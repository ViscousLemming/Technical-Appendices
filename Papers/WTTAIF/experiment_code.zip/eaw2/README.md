# EAW2

EAW2 tests whether a tuned freedom selector improves model selection inside sample-based Forward XM.

The child task is long-tailed. Every one of twelve outputs occurs during training, but common outputs appear far more often than rare outputs. The parent task uses new contexts and weights the same twelve outputs equally. Child-validation selection therefore favours a frequency specialist. Freedom selection chooses a near-tied child model that retains more valid parent completions.

The public comparison has two rows.

```text
xm
weak
```

Both rows come from the same 48-model candidate pool in each full-profile world. The freedom selector reads output profiles on unlabelled parent contexts. The child-validation selector does not. The primary comparison is a transductive common-pool model-selection test, rather than an equal-compute comparison between two selected training runs.

## Colab

Place this folder at

```text
/content/drive/MyDrive/weakness_experiments/eaw2lt
```

Open `eaw2.ipynb` from that folder.

Run the smoke profile first.

```python
PROFILE = "smoke"
```

Then run the full profile.

```python
PROFILE = "full"
```

All progress is written to

```text
/content/drive/MyDrive/weakness_experiments/eaw2run
```

The runner resumes completed worlds and unfinished branches after a disconnection.

An L4 or A100 is appropriate. The full profile should usually finish in about two to five hours on an L4 and one to three hours on an A100. Drive traffic and Colab contention can lengthen this.

## Command line

```bash
python -m eaw2code.main check \
  --root /content/drive/MyDrive/weakness_experiments

python -m eaw2code.main run \
  --root /content/drive/MyDrive/weakness_experiments \
  --profile full
```

The final report is written to

```text
eaw2run/full/report.md
```

Read `spec.md` before interpreting the result.
