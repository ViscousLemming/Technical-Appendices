# EAW2 results

The full long-tail EAW2 run completed 24 calibration worlds and 30 disjoint final worlds.

## Primary result

| Quantity | Result |
|---|---:|
| Freedom-selected balanced-parent hit | 0.389181 |
| Child-validation XM balanced-parent hit | 0.316942 |
| Paired difference | +0.072239 |
| Paired bootstrap 95 percent interval | +0.066296 to +0.076127 |
| Freedom wins | 29 of 30 |
| Ties | 0 of 30 |
| Exact one-sided paired sign-flip value | 1.863e-09 |

## Secondary results

| Quantity | Paired difference |
|---|---:|
| Child hit | -0.021698 |
| Parent support | +2.685547 cells |
| Parent log weakness | +1.877307 |

## Scope

The freedom selector read output-profile features on 256 unlabelled parent contexts. The child-validation selector did not. The selector was barred from the parent-hit endpoint. The same 240 deployment draws were used for selector features and the reported parent-hit estimate, so selection and endpoint noise were dependent.

The primary selectors could choose different K values and checkpoints. Child validation selected K=8 in every world. Freedom selected K=16 in 29 worlds and K=8 in one. The result is therefore a transductive common-pool selector comparison, rather than an individually compute-matched training comparison.

A post hoc matched-setting check across the six fixed K and checkpoint combinations with K in {16,32} gave mean gain +0.006455, paired bootstrap interval [0.005798, 0.007079], and a positive mean in all 30 worlds. It was not predeclared.

## Calibration

The frozen instrument used formula-bank prefix 240 and a 0.97 child-fit gate. Its cross-stream calibration mean improvement was +0.068139. Its structural rate was 0.9167, above the required 0.80 threshold.
