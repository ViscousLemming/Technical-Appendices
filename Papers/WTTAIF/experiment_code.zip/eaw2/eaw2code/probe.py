"""Deployment profiles and completion features."""
from __future__ import annotations

import numpy as np
import torch

from cfg import Plan
from world import World


@torch.no_grad()
def draw(
    model,
    x: torch.Tensor,
    draws: int,
    seed: int,
    device: torch.device,
    ctx_batch: int = 128,
    draw_chunk: int = 24,
) -> torch.Tensor:
    model.eval()
    gen = torch.Generator(device=device.type).manual_seed(seed)
    out = []
    zdim = model.z.in_features
    for start in range(0, len(x), ctx_batch):
        xb = x[start:start + ctx_batch].to(device)
        parts = []
        left = draws
        while left:
            n = min(left, draw_chunk)
            xx = xb.repeat(n, 1)
            z = torch.randn((n * len(xb), zdim), generator=gen, device=device, dtype=xb.dtype)
            parts.append(model(xx, z).reshape(n, len(xb), -1).cpu())
            left -= n
        out.append(torch.cat(parts).transpose(0, 1))
    return torch.cat(out)


def cells(pred: torch.Tensor) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Decode every continuous output into its nearest one-hot output cell."""
    d2 = pred.square().sum(-1, keepdim=True) + 1.0 - 2.0 * pred
    vals, labs = torch.topk(d2, k=2, dim=-1, largest=False)
    dist = vals[..., 0]
    margin = vals[..., 1] - vals[..., 0]
    return (
        labs[..., 0].numpy().astype(np.int16),
        dist.numpy().astype(np.float32),
        margin.numpy().astype(np.float32),
    )


def _profile(lab: np.ndarray, n_out: int, upto: int):
    lab = lab[:, :upto]
    n_context = lab.shape[0]
    counts = np.zeros((n_context, n_out), np.int32)
    rows = np.repeat(np.arange(n_context), upto)
    np.add.at(counts, (rows, lab.reshape(-1)), 1)
    return counts, counts > 0, counts / max(1, upto)


def _hit(p: np.ndarray, freq: np.ndarray, k: int) -> float:
    return float((p * (1.0 - np.power(1.0 - freq, k))).sum(-1).mean())


def _logw(a: np.ndarray) -> np.ndarray:
    a = np.maximum(a.astype(float), 1.0)
    return np.log(np.power(2.0, a) - 1.0)


def _bundles(plan: Plan, seed: int) -> dict[int, np.ndarray]:
    rng = np.random.default_rng(seed)
    n = max(plan.probe_counts)
    return {
        order: np.stack([
            rng.choice(plan.n_out, order, replace=False) for _ in range(n)
        ])
        for order in (1, 2, 3, 4)
    }


def eval_model(
    model,
    world: World,
    plan: Plan,
    seed: int,
    device: torch.device,
    step: int,
    loss: float,
) -> dict:
    pred_val = draw(model, world.x_val, plan.draws, seed + 1, device)
    pred_probe = draw(model, world.x_probe, plan.draws, seed + 2, device)
    lab_val, dist_val, margin_val = cells(pred_val)
    lab_probe, dist_probe, margin_probe = cells(pred_probe)

    count_val, active_val, freq_val = _profile(lab_val, plan.n_out, plan.draws)
    count_probe, active_probe, freq_probe = _profile(lab_probe, plan.n_out, plan.draws)
    p_child = world.p_val.numpy()
    p_parent = world.p_probe.numpy()
    child_support = active_val.sum(-1)
    probe_support = active_probe.sum(-1)

    child_hit = _hit(p_child, freq_val, plan.eval_k)
    parent_hit = _hit(p_parent, freq_probe, plan.eval_k)
    child_primary = float(_logw(child_support).mean())
    parent_primary = float(_logw(probe_support).mean())
    child_full = float((child_support == plan.n_out).mean())
    probe_full = float((probe_support == plan.n_out).mean())

    row = {
        "step": step,
        "train_loss": loss,
        "child_hit": child_hit,
        "parent_hit": parent_hit,
        "child_supp": float(child_support.mean()),
        "parent_supp": float(probe_support.mean()),
        "child_logw": child_primary,
        "parent_logw": parent_primary,
        "child_full": child_full,
        "parent_full": probe_full,
        "child_fit": float(np.exp(-dist_val).mean()),
        "parent_fit": float(np.exp(-dist_probe).mean()),
        "child_margin": float(margin_val.mean()),
        "parent_margin": float(margin_probe.mean()),
    }

    # Rare labels are the lower half of the child probability order.
    order = world.label_order.numpy()
    rare = np.zeros(plan.n_out, dtype=bool)
    rare[order[plan.n_out // 2:]] = True
    bundles = _bundles(plan, seed + 13)

    for n in plan.probe_counts:
        _, active, freq = _profile(lab_probe, plan.n_out, n)
        support = active.sum(-1)
        logw = _logw(support)
        entropy = -(freq * np.log(np.clip(freq, 1e-30, None))).sum(-1)
        row[f"primary_{n}"] = float(logw.mean())
        row[f"supp_{n}"] = float(support.mean())
        row[f"suppsd_{n}"] = float(support.std())
        row[f"full_{n}"] = float((support == plan.n_out).mean())
        row[f"ent_{n}"] = float(entropy.mean())
        row[f"maxp_{n}"] = float(freq.max(-1).mean())
        row[f"tail_{n}"] = float(freq[:, rare].sum(-1).mean())
        row[f"fit_{n}"] = float(np.exp(-dist_probe[:, :n]).mean())
        row[f"margin_{n}"] = float(margin_probe[:, :n].mean())
        for order_n, bundle in bundles.items():
            ok = active[:, bundle[:n]].all(-1)
            row[f"c{order_n}_{n}"] = float(ok.mean())
        vals = np.asarray([row[f"c{r}_{n}"] for r in (1, 2, 3, 4)])
        row[f"joint_{n}"] = float(vals.mean())
        row[f"decay_{n}"] = float(vals[0] - vals[-1])

    return row


def feature_cols(n: int) -> list[str]:
    return [
        f"supp_{n}", f"suppsd_{n}", f"full_{n}", f"ent_{n}", f"maxp_{n}",
        f"tail_{n}", f"fit_{n}", f"margin_{n}",
        f"c1_{n}", f"c2_{n}", f"c3_{n}", f"c4_{n}", f"joint_{n}", f"decay_{n}",
        "child_hit", "child_supp", "child_logw", "child_full", "child_fit",
        "child_margin", "train_loss",
    ]
