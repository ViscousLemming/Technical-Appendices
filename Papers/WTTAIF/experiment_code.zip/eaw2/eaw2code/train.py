"""Sample-based XM candidate pools for the long-tail child task."""
from __future__ import annotations

import math
from pathlib import Path
import torch
from torch.nn import functional as F

from cfg import Plan
from net import GenNet
from util import atomic_torch, seed_all
from world import World
from xmcore import xm_best_of_k


def _loss_wrap(model_forward, conditions, targets, learning=True,
               rand_inputs=None, rand_seeds=None):
    del rand_seeds
    with torch.set_grad_enabled(learning):
        pred = model_forward(conditions, rand_inputs)
        loss = F.mse_loss(pred, targets, reduction="none").mean(1)
        return loss, pred


def _rate(step: int, total: int, peak: float) -> float:
    warm = max(10, total // 20)
    if step < warm:
        return peak * (step + 1) / warm
    frac = (step - warm) / max(1, total - warm)
    return peak * (0.05 + 0.95 * 0.5 * (1 + math.cos(math.pi * frac)))


def train_branch(
    world: World,
    plan: Plan,
    k: int,
    family: int,
    branch: int,
    device: torch.device,
    ck: Path,
    state: Path,
    on_check,
) -> list[dict]:
    # K variants inside one family start from the same parameters and minibatches.
    init_seed = world.seed + 3001 + 1009 * family
    batch_seed = world.seed + 5003 + 1013 * family
    cand_seed = world.seed + 7001 + 1019 * family

    seed_all(init_seed)
    model = GenNet(plan.d_in, plan.n_out, plan.width, plan.n_out, init_seed).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=plan.lr, weight_decay=plan.wd)
    batch_gen = torch.Generator(device=device.type).manual_seed(batch_seed)
    cand_gen = torch.Generator(device=device.type)

    start = 0
    rows: list[dict] = []
    saved: dict[str, dict[str, torch.Tensor]] = {}
    if state.exists():
        raw = torch.load(state, map_location="cpu", weights_only=False)
        rows = list(raw.get("rows", []))
        saved = raw.get("states", {})
        if len(rows) == len(plan.checks):
            return rows
        if not ck.exists():
            rows = []
            saved = {}

    if ck.exists():
        raw = torch.load(ck, map_location=device, weights_only=False)
        model.load_state_dict(raw["model"])
        opt.load_state_dict(raw["opt"])
        start = int(raw["step"])
        rows = list(raw.get("rows", []))
        saved = raw.get("states", {})
        batch_gen.set_state(raw["batch_gen"].cpu())
        torch.set_rng_state(raw["rng"].cpu())
        if torch.cuda.is_available() and raw.get("cuda_rng") is not None:
            torch.cuda.set_rng_state_all([state.cpu() for state in raw["cuda_rng"]])

    x = world.x_train.to(device)
    y = world.y_train.to(device)
    eye = torch.eye(plan.n_out, device=device)
    done = {int(row["step"]) for row in rows}

    for step in range(start + 1, plan.steps + 1):
        idx = torch.randint(0, len(x), (plan.batch,), generator=batch_gen, device=device)
        target = eye[y[idx]]
        # The candidate sets for different K values are nested at every step.
        cand_gen.manual_seed(cand_seed + 104729 * step)
        losses, _ = xm_best_of_k(
            model.forward,
            _loss_wrap,
            x[idx],
            target,
            k,
            plan.chunk,
            save_mem=True,
            generator=cand_gen,
        )
        loss = losses.mean()
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        lr = _rate(step - 1, plan.steps, plan.lr)
        for group in opt.param_groups:
            group["lr"] = lr
        opt.step()

        if step in plan.checks and step not in done:
            row = on_check(model, step, float(loss.detach()))
            row.update({"branch": branch, "family": family, "k_train": k, "step": step})
            rows.append(row)
            saved[str(step)] = {
                name: value.detach().cpu() for name, value in model.state_dict().items()
            }
            atomic_torch(
                ck,
                {
                    "step": step,
                    "model": model.state_dict(),
                    "opt": opt.state_dict(),
                    "rows": rows,
                    "states": saved,
                    "batch_gen": batch_gen.get_state(),
                    "rng": torch.get_rng_state(),
                    "cuda_rng": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
                },
            )
            atomic_torch(state, {"rows": rows, "states": saved})
        elif step % max(25, plan.steps // 8) == 0 and step < plan.steps:
            atomic_torch(
                ck,
                {
                    "step": step,
                    "model": model.state_dict(),
                    "opt": opt.state_dict(),
                    "rows": rows,
                    "states": saved,
                    "batch_gen": batch_gen.get_state(),
                    "rng": torch.get_rng_state(),
                    "cuda_rng": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
                },
            )

    if ck.exists():
        ck.unlink()
    atomic_torch(state, {"rows": rows, "states": saved})
    return rows
