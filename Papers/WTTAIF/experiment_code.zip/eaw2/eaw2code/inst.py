"""Prospective Part-B-style weakness tuning."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import numpy as np
import pandas as pd
from scipy.optimize import nnls

from probe import feature_cols
from util import rank_pct, spearman


@dataclass
class Fit:
    bank_n: int
    probe_n: int
    alpha: float
    cap: float
    cols: list[str]
    p_mean: float
    p_sd: float
    x_mean: list[float]
    x_sd: list[float]
    coef: list[float]
    intercept: float

    def asdict(self) -> dict:
        return self.__dict__

    @classmethod
    def fromdict(cls, raw: dict) -> "Fit":
        return cls(**raw)


def eligible(group: pd.DataFrame, gate: float) -> pd.DataFrame:
    best = float(group.child_hit.max())
    cut = best * float(gate)
    out = group[group.child_hit >= cut - 1e-12].copy()
    if out.empty:
        out = group.loc[[group.child_hit.idxmax()]].copy()
    return out


def _target(frame: pd.DataFrame) -> np.ndarray:
    out = np.empty(len(frame), dtype=float)
    for _, idx in frame.groupby("world", sort=False).groups.items():
        ids = np.asarray(list(idx), dtype=int)
        out[ids] = rank_pct(frame.loc[idx, "parent_hit"].to_numpy())
    return out


def fit_one(
    frame: pd.DataFrame,
    bank_n: int,
    probe_n: int,
    alpha: float,
    cap: float,
    cols: list[str],
) -> Fit:
    if frame.empty:
        raise ValueError("no calibration candidates")
    y = _target(frame)
    y = (y - y.mean()) / max(y.std(), 1e-8)
    primary = frame[f"primary_{probe_n}"].to_numpy(float)
    p_mean = float(primary.mean())
    p_sd = float(max(primary.std(), 1e-8))
    pz = (primary - p_mean) / p_sd

    if not cols:
        return Fit(
            bank_n=bank_n, probe_n=probe_n, alpha=float(alpha), cap=float(cap), cols=[],
            p_mean=p_mean, p_sd=p_sd, x_mean=[], x_sd=[], coef=[], intercept=0.0,
        )

    x = frame[cols].to_numpy(float)
    x_mean = x.mean(0)
    x_sd = x.std(0)
    x_sd = np.where(x_sd < 1e-8, 1.0, x_sd)
    xz = (x - x_mean) / x_sd
    target = y - pz
    xc = xz - xz.mean(0)
    yc = target - target.mean()
    ax = np.vstack([xc, np.sqrt(max(alpha, 0.0)) * np.eye(xc.shape[1])])
    ay = np.r_[yc, np.zeros(xc.shape[1])]
    coef, _ = nnls(ax, ay, maxiter=max(200, 40 * xc.shape[1]))
    intercept = float(target.mean() - xz.mean(0) @ coef)
    return Fit(
        bank_n=bank_n, probe_n=probe_n, alpha=float(alpha), cap=float(cap), cols=list(cols),
        p_mean=p_mean, p_sd=p_sd, x_mean=x_mean.tolist(), x_sd=x_sd.tolist(),
        coef=coef.tolist(), intercept=intercept,
    )


def predict_one(fit: Fit, frame: pd.DataFrame) -> np.ndarray:
    primary = (frame[f"primary_{fit.probe_n}"].to_numpy(float) - fit.p_mean) / max(fit.p_sd, 1e-8)
    if not fit.cols:
        return primary
    x = (frame[fit.cols].to_numpy(float) - np.asarray(fit.x_mean)) / np.asarray(fit.x_sd)
    residual = x @ np.asarray(fit.coef) + fit.intercept
    cap = max(fit.cap, 1e-6)
    return primary + cap * np.tanh(residual / cap)


def _struct(frame: pd.DataFrame, gate: float, probe_n: int, gap: float) -> dict[str, float]:
    ok = []
    ranges = []
    sizes = []
    for _, group in frame.groupby("world", sort=False):
        pool = eligible(group, gate)
        vals = pool[f"primary_{probe_n}"].to_numpy(float)
        span = float(vals.max() - vals.min()) if len(vals) else 0.0
        ranges.append(span)
        sizes.append(len(pool))
        ok.append(len(pool) >= 2 and span >= gap)
    return {
        "rate": float(np.mean(ok)) if ok else 0.0,
        "mean_gap": float(np.mean(ranges)) if ranges else 0.0,
        "mean_n": float(np.mean(sizes)) if sizes else 0.0,
    }


def _eval(fit: Fit, test: pd.DataFrame, gate: float) -> dict[str, float]:
    delta = []
    rho = []
    wins = []
    for _, group in test.groupby("world", sort=False):
        pool = eligible(group, gate)
        score = predict_one(fit, pool)
        weak_idx = pool.index[int(np.argmax(score))]
        xm_idx = group.child_hit.idxmax()
        dv = float(group.loc[weak_idx, "parent_hit"] - group.loc[xm_idx, "parent_hit"])
        delta.append(dv)
        wins.append(dv > 1e-15)
        rho.append(spearman(score, pool.parent_hit.to_numpy()))
    return {
        "delta": float(np.mean(delta)),
        "win": float(np.mean(wins)),
        "rho": float(np.mean(rho)),
    }


def _configs(max_n: int, plan) -> list[dict[str, Any]]:
    rng = np.random.default_rng(260804)
    out: list[dict[str, Any]] = []
    # Formula zero is primary measured weakness with no residual.
    out.append({"probe_n": max(plan.probe_counts), "alpha": 0.0, "cap": 1.0, "cols": []})
    alphas = [0.0, 0.01, 0.1, 1.0, 10.0]
    caps = [0.25, 0.5]
    while len(out) < max_n:
        i = len(out)
        probe_n = plan.probe_counts[i % len(plan.probe_counts)]
        all_cols = feature_cols(probe_n)
        take = int(rng.integers(max(3, len(all_cols) // 3), len(all_cols) + 1))
        cols = sorted(rng.choice(all_cols, take, replace=False).tolist())
        out.append({
            "probe_n": probe_n,
            "alpha": alphas[i % len(alphas)],
            "cap": caps[(i // len(alphas)) % len(caps)],
            "cols": cols,
        })
    return out


def tune(frame: pd.DataFrame, plan) -> dict[str, Any]:
    stream0 = frame[frame.stream == 0].reset_index(drop=True)
    stream1 = frame[frame.stream == 1].reset_index(drop=True)
    configs = _configs(max(plan.bank_counts), plan)
    records = []

    for idx, cfg in enumerate(configs):
        fit0 = fit_one(stream0, max(plan.bank_counts), **cfg)
        fit1 = fit_one(stream1, max(plan.bank_counts), **cfg)
        for gate in plan.gates:
            e01 = _eval(fit0, stream1, gate)
            e10 = _eval(fit1, stream0, gate)
            st0 = _struct(stream0, gate, cfg["probe_n"], plan.struct_gap)
            st1 = _struct(stream1, gate, cfg["probe_n"], plan.struct_gap)
            cv = {
                "score": min(e01["delta"], e10["delta"]),
                "mean": 0.5 * (e01["delta"] + e10["delta"]),
                "win": min(e01["win"], e10["win"]),
                "rho": 0.5 * (e01["rho"] + e10["rho"]),
                "struct": min(st0["rate"], st1["rate"]),
                "gap": min(st0["mean_gap"], st1["mean_gap"]),
            }
            records.append({"idx": idx, "gate": gate, "cfg": cfg, "cv": cv, "fit0": fit0, "fit1": fit1})

    def key(row):
        cv = row["cv"]
        return (cv["score"], cv["mean"], cv["win"], cv["rho"], cv["struct"], cv["gap"])

    bank_best = []
    for n in plan.bank_counts:
        pool = [r for r in records if r["idx"] < n and r["cv"]["struct"] >= plan.struct_rate]
        if not pool:
            pool = [r for r in records if r["idx"] < n]
        best = max(pool, key=key)
        bank_best.append({"n": n, **best})

    chosen = max(bank_best, key=key)
    if chosen["cv"]["struct"] < plan.struct_rate:
        raise RuntimeError(
            f"Calibration pool lacks the declared weakness contrast. "
            f"Observed structural rate {chosen['cv']['struct']:.3f}, required {plan.struct_rate:.3f}."
        )

    peers = [
        r for r in records
        if r["idx"] < chosen["n"]
        and r["gate"] == chosen["gate"]
        and r["cv"]["struct"] >= plan.struct_rate
    ]
    peers = sorted(peers, key=key, reverse=True)[:plan.ensemble]
    fits = [fit.asdict() for row in peers for fit in (row["fit0"], row["fit1"])]
    return {
        "schema": "eaw2.lt.v1",
        "weak": {
            "bank_n": chosen["n"],
            "gate": chosen["gate"],
            "cv": chosen["cv"],
            "fits": fits,
            "bank": [
                {"n": row["n"], "idx": row["idx"], "gate": row["gate"], "cv": row["cv"]}
                for row in bank_best
            ],
        },
    }


def predict(spec: dict, frame: pd.DataFrame) -> np.ndarray:
    vals = [rank_pct(predict_one(Fit.fromdict(raw), frame)) for raw in spec["fits"]]
    if not vals:
        return frame[f"primary_{max(48, 1)}"].to_numpy(float)
    return np.mean(np.stack(vals), axis=0)
