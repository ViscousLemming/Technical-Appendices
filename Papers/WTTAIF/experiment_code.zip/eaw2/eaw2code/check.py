"""Fast implementation checks."""
from __future__ import annotations

import numpy as np
import pandas as pd
import torch

from cfg import get_plan
from net import GenNet
from probe import eval_model
from sel import choose
from world import make_world
from xmcore import xm_best_of_k


def checks() -> None:
    plan = get_plan("smoke")
    world = make_world(plan, 77)
    if not np.isclose(float(world.p_child.sum()), 1.0):
        raise AssertionError("child law does not sum to one")
    if len(torch.unique(world.y_train)) != plan.n_out:
        raise AssertionError("every output must occur in the child sample")
    if not torch.allclose(world.p_probe[0], torch.full((plan.n_out,), 1 / plan.n_out)):
        raise AssertionError("parent law must be balanced")

    model = GenNet(plan.d_in, plan.n_out, plan.width, plan.n_out, 9)
    row = eval_model(model, world, plan, 88, torch.device("cpu"), 0, 0.0)
    for key in ("child_hit", "parent_hit", "parent_logw", "primary_48"):
        if key not in row:
            raise AssertionError(key)

    x = torch.randn(5, plan.d_in)
    target = torch.eye(plan.n_out)[torch.tensor([0, 1, 2, 3, 0])]

    def wrap(model_forward, conditions, targets, learning=True,
             rand_inputs=None, rand_seeds=None):
        del rand_seeds
        with torch.set_grad_enabled(learning):
            pred = model_forward(conditions, rand_inputs)
            loss = (pred - targets).square().mean(1)
            return loss, pred

    gen = torch.Generator().manual_seed(41)
    loss, pred = xm_best_of_k(
        model.forward, wrap, x, target, 4, 2, save_mem=True, debug=True, generator=gen
    )
    if loss.shape != (5,) or pred.shape != target.shape:
        raise AssertionError("unexpected XM shape")
    loss.mean().backward()
    if not any(param.grad is not None for param in model.parameters()):
        raise AssertionError("winner-only gradient recompute failed")

    # The final selector may read unlabelled parent-profile features but must reject the parent-hit endpoint.
    dummy = pd.DataFrame({
        "candidate": [0, 1], "child_hit": [0.8, 0.79], "k_train": [8, 16],
        "step": [20, 40], "family": [0, 0], "branch": [0, 1],
        "primary_48": [1.0, 2.0], "parent_hit": [0.3, 0.5],
    })
    inst = {"weak": {"gate": 0.98, "fits": [{
        "bank_n": 1, "probe_n": 48, "alpha": 0.0, "cap": 1.0, "cols": [],
        "p_mean": 0.0, "p_sd": 1.0, "x_mean": [], "x_sd": [], "coef": [], "intercept": 0.0,
    }]}}
    try:
        choose(dummy, inst)
    except ValueError:
        pass
    else:
        raise AssertionError("parent endpoint block failed")

    print("EAW2 checks passed")


if __name__ == "__main__":
    checks()
