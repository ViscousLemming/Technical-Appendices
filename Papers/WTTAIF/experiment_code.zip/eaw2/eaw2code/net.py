"""Latent-conditioned generator used by EAW2."""
from __future__ import annotations

import torch
from torch import nn


class GenNet(nn.Module):
    def __init__(self, d_in: int, z_dim: int, width: int, n_out: int, seed: int):
        super().__init__()
        state = torch.random.get_rng_state()
        torch.manual_seed(seed)
        self.x = nn.Linear(d_in, width)
        self.z = nn.Linear(z_dim, width)
        self.h1 = nn.Linear(width, width)
        self.h2 = nn.Linear(width, width)
        self.out = nn.Linear(width, n_out)
        nn.init.normal_(self.out.weight, std=0.02)
        nn.init.zeros_(self.out.bias)
        torch.random.set_rng_state(state)

    def forward(self, x: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
        h = torch.nn.functional.silu(self.x(x) + self.z(z))
        h = h + torch.nn.functional.silu(self.h1(h))
        h = h + torch.nn.functional.silu(self.h2(h))
        return self.out(h)
