"""EAW2 run plans."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class Plan:
    name: str
    d_in: int
    width: int
    n_out: int
    n_train: int
    n_val: int
    n_probe: int
    batch: int
    ks: tuple[int, ...]
    families: int
    checks: tuple[int, ...]
    steps: int
    lr: float
    wd: float
    chunk: int
    eval_k: int
    draws: int
    tail_alpha: float
    cal_worlds: int
    final_worlds: int
    probe_counts: tuple[int, ...]
    bank_counts: tuple[int, ...]
    ensemble: int
    gates: tuple[float, ...]
    struct_gap: float
    struct_rate: float

    def asdict(self) -> dict:
        return asdict(self)

    @property
    def pool_n(self) -> int:
        return len(self.ks) * self.families * len(self.checks)


PLANS = {
    "smoke": Plan(
        name="smoke", d_in=4, width=32, n_out=8,
        n_train=768, n_val=24, n_probe=48, batch=64,
        ks=(4, 8), families=1, checks=(20, 40), steps=40,
        lr=0.004, wd=1e-6, chunk=4, eval_k=4, draws=48,
        tail_alpha=1.4, cal_worlds=2, final_worlds=2,
        probe_counts=(16, 32, 48), bank_counts=(8, 16), ensemble=2,
        gates=(0.95, 0.98), struct_gap=0.10, struct_rate=0.0,
    ),
    "dev": Plan(
        name="dev", d_in=8, width=64, n_out=12,
        n_train=4096, n_val=64, n_probe=128, batch=192,
        ks=(4, 8, 16, 32), families=1,
        checks=(200, 300, 400), steps=400,
        lr=0.0020, wd=1e-6, chunk=8, eval_k=8, draws=120,
        tail_alpha=1.6, cal_worlds=3, final_worlds=2,
        probe_counts=(48, 120), bank_counts=(48,), ensemble=4,
        gates=(0.97, 0.98, 0.99), struct_gap=0.40, struct_rate=0.50,
    ),
    "core": Plan(
        name="core", d_in=8, width=80, n_out=12,
        n_train=6144, n_val=64, n_probe=128, batch=192,
        ks=(4, 8, 16, 32), families=2,
        checks=(400, 600, 800), steps=800,
        lr=0.0018, wd=1e-6, chunk=8, eval_k=8, draws=120,
        tail_alpha=1.6, cal_worlds=5, final_worlds=10,
        probe_counts=(48, 120), bank_counts=(48, 120), ensemble=6,
        gates=(0.97, 0.98, 0.99), struct_gap=0.60, struct_rate=0.60,
    ),
    "full": Plan(
        name="full", d_in=8, width=128, n_out=12,
        n_train=16384, n_val=128, n_probe=256, batch=384,
        ks=(4, 8, 16, 32), families=4,
        checks=(1250, 1875, 2500), steps=2500,
        lr=0.0015, wd=1e-6, chunk=8, eval_k=8, draws=240,
        tail_alpha=1.6, cal_worlds=12, final_worlds=30,
        probe_counts=(48, 120, 240), bank_counts=(48, 120, 240), ensemble=8,
        gates=(0.97, 0.98, 0.99), struct_gap=1.0, struct_rate=0.80,
    ),
}


def get_plan(name: str) -> Plan:
    key = name.lower().strip()
    if key not in PLANS:
        raise ValueError("profile must be smoke, dev, core, or full")
    plan = PLANS[key]
    if plan.checks[-1] != plan.steps:
        raise ValueError("last checkpoint must equal steps")
    expected = {"smoke": 4, "dev": 12, "core": 24, "full": 48}[key]
    if plan.pool_n != expected:
        raise ValueError("unexpected pool size")
    return plan


def dirs(root: str | Path, profile: str) -> dict[str, Path]:
    base = Path(root) / "eaw2run" / profile
    out = {k: base / k for k in ("cal", "inst", "final", "pool", "ckpt", "tabs", "figs")}
    out["base"] = base
    for path in out.values():
        path.mkdir(parents=True, exist_ok=True)
    return out
