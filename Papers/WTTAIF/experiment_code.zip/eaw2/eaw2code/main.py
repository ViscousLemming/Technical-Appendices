from __future__ import annotations

import argparse
from check import checks
from run import analyse, run_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("check", "run", "analyse"))
    parser.add_argument("--root", required=True)
    parser.add_argument("--profile", default="full")
    parser.add_argument("--allow-cpu", action="store_true")
    args = parser.parse_args()
    if args.action == "check":
        checks()
    elif args.action == "run":
        run_all(args.root, args.profile, args.allow_cpu)
    else:
        analyse(args.root, args.profile)


if __name__ == "__main__":
    main()
