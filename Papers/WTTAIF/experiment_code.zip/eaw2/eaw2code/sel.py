"""Child-validation and transductive tuned-weakness selectors."""
from __future__ import annotations

import numpy as np
import pandas as pd

from inst import eligible, predict


FORBIDDEN_COLS = {"parent_hit"}


def _xm_index(frame: pd.DataFrame) -> int:
    # Highest child hit. Ties favour less exploration, then the earlier checkpoint.
    ordered = frame.sort_values(
        ["child_hit", "k_train", "step", "family", "branch"],
        ascending=[False, True, True, True, True],
        kind="mergesort",
    )
    return int(ordered.index[0])


def choose(frame: pd.DataFrame, instrument: dict) -> pd.DataFrame:
    leak = FORBIDDEN_COLS.intersection(frame.columns)
    if leak:
        raise ValueError(f"parent performance endpoint reached final selector: {sorted(leak)}")

    rows = []
    xm_idx = _xm_index(frame)
    xm = frame.loc[xm_idx].copy()
    xm["selector"] = "xm"
    rows.append(xm)

    spec = instrument["weak"]
    pool = eligible(frame, float(spec["gate"]))
    score = predict(spec, pool)
    pool = pool.copy()
    pool["weak_score"] = score
    ordered = pool.sort_values(
        ["weak_score", f"primary_{max(int(f['probe_n']) for f in spec['fits'])}", "child_hit", "k_train", "step"],
        ascending=[False, False, False, False, False],
        kind="mergesort",
    )
    weak_idx = int(ordered.index[0])
    weak = frame.loc[weak_idx].copy()
    weak["selector"] = "weak"
    weak["weak_score"] = float(pool.loc[weak_idx, "weak_score"])
    rows.append(weak)
    return pd.DataFrame(rows)
