"""EAW2 calibration, final cohort, and analysis."""
from __future__ import annotations

import gc
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch

from cfg import dirs, get_plan
from inst import tune
from probe import eval_model
from sel import FORBIDDEN_COLS, choose
from train import train_branch
from util import atomic_json, bootstrap_mean, devinfo, signflip_p
from world import make_world

SCHEMA = "eaw2.lt.v1"


def _load(path: str | Path):
    return json.loads(Path(path).read_text())


def run_world(root: Path, plan, stage: str, stream: int, index: int, device: torch.device) -> pd.DataFrame:
    dd = dirs(root, plan.name)
    csv = dd[stage] / f"s{stream}-w{index}.csv"
    if csv.exists():
        return pd.read_csv(csv)

    seed = 92003 + (0 if stage == "cal" else 1_000_000) + 10007 * stream + 101 * index
    world = make_world(plan, seed)
    rows = []
    branch = 0
    for family in range(plan.families):
        for k in plan.ks:
            print(f"{stage} stream={stream} world={index} family={family} K={k}")

            def on_check(model, step, loss, b=branch, fam=family, kval=k):
                return eval_model(
                    model,
                    world,
                    plan,
                    seed + 100003 * b + 1009 * step + 17 * kval,
                    device,
                    step,
                    loss,
                )

            rows.extend(
                train_branch(
                    world,
                    plan,
                    k,
                    family,
                    branch,
                    device,
                    dd["ckpt"] / f"{stage}-s{stream}-w{index}-f{family}-k{k}.pt",
                    dd["pool"] / f"{stage}-s{stream}-w{index}-f{family}-k{k}.pt",
                    on_check,
                )
            )
            branch += 1
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    frame = pd.DataFrame(rows)
    frame["stage"] = stage
    frame["stream"] = stream
    frame["world"] = index
    frame["seed"] = seed
    frame["candidate"] = np.arange(len(frame), dtype=int)
    csv.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(csv, index=False)
    return frame


def run_all(root: str | Path, profile: str = "full", allow_cpu: bool = False):
    root = Path(root)
    plan = get_plan(profile)
    dd = dirs(root, profile)
    cfg_path = root / "eaw2run" / "cfg.json"
    if cfg_path.exists() and _load(cfg_path).get("schema") != SCHEMA:
        raise RuntimeError("An earlier eaw2run is present. Rename it before running this design.")
    atomic_json(cfg_path, {"schema": SCHEMA})

    if not torch.cuda.is_available() and not allow_cpu:
        raise RuntimeError("CUDA is absent")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    atomic_json(
        dd["base"] / "plan.json",
        {
            "schema": SCHEMA,
            "plan": plan.asdict(),
            "device": devinfo(),
            "child_law": "permuted Zipf",
            "parent_law": "uniform over the same outputs",
        },
    )

    cal = []
    for stream in (0, 1):
        for index in range(plan.cal_worlds):
            cal.append(run_world(root, plan, "cal", stream, index, device))
    cal_frame = pd.concat(cal, ignore_index=True)
    cal_frame.to_csv(dd["tabs"] / "cal.csv", index=False)

    inst_path = dd["inst"] / "inst.json"
    if inst_path.exists():
        instrument = _load(inst_path)
    else:
        instrument = tune(cal_frame, plan)
        atomic_json(inst_path, instrument)

    final = []
    for rep in range(plan.final_worlds):
        path = dd["final"] / f"r{rep}.csv"
        if path.exists():
            selected = pd.read_csv(path)
        else:
            candidates = run_world(root, plan, "final", 2, rep, device)
            selector_frame = candidates.drop(columns=list(FORBIDDEN_COLS), errors="ignore")
            picks = choose(selector_frame, instrument)
            audit = candidates.set_index("candidate")
            rows = []
            for _, pick in picks.iterrows():
                row = audit.loc[int(pick.candidate)].copy()
                row["selector"] = pick.selector
                row["rep"] = rep
                if "weak_score" in pick:
                    row["weak_score"] = pick.weak_score
                rows.append(row)
            selected = pd.DataFrame(rows)
            selected.to_csv(path, index=False)
        final.append(selected)

    final_frame = pd.concat(final, ignore_index=True)
    final_frame.to_csv(dd["tabs"] / "final.csv", index=False)
    return analyse(root, profile, final_frame, instrument)


def _paired(frame: pd.DataFrame, value: str) -> np.ndarray:
    pivot = frame.pivot(index="rep", columns="selector", values=value)
    return (pivot.weak - pivot.xm).to_numpy()


def analyse(root: str | Path, profile: str, frame: pd.DataFrame | None = None, instrument: dict | None = None):
    root = Path(root)
    plan = get_plan(profile)
    dd = dirs(root, profile)
    if frame is None:
        files = sorted(dd["final"].glob("r*.csv"))
        if not files:
            raise RuntimeError("no final rows")
        frame = pd.concat([pd.read_csv(path) for path in files], ignore_index=True)

    means = frame.groupby("selector").agg(
        parent_hit=("parent_hit", "mean"),
        child_hit=("child_hit", "mean"),
        parent_supp=("parent_supp", "mean"),
        parent_logw=("parent_logw", "mean"),
        k_train=("k_train", "mean"),
        step=("step", "mean"),
    ).reset_index()
    means.to_csv(dd["tabs"] / "means.csv", index=False)

    contrasts = {}
    for value, seed in (("parent_hit", 82001), ("child_hit", 82002), ("parent_supp", 82003), ("parent_logw", 82004)):
        delta = _paired(frame, value)
        mean, lo, hi = bootstrap_mean(delta, seed)
        contrasts[value] = {
            "delta": mean,
            "lo": lo,
            "hi": hi,
            "positive": int((delta > 0).sum()),
            "ties": int((np.abs(delta) <= 1e-15).sum()),
            "n": len(delta),
            "p_one": signflip_p(delta),
        }
    pd.DataFrame([{"metric": key, **value} for key, value in contrasts.items()]).to_csv(
        dd["tabs"] / "pair.csv", index=False
    )

    import matplotlib.pyplot as plt

    parent_delta = _paired(frame, "parent_hit")
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    ax.scatter(np.arange(len(parent_delta)), parent_delta)
    ax.axhline(0, linewidth=1)
    ax.set_xlabel("Paired parent world")
    ax.set_ylabel("Freedom selection minus child-validation XM")
    fig.tight_layout()
    fig.savefig(dd["figs"] / "pair.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    for selector, group in frame.groupby("selector"):
        label = {"xm": "Child-validation XM", "weak": "Freedom-selected XM"}.get(selector, selector)
        ax.scatter(group.child_hit, group.parent_hit, label=label, alpha=0.75)
    ax.set_xlabel("Long-tail child hit")
    ax.set_ylabel("Balanced parent hit")
    ax.legend()
    fig.tight_layout()
    fig.savefig(dd["figs"] / "frontier.png", dpi=180)
    plt.close(fig)

    spec = (instrument or _load(dd["inst"] / "inst.json"))["weak"]
    main = contrasts["parent_hit"]
    child = contrasts["child_hit"]
    supp = contrasts["parent_supp"]
    logw = contrasts["parent_logw"]
    text = [
        "# EAW2 report",
        "",
        f"Freedom selection minus child-validation XM on the balanced parent was {main['delta']:.6f} "
        f"with 95% interval [{main['lo']:.6f}, {main['hi']:.6f}].",
        f"Freedom selection improved {main['positive']} of {main['n']} paired parent worlds. "
        f"The exact one-sided sign-flip value was {main['p_one']:.3e}.",
        "",
        f"The paired child-hit difference was {child['delta']:.6f}.",
        f"The paired parent-support difference was {supp['delta']:.6f}.",
        f"The paired parent log-freedom difference was {logw['delta']:.6f}.",
        "",
        f"The frozen instrument used formula-bank prefix {spec['bank_n']}, child-fit gate {spec['gate']:.3f}, "
        f"and calibration structural rate {spec['cv']['struct']:.3f}.",
    ]
    (dd["base"] / "report.md").write_text("\n".join(text) + "\n")
    return {"means": means.to_dict("records"), "pair": contrasts, "instrument": spec}
