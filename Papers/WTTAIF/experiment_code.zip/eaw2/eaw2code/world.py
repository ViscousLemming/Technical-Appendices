"""Long-tail child tasks and balanced parent tasks."""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import torch

from cfg import Plan


@dataclass(frozen=True)
class World:
    seed: int
    x_train: torch.Tensor
    y_train: torch.Tensor
    x_val: torch.Tensor
    p_val: torch.Tensor
    x_probe: torch.Tensor
    p_probe: torch.Tensor
    p_child: torch.Tensor
    label_order: torch.Tensor


def _contexts(rng: np.random.Generator, n: int, d: int) -> np.ndarray:
    # Child and parent use separate context samples from the same distribution.
    # This isolates the shift in demanded output frequencies.
    x = rng.normal(size=(n, d)).astype(np.float32)
    x[:, 0] += 0.15 * np.tanh(x[:, 1])
    return x


def _tail(n_out: int, alpha: float, order: np.ndarray) -> np.ndarray:
    ranks = np.arange(1, n_out + 1, dtype=np.float64)
    base = np.power(ranks, -alpha)
    base /= base.sum()
    p = np.empty(n_out, dtype=np.float64)
    p[order] = base
    return p


def make_world(plan: Plan, seed: int) -> World:
    rng = np.random.default_rng(seed)
    order = rng.permutation(plan.n_out)
    p_child = _tail(plan.n_out, plan.tail_alpha, order)
    p_parent = np.full(plan.n_out, 1.0 / plan.n_out, dtype=np.float64)

    x_train = _contexts(rng, plan.n_train, plan.d_in)
    # Put one instance of each output in the child sample, then draw the rest
    # from the declared long-tail law.
    y_rest = rng.choice(plan.n_out, size=plan.n_train - plan.n_out, p=p_child)
    y_train = np.concatenate([np.arange(plan.n_out), y_rest]).astype(np.int64)
    rng.shuffle(y_train)

    x_val = _contexts(rng, plan.n_val, plan.d_in)
    x_probe = _contexts(rng, plan.n_probe, plan.d_in)
    return World(
        seed=seed,
        x_train=torch.from_numpy(x_train),
        y_train=torch.from_numpy(y_train),
        x_val=torch.from_numpy(x_val),
        p_val=torch.from_numpy(np.broadcast_to(p_child.astype(np.float32), (plan.n_val, plan.n_out)).copy()),
        x_probe=torch.from_numpy(x_probe),
        p_probe=torch.from_numpy(np.broadcast_to(p_parent.astype(np.float32), (plan.n_probe, plan.n_out)).copy()),
        p_child=torch.from_numpy(p_child.astype(np.float32)),
        label_order=torch.from_numpy(order.astype(np.int64)),
    )
