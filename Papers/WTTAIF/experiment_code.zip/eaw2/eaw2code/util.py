"""EAW2 helpers."""
from __future__ import annotations

import json
import math
import os
import random
from pathlib import Path
from typing import Any

import numpy as np
import torch


def seed_all(seed: int):
    random.seed(seed); np.random.seed(seed % (2**32 - 1)); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


def atomic_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True))
    os.replace(tmp, path)


def atomic_torch(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, tmp)
    os.replace(tmp, path)


def rank_pct(x: np.ndarray) -> np.ndarray:
    from scipy.stats import rankdata
    x = np.asarray(x, float)
    if len(x) <= 1: return np.zeros_like(x)
    return (rankdata(x, method="average") - 1) / (len(x) - 1)


def spearman(a, b) -> float:
    from scipy.stats import spearmanr
    v = spearmanr(a, b).statistic
    return 0.0 if not np.isfinite(v) else float(v)


def bootstrap_mean(x: np.ndarray, seed: int, draws: int = 20000):
    x = np.asarray(x, float); rng = np.random.default_rng(seed)
    sims = x[rng.integers(0, len(x), size=(draws, len(x)))].mean(1)
    return float(x.mean()), float(np.quantile(sims, .025)), float(np.quantile(sims, .975))


def signflip_p(x: np.ndarray) -> float:
    """Exact one-sided paired sign-flip value when n is moderate.

    The observed statistic is the paired mean. A sign pattern can be
    represented by the subset of observations whose signs are flipped. If
    the observed sum is T, the permuted sum is T - 2 * subset_sum. Hence a
    permuted mean at least as large as observed is equivalent to a subset
    sum no greater than the numerical tolerance. Meet-in-the-middle avoids
    enumerating all 2**n patterns.
    """
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    x = x[np.abs(x) > 1e-15]
    n = len(x)
    if n == 0:
        return 1.0

    if n <= 42:
        def subset_sums(values: np.ndarray) -> np.ndarray:
            out = np.array([0.0], dtype=np.float64)
            for value in values:
                out = np.concatenate((out, out + value))
            return out

        split = n // 2
        left = subset_sums(x[:split])
        right = np.sort(subset_sums(x[split:]))
        threshold = 0.5 * n * 1e-15
        count = 0
        for value in left:
            count += int(np.searchsorted(right, threshold - value, side="right"))
        return float(count / (2**n))

    # Deterministic Monte Carlo fallback with an add-one correction.
    rng = np.random.default_rng(77)
    draws = 2_000_000
    signs = rng.choice((-1, 1), size=(draws, n))
    exceed = int((np.mean(signs * x, axis=1) >= x.mean() - 1e-15).sum())
    return float((exceed + 1) / (draws + 1))


def devinfo():
    return {"torch": torch.__version__, "cuda": bool(torch.cuda.is_available()),
            "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu"}
