# EAW2

## Claim

EAW2 tests this claim.

> Among models trained by the same sample-based Forward XM procedure, a prospectively tuned freedom selector chooses a model that performs better on a balanced parent task than the model chosen by long-tail child validation.

## Child and parent

There are twelve decoded output cells. Every output occurs in the child sample. Child frequencies follow a permuted Zipf law with exponent 1.6. Parent demands on new contexts are uniform over the same twelve outputs.

The child and parent context sets are disjoint samples from the same context law. The design isolates the change in demanded output frequencies.

This creates a conflict between specialisation and retained freedom. Child validation rewards concentrating probability on common outputs. The parent rewards retaining the whole valid repertoire.

## Forward XM

Each update draws `K` Gaussian latent candidates. The generator emits one continuous output for each latent. The code computes reconstruction loss against the one-hot target, selects the minimum-loss candidate, and recomputes only that candidate with gradients.

This is the winner-only sample-based Forward XM update used by the authors' public implementation.

The full profile trains

```text
K = 4, 8, 16, 32
```

Four paired families share initial parameters and minibatch order across K. Each trajectory is recorded at steps

```text
1250, 1875, 2500
```

This yields 48 candidates per world.

## Output language

Every continuous generation is decoded into its nearest one-hot output cell. The twelve Voronoi cells form a total finite output partition.

For an unseen context with `a` active output cells, local freedom is

```text
2^a - 1
```

The reported score averages log freedom across unlabelled parent inputs. Probe counts of 48, 120, and 240 latent draws are treated as tuning choices.

## Selection

`xm` chooses the candidate with greatest child best-of-eight hit probability. Ties favour lower K and then an earlier checkpoint.

`weak` first restricts the pool to candidates whose child hit is within a prospectively selected fraction of the best child hit. The gate is selected from

```text
0.97, 0.98, 0.99
```

A Part-B-style instrument then ranks those candidates. Its primary freedom coefficient is fixed at one. Nonnegative bounded residual terms refine the operational estimate. Formula-bank size is selected from

```text
48, 120, 240
```

Two independent calibration streams fit and test in opposite directions. The final instrument is frozen before the thirty final parent worlds are evaluated.

## Structural gate

Before final-world evaluation, calibration must show that at least 80 percent of worlds contain two eligible candidates whose measured log freedom differs by at least one.

The run stops when this condition fails. This prevents another saturated candidate pool in which both selectors are forced into the same choice.

## Final selection information

The freedom selector is transductive. It reads output-profile features computed on unlabelled parent contexts, including measured weakness. The child-validation selector reads only child-validation hit. The final selector is barred from the balanced-parent hit endpoint. Parent hit is joined to the selected rows only after both candidate indices are fixed.

In the completed run, the same 240 deployment draws were used to compute the parent-context selector features and the reported parent-hit estimate. A replication intended to remove selection-noise dependence should use separate selector and audit draws.

## Primary result

The primary contrast is

```text
weak parent hit - xm parent hit
```

The parent metric is balanced best-of-eight hit on new contexts. Child hit is reported separately and is not averaged into the parent endpoint.

The full result is positive when the paired mean is above zero, its paired bootstrap interval is above zero, and the exact one-sided paired sign-flip value is at most 0.05.

The primary selectors can choose different K values and checkpoints. The primary endpoint is therefore a common-pool selector comparison. Individually compute-matched comparisons require fixed K and fixed checkpoint.
