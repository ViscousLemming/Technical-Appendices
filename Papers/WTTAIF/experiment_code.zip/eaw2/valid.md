# Validation

I compiled every Python module and every notebook code cell.

The implementation check passed. It verifies the sample-based winner-only XM update, nested candidate draws, the long-tail child law, the balanced parent law, complete child label occurrence, and the final parent-hit endpoint block.

A fresh smoke run completed calibration, instrument fitting, final selection, analysis, figures, and checkpoint recovery.

I also ran the `dev` profile on CPU. Two independent calibration streams each contained three worlds. The selected instrument had structural contrast in every calibration world. Its lower cross-stream parent improvement was `+0.006451`.

Across two disjoint development parent worlds, tuned weakness exceeded child-validation XM by `+0.034446` mean balanced parent hit. The paired child-hit change was `-0.003378`. Parent support increased by `+1.035156` cells and parent log freedom increased by `+0.729972`.

The two-world development check tests direction and implementation. It is not the full result. The `full` profile contains thirty final worlds and must be run before any paper claim is written.

## Completed full-run audit

The completed full run was re-analysed after correcting the small-p sign-flip calculation. The exact one-sided paired sign-flip value for the primary parent-hit contrast is `1.862645149230957e-09`.

The primary freedom selector intentionally reads unlabelled parent-context profile features. It does not read the parent-hit endpoint. The completed result used the same 240 deployment draws for selector features and parent-hit estimation. This dependence is documented in the manuscript and specification.

The selected runs were not individually compute-matched. A post hoc fixed-K, fixed-checkpoint robustness check is included in `results/tabs/matched.csv`.
