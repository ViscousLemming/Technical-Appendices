# EAW2 report

Freedom selection minus child-validation XM on the balanced parent was 0.072239 with paired bootstrap 95% interval [0.066296, 0.076127].
Freedom selection improved 29 of 30 final worlds. The exact one-sided paired sign-flip value was 1.863e-09.

The paired child-hit difference was -0.021698.
The paired parent-support difference was 2.685547.
The paired parent log-freedom difference was 1.877307.

The frozen instrument used formula-bank prefix 240, child-fit gate 0.970, and calibration structural rate 0.917.

The primary comparison was transductive. The freedom selector read output-profile features on 256 unlabelled parent contexts. It was barred from the parent-hit endpoint. The same 240 deployment draws were used for selector features and the reported parent-hit estimate.

The selected individual runs were not compute-matched. Child validation selected K=8 in all 30 worlds. Freedom selected K=16 in 29 worlds and K=8 in one. Mean K x updates was 26,667 for weakness and 18,667 for child validation.

A post hoc matched-setting check averaged the six fixed combinations K in {16,32} and updates in {1250,1875,2500} within each world. Its mean gain was 0.006455, with paired bootstrap 95% interval [0.005798, 0.007079], and was positive in all 30 worlds. Its exact one-sided sign-flip value was 9.313e-10. This check was not predeclared.
