"""EAW1 run plans."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class Job:
    profile: str
    regime: str
    k: int
    rep: int
    width: int
    n_train: int
    n_audit: int
    steps: int
    batch: int
    lr: float
    wd: float
    chunk: int
    ck_every: int
    d_in: int = 8
    n_out: int = 12
    z_dim: int = 12
    probe_n: int = 240
    mode_r: float = 0.64

    def asdict(self):
        return asdict(self)


@dataclass(frozen=True)
class Plan:
    name: str
    jobs: tuple[Job, ...]


def _jobs(name: str, *, reps, ks, steps, width, n_train, n_audit, batch) -> tuple[Job, ...]:
    out = []
    for regime in ("uni", "skew"):
        for rep in reps:
            for k in ks:
                out.append(Job(name, regime, k, rep, width, n_train, n_audit,
                               steps, batch, 1e-3, 1e-5, 8, max(20, steps // 4)))
    return tuple(out)


def get_plan(name: str) -> Plan:
    key = name.lower().strip()
    if key == "smoke":
        return Plan(key, _jobs(key, reps=range(1), ks=(1, 4), steps=60,
                               width=32, n_train=512, n_audit=128, batch=64))
    if key == "core":
        return Plan(key, _jobs(key, reps=range(8), ks=(1, 2, 4, 8, 16, 32),
                               steps=1600, width=96, n_train=8192,
                               n_audit=2048, batch=256))
    if key == "full":
        return Plan(key, _jobs(key, reps=range(12), ks=(1, 2, 4, 8, 16, 32),
                               steps=2500, width=128, n_train=16384,
                               n_audit=4096, batch=384))
    raise ValueError("profile must be smoke, core, or full")


def dirs(root: str | Path, profile: str) -> dict[str, Path]:
    base = Path(root) / "eaw1run" / profile
    out = {k: base / k for k in ("runs", "ckpt", "mods", "tabs", "figs")}
    out["base"] = base
    for p in out.values():
        p.mkdir(parents=True, exist_ok=True)
    return out
