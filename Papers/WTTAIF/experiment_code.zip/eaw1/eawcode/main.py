from __future__ import annotations
import argparse
from check import checks
from run import analyse, run_all


def main():
    p = argparse.ArgumentParser()
    p.add_argument("action", choices=("check", "run", "analyse"))
    p.add_argument("--root", required=True)
    p.add_argument("--profile", default="full")
    p.add_argument("--allow-cpu", action="store_true")
    a = p.parse_args()
    if a.action == "check": checks()
    elif a.action == "run": run_all(a.root, a.profile, a.allow_cpu)
    else: analyse(a.root, a.profile)

if __name__ == "__main__": main()
