"""Fast implementation checks."""
from __future__ import annotations

import torch

from net import GenNet
from xmcore import xm_best_of_k


def checks() -> None:
    torch.manual_seed(7)
    model = GenNet(3, 4, 12, 4, 9)
    x = torch.randn(5, 3)
    y = torch.eye(4)[torch.tensor([0, 1, 2, 3, 0])]

    def wrap(f, c, t, learning=True, rand_inputs=None, rand_seeds=None):
        del rand_seeds
        with torch.set_grad_enabled(learning):
            p = f(c, rand_inputs)
            return (p - t).square().mean(1), p

    loss, pred = xm_best_of_k(model.forward, wrap, x, y, 4, 2, save_mem=True, debug=True)
    if loss.shape != (5,) or pred.shape != (5, 4):
        raise AssertionError("unexpected XM shapes")
    loss.mean().backward()
    if not any(p.grad is not None for p in model.parameters()):
        raise AssertionError("winner-only recompute did not create gradients")
    print("EAW1 checks passed")

if __name__ == "__main__":
    checks()
