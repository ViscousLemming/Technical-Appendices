"""Run, resume, and analyse EAW1."""
from __future__ import annotations

import gc
import hashlib
import json
from dataclasses import asdict
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from cfg import dirs, get_plan
from data import make_data
from metric import evaluate
from train import train
from util import atomic_json, atomic_torch, bootstrap_mean, devinfo, signflip_p

SCHEMA = "eaw1.sample.v1"


def _ident(job) -> str:
    raw = json.dumps(job.asdict(), sort_keys=True).encode()
    return hashlib.sha1(raw).hexdigest()[:12]


def run_all(root: str | Path, profile: str = "full", allow_cpu: bool = False):
    root = Path(root)
    plan = get_plan(profile)
    dd = dirs(root, profile)
    schema = root / "eaw1run" / "cfg.json"
    if schema.exists() and json.loads(schema.read_text()).get("schema") != SCHEMA:
        raise RuntimeError("Earlier eaw1run detected. Rename it before running the sample-based version.")
    atomic_json(schema, {"schema": SCHEMA})
    if not torch.cuda.is_available() and not allow_cpu:
        raise RuntimeError("CUDA is absent. Select a GPU runtime or set allow_cpu=True.")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    atomic_json(dd["base"] / "plan.json", {"schema": SCHEMA, "plan": [j.asdict() for j in plan.jobs], "device": devinfo()})
    done = 0
    for i, job in enumerate(plan.jobs, 1):
        ident = _ident(job)
        rp = dd["runs"] / f"{ident}.json"
        if rp.exists():
            done += 1
            continue
        print(f"[{i}/{len(plan.jobs)}] {job.regime} K={job.k} rep={job.rep}")
        data = make_data(job)
        model, meta = train(job, data, device, dd["ckpt"] / f"{ident}.pt")
        met = evaluate(model, job, data.x_audit, data.p_audit, device)
        atomic_torch(dd["mods"] / f"{ident}.pt", {"job": job.asdict(), "model": model.state_dict()})
        atomic_json(rp, {"schema": SCHEMA, "id": ident, "job": job.asdict(), "train": meta, "metrics": met})
        done += 1
        print(f"  hit8={met['hit8']:.4f} support={met['support']:.2f} logw={met['logw']:.3f}")
        del model
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    return {"done": done, "total": len(plan.jobs), "profile": profile}


def analyse(root: str | Path, profile: str = "full"):
    root = Path(root)
    dd = dirs(root, profile)
    rows = []
    for p in sorted(dd["runs"].glob("*.json")):
        r = json.loads(p.read_text())
        row = {**r["job"], **r["metrics"], "secs": r["train"]["secs"]}
        rows.append(row)
    if not rows:
        raise RuntimeError("No completed jobs")
    df = pd.DataFrame(rows)
    df.to_csv(dd["tabs"] / "all.csv", index=False)
    means = df.groupby(["regime", "k"]).agg(hit8=("hit8", "mean"), support=("support", "mean"),
                                               logw=("logw", "mean"), invalid=("invalid", "mean"),
                                               compat_err=("compat_obs", lambda s: 0.0)).reset_index()
    # Compatibility error needs paired columns.
    tmp = df.copy(); tmp["compat_err"] = (tmp.compat_obs - tmp.compat_pred).abs()
    means = tmp.groupby(["regime", "k"]).agg(hit8=("hit8", "mean"), support=("support", "mean"),
                                                logw=("logw", "mean"), invalid=("invalid", "mean"),
                                                compat_err=("compat_err", "mean"), secs=("secs", "mean")).reset_index()
    means.to_csv(dd["tabs"] / "means.csv", index=False)

    pairs = []
    for regime, group in df.groupby("regime"):
        base = group[group.k == 1].set_index("rep")
        for target_k in sorted(set(group.k) - {1}):
            alt = group[group.k == target_k].set_index("rep")
            ids = base.index.intersection(alt.index)
            if len(ids) == 0:
                continue
            for metric in ("hit8", "support", "logw"):
                delta = alt.loc[ids, metric].to_numpy(float) - base.loc[ids, metric].to_numpy(float)
                mean, lo, hi = bootstrap_mean(delta, 87001 + target_k + 100 * len(pairs))
                pairs.append({
                    "regime": regime, "k": int(target_k), "metric": metric,
                    "delta": mean, "lo": lo, "hi": hi,
                    "positive": int((delta > 0).sum()), "n": int(len(delta)),
                    "p_one": signflip_p(delta),
                })
    pair_df = pd.DataFrame(pairs)
    pair_df.to_csv(dd["tabs"] / "paired.csv", index=False)
    lines = ["# EAW1 report", ""]
    for r in pairs:
        lines.append(
            f"{r['regime']} K={r['k']} minus K=1 for {r['metric']} was "
            f"{r['delta']:.6f} with 95% interval [{r['lo']:.6f}, {r['hi']:.6f}]."
        )
    (dd["base"] / "report.md").write_text("\n".join(lines) + "\n")

    import matplotlib.pyplot as plt
    for metric, label, fname in [("hit8", "Audit best-of-8 hit", "hit.png"),
                                 ("support", "Active output cells", "supp.png"),
                                 ("logw", "Mean log weakness", "weak.png")]:
        fig, ax = plt.subplots(figsize=(6.5, 4.4))
        for regime, g in means.groupby("regime"):
            ax.plot(g.k, g[metric], marker="o", label=regime)
        ax.set_xscale("log", base=2); ax.set_xlabel("Training exploration K"); ax.set_ylabel(label)
        ax.legend(frameon=False); fig.tight_layout(); fig.savefig(dd["figs"] / fname, dpi=180); plt.close(fig)

    return {"rows": len(df), "means": means.to_dict("records"),
            "paired": pair_df.to_dict("records")}
