"""Deployment sampling and weakness measurements."""
from __future__ import annotations

import numpy as np
import torch

from cfg import Job


@torch.no_grad()
def sample_outputs(model, x: torch.Tensor, draws: int, seed: int, device: torch.device,
                   ctx_batch: int = 256, draw_chunk: int = 32) -> torch.Tensor:
    model.eval()
    gen = torch.Generator(device=device.type).manual_seed(seed)
    parts = []
    for s in range(0, len(x), ctx_batch):
        xb = x[s:s + ctx_batch].to(device)
        sub = []
        left = draws
        while left:
            m = min(draw_chunk, left)
            xx = xb.repeat(m, 1)
            z = torch.randn((m * len(xb), model.z.in_features), generator=gen,
                            device=device, dtype=xb.dtype)
            pred = model(xx, z).reshape(m, len(xb), -1).cpu()
            sub.append(pred)
            left -= m
        parts.append(torch.cat(sub, dim=0).transpose(0, 1))
    return torch.cat(parts, dim=0)  # context, draw, output dim


def cells(pred: torch.Tensor, radius: float) -> tuple[torch.Tensor, torch.Tensor]:
    # Squared distance to one-hot prototype j equals ||x||^2 + 1 - 2 x_j.
    d2 = pred.square().sum(-1, keepdim=True) + 1.0 - 2.0 * pred
    dist, lab = d2.min(-1)
    valid = dist <= radius * radius
    return lab, valid


def _logw(a: torch.Tensor) -> torch.Tensor:
    a = a.double()
    # Empty operational profiles are outside the nonempty permission language.
    # They receive the minimum score zero and are reported separately.
    a_eff = a.clamp_min(1.0)
    return torch.log(torch.pow(2.0, a_eff) - 1.0)


def evaluate(model, job: Job, x: torch.Tensor, p: torch.Tensor, device: torch.device) -> dict:
    pred = sample_outputs(model, x, job.probe_n, 800001 + 1009 * job.rep, device)
    lab, valid = cells(pred, job.mode_r)
    n, draws = lab.shape
    counts = torch.zeros((n, job.n_out), dtype=torch.int32)
    counts.scatter_add_(1, lab, valid.to(torch.int32))
    active = counts > 0
    a = active.sum(-1)
    freq = counts.float() / draws
    p64 = p.double()
    q64 = freq.double()
    hit8 = (p64 * (1 - torch.pow(1 - q64, 8))).sum(-1).mean()
    hitk = (p64 * (1 - torch.pow(1 - q64, job.k))).sum(-1).mean()
    invalid = float((~valid).float().mean())

    rng = np.random.default_rng(900001 + job.rep)
    masks = active.numpy().astype(np.uint64)
    bits = (np.uint64(1) << np.arange(job.n_out, dtype=np.uint64))[None]
    allow = (masks * bits).sum(1, dtype=np.uint64)
    demand = rng.integers(1, 1 << job.n_out, size=(n, 32), dtype=np.uint64)
    ok = (demand & (~allow[:, None])) == 0
    pred_compat = np.mean((np.power(2.0, a.numpy()) - 1) / (2.0**job.n_out - 1))

    # Direct candidate-loop check on a fixed target sample.
    mc_n = min(512, n)
    target_gen = torch.Generator(device="cpu").manual_seed(910003 + job.rep)
    target = torch.multinomial(p[:mc_n], 1, replacement=True, generator=target_gen).squeeze(1)
    cand = pred[:mc_n, :job.k]
    d2 = cand.square().sum(-1) + 1 - 2 * cand.gather(2, target[:, None, None].expand(-1, job.k, 1)).squeeze(-1)
    mc_hit = float((d2.min(1).values <= job.mode_r**2).float().mean())

    lw = _logw(a)
    mean_lw = float(lw.mean())
    return {
        "hit8": float(hit8), "hitk": float(hitk), "mc_hit": mc_hit,
        "support": float(a.float().mean()), "support_sd": float(a.float().std()),
        "logw": mean_lw, "empty": float((a == 0).float().mean()),
        "invalid": invalid,
        "compat_pred": float(pred_compat), "compat_obs": float(ok.mean()),
        "probe_n": int(job.probe_n), "radius": float(job.mode_r),
    }
