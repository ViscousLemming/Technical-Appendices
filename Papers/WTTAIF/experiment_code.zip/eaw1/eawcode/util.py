"""Small IO and reproducibility helpers."""
from __future__ import annotations

import json
import os
import random
from pathlib import Path
from typing import Any

import numpy as np
import torch


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed % (2**32 - 1))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def atomic_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True))
    os.replace(tmp, path)


def atomic_torch(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, tmp)
    os.replace(tmp, path)


def devinfo() -> dict[str, Any]:
    return {
        "torch": torch.__version__,
        "cuda": bool(torch.cuda.is_available()),
        "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
    }


def bootstrap_mean(x: np.ndarray, seed: int, draws: int = 20000):
    x = np.asarray(x, float)
    rng = np.random.default_rng(seed)
    sims = x[rng.integers(0, len(x), size=(draws, len(x)))].mean(1)
    return float(x.mean()), float(np.quantile(sims, .025)), float(np.quantile(sims, .975))


def signflip_p(x: np.ndarray) -> float:
    x = np.asarray(x, float)
    n = len(x)
    if n > 24:
        rng = np.random.default_rng(77)
        signs = rng.choice((-1, 1), size=(2_000_000, n))
        return float((np.mean(signs * x, axis=1) >= x.mean() - 1e-15).mean())
    vals = []
    for mask in range(1 << n):
        signs = np.array([1 if mask & (1 << j) else -1 for j in range(n)])
        vals.append(np.mean(signs * x))
    return float(np.mean(np.asarray(vals) >= x.mean() - 1e-15))
