"""Faithful sample-based XM training."""
from __future__ import annotations

import math
import time
from pathlib import Path
from typing import Any

import torch
from torch.nn import functional as F

from cfg import Job
from data import Data
from net import GenNet
from util import atomic_torch, seed_all
from xmcore import xm_best_of_k


def _lr(step: int, total: int, peak: float) -> float:
    warm = max(10, total // 20)
    if step < warm:
        return peak * (step + 1) / warm
    f = (step - warm) / max(1, total - warm)
    return peak * (0.05 + 0.95 * 0.5 * (1 + math.cos(math.pi * f)))


def _loss_wrap(model_forward, conditions, targets, learning=True,
               rand_inputs=None, rand_seeds=None):
    del rand_seeds
    with torch.set_grad_enabled(learning):
        pred = model_forward(conditions, rand_inputs)
        loss = F.mse_loss(pred, targets, reduction="none").mean(dim=1)
        return loss, pred


def train(job: Job, data: Data, device: torch.device, ck: Path) -> tuple[GenNet, dict[str, Any]]:
    init_seed = 420001 + 1009 * job.rep + 31 * job.width
    batch_seed = 430003 + 1013 * job.rep
    # Paired K runs begin from the same candidate RNG state. K changes how
    # many candidates are inspected, rather than adding an unrelated seed.
    cand_seed = 440009 + 1019 * job.rep
    seed_all(init_seed)
    model = GenNet(job.d_in, job.z_dim, job.width, job.n_out, init_seed).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=job.lr, weight_decay=job.wd)
    bgen = torch.Generator(device=device.type).manual_seed(batch_seed)
    start = 0
    hist = []
    secs0 = 0.0
    if ck.exists():
        raw = torch.load(ck, map_location=device, weights_only=False)
        model.load_state_dict(raw["model"])
        opt.load_state_dict(raw["opt"])
        start = int(raw["step"])
        hist = list(raw.get("hist", []))
        secs0 = float(raw.get("secs", 0))
        bgen.set_state(raw["bgen"].cpu())
        torch.set_rng_state(raw["rng"].cpu())
        if torch.cuda.is_available() and raw.get("cuda_rng") is not None:
            torch.cuda.set_rng_state_all(raw["cuda_rng"])
    else:
        seed_all(cand_seed)

    x = data.x_train.to(device)
    y = data.y_train.to(device)
    eye = torch.eye(job.n_out, device=device)
    clock = time.perf_counter()
    model.train()
    for step in range(start, job.steps):
        idx = torch.randint(0, x.shape[0], (job.batch,), generator=bgen, device=device)
        xb = x[idx]
        target = eye[y[idx]]
        loss_vec, _ = xm_best_of_k(
            model.forward, _loss_wrap, xb, target, job.k, job.chunk,
            save_mem=True, no_grad_only=False,
        )
        loss = loss_vec.mean()
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        rate = _lr(step, job.steps, job.lr)
        for g in opt.param_groups:
            g["lr"] = rate
        opt.step()
        if step == start or (step + 1) % max(20, job.steps // 20) == 0:
            hist.append({"step": step + 1, "loss": float(loss.detach()), "lr": rate})
        if (step + 1) % job.ck_every == 0 and step + 1 < job.steps:
            atomic_torch(ck, {
                "step": step + 1, "model": model.state_dict(), "opt": opt.state_dict(),
                "hist": hist, "secs": secs0 + time.perf_counter() - clock,
                "bgen": bgen.get_state(), "rng": torch.get_rng_state(),
                "cuda_rng": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
            })
    if ck.exists():
        ck.unlink()
    return model, {"hist": hist, "secs": secs0 + time.perf_counter() - clock}
