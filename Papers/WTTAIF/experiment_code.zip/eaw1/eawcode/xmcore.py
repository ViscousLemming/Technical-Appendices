"""Sample-based Forward XM candidate selection.

Derived from ``xm_chunked_best_of_k`` in alexiglad/XM at commit
9d06ced61e2d2775a34782eb5830584ae4ef6094. The upstream repository is
Apache-2.0 licensed. The selection semantics are unchanged. K candidate
latents are drawn, each candidate is scored, and only the lowest-loss
candidate is recomputed with gradients when memory-saving mode is active.
"""
from __future__ import annotations

import math
from typing import Any, Callable

import torch


def xm_best_of_k(
    model_forward: Callable[..., torch.Tensor],
    loss_calc: Callable[..., tuple[torch.Tensor, torch.Tensor | None]],
    conditions: Any,
    targets: torch.Tensor,
    best_of_k: int,
    max_chunk_mult: int,
    *,
    save_mem: bool = True,
    no_grad_only: bool = False,
    debug: bool = False,
    **kwargs: Any,
) -> tuple[torch.Tensor, torch.Tensor | None]:
    """Run the authors' sample-based hard best-of-K rule.

    ``targets`` also fixes the shape of the sampled latent tensor, matching the
    image and video code in the upstream implementation.
    """
    if best_of_k < 1:
        raise ValueError("best_of_k must be at least one")
    if max_chunk_mult < 1:
        raise ValueError("max_chunk_mult must be at least one")
    if debug and not save_mem:
        raise ValueError("debug requires save_mem")

    batch = targets.shape[0]
    if best_of_k == 1:
        latent = torch.randn_like(targets)
        seeds = torch.randint(0, 2147483647, (batch,), device=targets.device)
        return loss_calc(
            model_forward,
            conditions,
            targets,
            learning=not no_grad_only,
            rand_inputs=latent,
            rand_seeds=seeds,
            **kwargs,
        )

    if not save_mem and not no_grad_only and max_chunk_mult < best_of_k:
        raise ValueError("save_mem=False requires max_chunk_mult >= best_of_k")

    total = batch * best_of_k
    max_chunk = batch * max_chunk_mult
    remaining = total
    first = True
    track_grad = (not save_mem) and (not no_grad_only)
    best_pred = None

    with torch.set_grad_enabled(track_grad):
        while remaining > 0:
            chunk = min(remaining, max_chunk)
            if chunk % batch:
                raise RuntimeError("candidate chunk must be divisible by batch size")
            remaining -= chunk
            mult = chunk // batch

            latent = torch.randn((chunk, *targets.shape[1:]), device=targets.device, dtype=targets.dtype)
            seeds = torch.randint(0, 2147483647, (chunk,), device=targets.device)

            if isinstance(conditions, tuple):
                c_exp = tuple(torch.cat([c] * mult, dim=0) for c in conditions)
            else:
                c_exp = torch.cat([conditions] * mult, dim=0)
            t_exp = torch.cat([targets] * mult, dim=0)

            losses, pred = loss_calc(
                model_forward,
                c_exp,
                t_exp,
                learning=track_grad,
                rand_inputs=latent,
                rand_seeds=seeds,
                **kwargs,
            )
            lr = losses.reshape(mult, batch)
            chunk_loss, chunk_idx = lr.min(dim=0)
            flat = chunk_idx * batch + torch.arange(batch, device=targets.device)
            chunk_latent = latent[flat]
            chunk_seeds = seeds[flat]
            chunk_pred = pred[flat] if pred is not None else None

            if first:
                first = False
                best_loss = chunk_loss
                best_latent = chunk_latent
                best_seeds = chunk_seeds
                if chunk_pred is not None:
                    best_pred = chunk_pred
            else:
                mask = chunk_loss < best_loss
                if mask.any():
                    best_loss[mask] = chunk_loss[mask]
                    best_latent[mask] = chunk_latent[mask]
                    best_seeds[mask] = chunk_seeds[mask]
                    if best_pred is not None and chunk_pred is not None:
                        best_pred[mask] = chunk_pred[mask]

    if save_mem:
        torch.clear_autocast_cache()
        final_loss, final_pred = loss_calc(
            model_forward,
            conditions,
            targets,
            learning=not no_grad_only,
            rand_inputs=best_latent,
            rand_seeds=best_seeds,
            **kwargs,
        )
        if debug:
            if best_pred is not None and final_pred is not None:
                if not torch.allclose(best_pred, final_pred, rtol=1e-5, atol=1e-8):
                    raise AssertionError("winner prediction did not reproduce")
            if not torch.allclose(best_loss, final_loss, rtol=1e-5, atol=1e-8):
                raise AssertionError("winner loss did not reproduce")
        return final_loss, final_pred

    return best_loss, best_pred
