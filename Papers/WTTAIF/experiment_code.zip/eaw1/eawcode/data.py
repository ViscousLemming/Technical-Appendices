"""Paired synthetic target laws."""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import torch

from cfg import Job


@dataclass(frozen=True)
class Data:
    x_train: torch.Tensor
    y_train: torch.Tensor
    x_audit: torch.Tensor
    p_audit: torch.Tensor


def _teacher(x: np.ndarray, n_out: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    w = rng.normal(scale=0.65, size=(x.shape[1], n_out))
    b = rng.normal(scale=0.25, size=(n_out,))
    logits = (x @ w + b) / 0.8
    logits -= logits.max(axis=1, keepdims=True)
    q = np.exp(logits)
    q /= q.sum(axis=1, keepdims=True)
    q = 0.90 * q + 0.10 / n_out
    return q


def make_data(job: Job) -> Data:
    seed = 120001 + 1009 * job.rep
    rng = np.random.default_rng(seed)
    x_train = rng.normal(size=(job.n_train, job.d_in)).astype(np.float32)
    x_audit = rng.normal(size=(job.n_audit, job.d_in)).astype(np.float32)
    if job.regime == "uni":
        p_train = np.full((job.n_train, job.n_out), 1 / job.n_out, np.float64)
        p_audit = np.full((job.n_audit, job.n_out), 1 / job.n_out, np.float64)
    else:
        p_train = _teacher(x_train, job.n_out, seed + 17)
        p_audit = _teacher(x_audit, job.n_out, seed + 17)
    y = np.asarray([rng.choice(job.n_out, p=row) for row in p_train], dtype=np.int64)
    return Data(torch.from_numpy(x_train), torch.from_numpy(y),
                torch.from_numpy(x_audit), torch.from_numpy(p_audit.astype(np.float32)))
