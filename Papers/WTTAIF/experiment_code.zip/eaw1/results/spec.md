# EAW1

## Question

Does the authors' sample-based Forward XM update turn a larger candidate count into a broader deployed output profile and greater weakness?

## Implementation

A latent-conditioned generator receives a context and Gaussian latent. Each datum is a one-hot output prototype. At every update, the code draws K latent candidates, computes K reconstruction losses, keeps the lowest-loss candidate, and recomputes only that candidate with gradients. The candidate loop follows `xm_chunked_best_of_k` from the public XM repository at commit `9d06ced61e2d2775a34782eb5830584ae4ef6094`.

The earlier analytic loss `(1-q_y)^K` is absent.

## Weakness

Deployment draws 240 latents at each audit context. A generation occupies output cell j when it falls within a fixed radius of one-hot prototype j. The active cell set is the deployed permission profile. For a context with $a$ active cells, the local extension factor is

\[
2^a-1.
\]

The primary statistic is mean log weakness across audit contexts. An empty operational profile is outside the nonempty permission language, so it receives the minimum score zero and its frequency is reported separately.

## Pairing

Within each repetition, every K uses the same dataset, target law, model initialisation, and minibatch stream. Candidate latent streams differ because K changes how many draws each update inspects.

## Profiles

`smoke` checks the route. `core` runs eight paired repetitions. `full` runs twelve paired repetitions for K in 1, 2, 4, 8, 16, and 32 under uniform and context-dependent target laws.

## Status

This package replaces the earlier analytic EAW1 implementation. Results from the analytic implementation are not imported. The sample-based full profile completed 144 runs. Its tables and report are stored under `results`.
