# Validation

- Every Python module compiles.
- Every notebook code cell parses.
- The implementation check draws K latent candidates and confirms winner-only gradient recomputation.
- A complete CPU smoke run finished all uniform and nonuniform jobs, wrote restart state, metrics, tables, and figures.
- The completed full profile contains 144 result rows. The accompanying verifier checks every manuscript value against those rows.
- I did not rerun the full GPU cohort in this container.
- Earlier EAW1 numbers from the analytic categorical objective are excluded.
