# EAW1

Extract this folder to

```text
/content/drive/MyDrive/weakness_experiments/eaw1
```

Open `eaw1.ipynb` in Colab. Run `smoke`, then `full`. Results are written after each job to

```text
/content/drive/MyDrive/weakness_experiments/eaw1run
```

An earlier `eaw1run` with another schema must be renamed before this version starts.
