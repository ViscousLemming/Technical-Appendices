#!/usr/bin/env python3
"""Recompute the EAW1 and EAW2 numerical claims used in paper.tex."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata

ROOT = Path(__file__).resolve().parent


def close(actual: float, expected: float, tol: float = 5e-7, name: str = "value") -> None:
    if not np.isclose(actual, expected, rtol=0.0, atol=tol):
        raise AssertionError(f"{name}: {actual} != {expected}")


def bootstrap_mean(x: np.ndarray, seed: int, draws: int) -> tuple[float, float, float]:
    x = np.asarray(x, float)
    rng = np.random.default_rng(seed)
    sims = x[rng.integers(0, len(x), size=(draws, len(x)))].mean(axis=1)
    return float(x.mean()), float(np.quantile(sims, 0.025)), float(np.quantile(sims, 0.975))


def subset_sums(values: np.ndarray) -> np.ndarray:
    out = np.array([0.0], dtype=np.float64)
    for value in values:
        out = np.concatenate((out, out + value))
    return out


def exact_signflip(x: np.ndarray) -> float:
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    x = x[np.abs(x) > 1e-15]
    n = len(x)
    if n == 0:
        return 1.0
    left = subset_sums(x[: n // 2])
    right = np.sort(subset_sums(x[n // 2 :]))
    threshold = 0.5 * n * 1e-15
    count = sum(int(np.searchsorted(right, threshold - value, side="right")) for value in left)
    return float(count / (2**n))


def rank_pct(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, float)
    if len(x) <= 1:
        return np.zeros_like(x)
    return (rankdata(x, method="average") - 1.0) / (len(x) - 1.0)


def eligible(frame: pd.DataFrame, gate: float) -> pd.DataFrame:
    cut = float(frame.child_hit.max()) * gate
    out = frame[frame.child_hit >= cut - 1e-12].copy()
    return out if len(out) else frame.loc[[frame.child_hit.idxmax()]].copy()


def predict_one(raw: dict, frame: pd.DataFrame) -> np.ndarray:
    probe_n = int(raw["probe_n"])
    primary = (frame[f"primary_{probe_n}"].to_numpy(float) - float(raw["p_mean"])) / max(float(raw["p_sd"]), 1e-8)
    cols = list(raw["cols"])
    if not cols:
        return primary
    x = (frame[cols].to_numpy(float) - np.asarray(raw["x_mean"], float)) / np.asarray(raw["x_sd"], float)
    residual = x @ np.asarray(raw["coef"], float) + float(raw["intercept"])
    cap = max(float(raw["cap"]), 1e-6)
    return primary + cap * np.tanh(residual / cap)


def predict(spec: dict, frame: pd.DataFrame) -> np.ndarray:
    values = [rank_pct(predict_one(raw, frame)) for raw in spec["fits"]]
    return np.mean(np.stack(values), axis=0)


def check_eaw1() -> None:
    data = pd.read_csv(ROOT / "eaw1" / "results" / "tabs" / "all.csv")
    if len(data) != 144:
        raise AssertionError(f"EAW1 row count {len(data)}")
    means = data.groupby(["regime", "k"])[["hit8", "support", "logw"]].mean()

    expected = {
        ("uni", 1): (0.0, 0.0, 0.0),
        ("uni", 8): (0.34246238100102083, 11.998738606770834, 8.316647357056643),
        ("uni", 32): (0.4408171975244029, 12.0, 8.31752199628717),
        ("skew", 1): (0.319796183821428, 0.57281494140625, 0.00017881059385874184),
        ("skew", 8): (0.7111962663442287, 7.274759928385417, 5.0295220917052745),
        ("skew", 32): (0.6488696336336169, 11.843648274739584, 8.209100699476622),
    }
    for key, vals in expected.items():
        actual = means.loc[key].to_numpy(float)
        if not np.allclose(actual, vals, rtol=0.0, atol=5e-10):
            raise AssertionError(f"EAW1 means {key}: {actual} != {vals}")

    paired = pd.read_csv(ROOT / "eaw1" / "results" / "tabs" / "paired.csv")
    claims = {
        ("uni", 8, "logw"): (8.316647357056642, 8.316280572863198, 8.316957712912636),
        ("skew", 8, "logw"): (5.029343281111416, 4.9534040346289165, 5.112624579941602),
        ("skew", 32, "logw"): (8.208921888882765, 8.19835824077446, 8.220584278532888),
    }
    for key, vals in claims.items():
        row = paired[(paired.regime == key[0]) & (paired.k == key[1]) & (paired.metric == key[2])].iloc[0]
        for col, expected_value in zip(("delta", "lo", "hi"), vals):
            close(float(row[col]), expected_value, 5e-12, f"EAW1 {key} {col}")

    error = np.abs(data.compat_obs.to_numpy(float) - data.compat_pred.to_numpy(float))
    close(float(error.mean()), 0.00020630868444156125, 5e-12, "EAW1 compatibility mean error")
    close(float(error.max()), 0.002185306386050967, 5e-12, "EAW1 compatibility max error")

    # Direction statements.
    for regime, first_k in (("uni", 4), ("skew", 2)):
        base = data[(data.regime == regime) & (data.k == 1)].set_index("rep")
        for k in sorted(v for v in data[data.regime == regime].k.unique() if v >= first_k):
            alt = data[(data.regime == regime) & (data.k == k)].set_index("rep")
            delta = alt.logw - base.logw
            if not np.all(delta.to_numpy() > 0):
                raise AssertionError(f"EAW1 direction failed for {regime} K={k}")


def check_eaw2() -> None:
    base = ROOT / "eaw2" / "results"
    final = pd.read_csv(base / "tabs" / "final.csv")
    if final.rep.nunique() != 30 or set(final.selector) != {"xm", "weak"}:
        raise AssertionError("EAW2 final rows incomplete")

    means = final.groupby("selector")[["parent_hit", "child_hit", "parent_supp", "parent_logw", "k_train", "step"]].mean()
    expected = {
        "xm": (0.3169423757160972, 0.7871594319120231, 5.84609375, 4.033112114862368, 8.0, 2333.3333333333335),
        "weak": (0.3891812635172514, 0.7654615997804743, 8.531640625, 5.9104193367146785, 15.733333333333333, 1708.3333333333333),
    }
    for selector, vals in expected.items():
        actual = means.loc[selector].to_numpy(float)
        if not np.allclose(actual, vals, rtol=0.0, atol=5e-12):
            raise AssertionError(f"EAW2 means {selector}: {actual} != {vals}")

    pivot = final.pivot(index="rep", columns="selector")
    parent_delta = (pivot.parent_hit.weak - pivot.parent_hit.xm).to_numpy(float)
    child_delta = (pivot.child_hit.weak - pivot.child_hit.xm).to_numpy(float)
    supp_delta = (pivot.parent_supp.weak - pivot.parent_supp.xm).to_numpy(float)
    logw_delta = (pivot.parent_logw.weak - pivot.parent_logw.xm).to_numpy(float)

    main = bootstrap_mean(parent_delta, 82001, 20000)
    for actual, expected_value, name in zip(main, (0.0722388878011543, 0.06629567398660699, 0.07612724687856949), ("mean", "lo", "hi")):
        close(actual, expected_value, 5e-12, f"EAW2 parent {name}")
    if int((parent_delta > 0).sum()) != 29 or int((parent_delta < 0).sum()) != 1:
        raise AssertionError("EAW2 win count")
    close(exact_signflip(parent_delta), 1.862645149230957e-09, 1e-18, "EAW2 exact sign-flip")
    close(float(child_delta.mean()), -0.021697832131548727, 5e-12, "EAW2 child delta")
    close(float(supp_delta.mean()), 2.685546875, 5e-12, "EAW2 support delta")
    close(float(logw_delta.mean()), 1.87730722185231, 5e-12, "EAW2 log freedom delta")

    if not np.all(pivot.k_train.xm.to_numpy() == 8):
        raise AssertionError("child-validation K choices")
    if int((pivot.k_train.weak.to_numpy() == 16).sum()) != 29 or int((pivot.k_train.weak.to_numpy() == 8).sum()) != 1:
        raise AssertionError("freedom K choices")
    candidate_units = final.assign(candidate_units=final.k_train * final.step).groupby("selector").candidate_units.mean()
    close(float(candidate_units.xm), 18666.666666666668, 5e-9, "XM candidate units")
    close(float(candidate_units.weak), 26666.666666666668, 5e-9, "freedom candidate units")

    instrument = json.loads((base / "inst" / "inst.json").read_text())["weak"]
    matched = []
    for rep in range(30):
        frame = pd.read_csv(base / "final" / f"s2-w{rep}.csv")
        gains = []
        for k in (16, 32):
            for step in (1250, 1875, 2500):
                group = frame[(frame.k_train == k) & (frame.step == step)]
                xm_idx = group.child_hit.idxmax()
                pool = eligible(group, float(instrument["gate"]))
                score = predict(instrument, pool)
                weak_idx = pool.index[int(np.argmax(score))]
                gains.append(float(group.loc[weak_idx, "parent_hit"] - group.loc[xm_idx, "parent_hit"]))
        matched.append(float(np.mean(gains)))
    matched = np.asarray(matched)
    matched_ci = bootstrap_mean(matched, 93017, 200000)
    for actual, expected_value, name in zip(matched_ci, (0.0064545056994777155, 0.00579801796440127, 0.007078872834887119), ("mean", "lo", "hi")):
        close(actual, expected_value, 5e-12, f"matched {name}")
    if int((matched > 0).sum()) != 30:
        raise AssertionError("matched direction")
    close(exact_signflip(matched), 9.313225746154785e-10, 1e-18, "matched sign-flip")


def main() -> None:
    check_eaw1()
    check_eaw2()
    print("All EAW1 and EAW2 manuscript claims passed.")


if __name__ == "__main__":
    main()
