#!/usr/bin/env python3
"""Locked recurrent PPO test using literal binary K_rho."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from dataclasses import asdict
from pathlib import Path

for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ.setdefault(key, "1")

import numpy as np
import pandas as pd
import torch

from env import InputBank, World, action_values, binary_terms, estimate_post, estimate_q, input_hash, layout, make_bank
from net import NetSpec, RNet
from ppo import TrainCfg
from quant import Quant, encode, fit_frame, fit_quant, fit_quant_frame, geometry_receipt, permute_codes


torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.backends.mkldnn.enabled = False


def allocations(states: int) -> list[tuple[int, int]]:
    if states != 6:
        raise ValueError("frozen protocol uses six categorical states")
    return [(5, 1), (4, 2), (3, 3), (2, 4), (1, 5)]


def make_world(seed: int, classes: int = 4, gates: int = 3, cues: int = 3, distractors: int = 5) -> World:
    if classes != 4 or gates != 3:
        raise ValueError("protocol uses four latent classes and three binary tests")
    rng = np.random.default_rng(int(seed))
    qh = float(rng.uniform(0.87, 0.96))
    ql = float(rng.uniform(0.27, 0.38))
    hf = float(rng.uniform(0.08, 0.16))

    base = np.asarray(
        [
            [0, 0, 1, 1],
            [0, 1, 0, 1],
            [0, 1, 1, 0],
        ],
        dtype=np.int64,
    )
    tests = base[rng.permutation(gates)][:, rng.permutation(classes)]
    tests = np.bitwise_xor(tests, rng.integers(0, 2, size=(gates, 1), dtype=np.int64))
    if not np.all(tests.sum(axis=1) == classes // 2):
        raise RuntimeError("binary tests must be balanced")
    answer_vectors = {tuple(tests[:, g].tolist()) for g in range(classes)}
    if len(answer_vectors) != classes:
        raise RuntimeError("test answers must distinguish all latent classes")
    return World(classes, gates, cues, distractors, qh, ql, hf, tests)


def specs(seed: int, hidden: int, lr: float, ent: float) -> list[NetSpec]:
    out: list[NetSpec] = []
    idx = 0
    for arch in ("gru", "lstm"):
        for focus in ("nat", "hi", "lo"):
            out.append(NetSpec(arch, focus, hidden, int(seed + 101 * idx + 17), lr, ent))
            idx += 1
    return out


def load_state(obs_dim: int, actions: int, spec: NetSpec, state: dict) -> RNet:
    model = RNet(obs_dim, actions, spec)
    model.load_state_dict(state)
    model.eval()
    return model


def run_model(model: RNet, bank: InputBank) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return one pre-test memory state and actor probabilities at each test."""
    with torch.no_grad():
        logits, _value, hidden = model.unroll(torch.from_numpy(bank.obs))
        probs = torch.softmax(logits, dim=2).numpy()
        hidden = hidden.numpy()
    n = len(bank.obs)
    gates = int(bank.gate_id.max()) + 1
    memory = np.empty((n, 1, hidden.shape[-1]), dtype=np.float64)
    gate_probs = np.empty((n, gates, probs.shape[-1]), dtype=np.float64)
    for i in range(n):
        gate_times = np.flatnonzero(bank.gate_id[i] >= 0)
        if len(gate_times) != gates or int(gate_times[0]) < 1:
            raise RuntimeError("invalid test layout")
        memory[i, 0] = hidden[i, int(gate_times[0]) - 1]
        for j in range(gates):
            t = int(np.flatnonzero(bank.gate_id[i] == j)[0])
            gate_probs[i, j] = probs[i, t]
    return memory, gate_probs, probs


def repeat_codes(code: np.ndarray, gates: int) -> np.ndarray:
    code = np.asarray(code, dtype=np.int64)
    if code.ndim != 2 or code.shape[1] != 1:
        raise ValueError("expected one pre-test code per episode")
    return np.repeat(code, int(gates), axis=1)


def cell_scores(codes: np.ndarray, values: np.ndarray) -> dict:
    """Compute literal binary K_rho and unweighted cell impurity."""
    codes = np.asarray(codes, dtype=np.int64)
    y, rho = binary_terms(values)
    if codes.shape != y.shape:
        raise ValueError("code shape mismatch")
    ksum = 0.0
    isum = 0.0
    cells = 0
    for j in range(y.shape[1]):
        for code in np.unique(codes[:, j]):
            ids = np.flatnonzero(codes[:, j] == code)
            mass = np.bincount(y[ids, j], weights=rho[ids, j], minlength=2)
            freq = np.bincount(y[ids, j], minlength=2)
            ksum += float(np.min(mass))
            isum += float(np.min(freq))
            cells += 1
    den = float(y.size)
    return {"krho": ksum / den, "imp": isum / den, "cells": cells, "rho": float(rho.mean())}


def make_policy(codes: np.ndarray, values: np.ndarray, states: int, weighted: bool) -> np.ndarray:
    """Fit one cellwise binary policy using weighted or unweighted votes."""
    codes = np.asarray(codes, dtype=np.int64)
    y, rho = binary_terms(values)
    pol = np.zeros((y.shape[1], states), dtype=np.int64)
    for j in range(y.shape[1]):
        w = rho[:, j] if weighted else None
        pol[j, :] = int(np.argmax(np.bincount(y[:, j], weights=w, minlength=2)))
        for code in np.unique(codes[:, j]):
            ids = np.flatnonzero(codes[:, j] == code)
            w = rho[ids, j] if weighted else None
            mass = np.bincount(y[ids, j], weights=w, minlength=2)
            pol[j, int(code)] = int(np.argmax(mass))
    return pol


def eval_policy(codes: np.ndarray, policy: np.ndarray, values: np.ndarray, correct: np.ndarray | None = None) -> dict:
    """Evaluate one policy and verify binary weighted-error identity."""
    codes = np.asarray(codes, dtype=np.int64)
    y, rho = binary_terms(values)
    acts = np.stack([policy[j, codes[:, j]] for j in range(codes.shape[1])], axis=1)
    regret = float(np.mean(rho * (acts != y)))
    got = values[np.arange(len(codes))[:, None], np.arange(values.shape[1])[None, :], acts]
    vmax = values.max(axis=2)
    direct = float(np.mean(1.0 - got / np.maximum(vmax, 1e-12)))
    if not np.isclose(regret, direct, atol=2e-12, rtol=2e-12):
        raise RuntimeError("binary weighted error differs from normalised regret")
    score = cell_scores(codes, values)
    out = {
        "ret": float(got.mean()),
        "regret": regret,
        "acc": float((acts == y).mean()),
        "krho": score["krho"],
        "exec": regret - score["krho"],
        "imp": score["imp"],
        "cells": score["cells"],
        "rho": score["rho"],
    }
    if correct is not None:
        out["hit"] = float((acts == np.asarray(correct, dtype=np.int64)).mean())
    return out


def native_scores(gate_probs: np.ndarray, values: np.ndarray, codes: np.ndarray, correct: np.ndarray | None = None) -> dict:
    gate_probs = np.asarray(gate_probs, dtype=np.float64)
    got = (gate_probs * values).sum(axis=2)
    vmax = values.max(axis=2)
    score = cell_scores(codes, values)
    out = {
        "ret": float(got.mean()),
        "regret": float(np.mean(1.0 - got / np.maximum(vmax, 1e-12))),
        "acc": float((gate_probs.argmax(2) == values.argmax(2)).mean()),
        "krho": score["krho"],
    }
    out["exec"] = out["regret"] - score["krho"]
    if correct is not None:
        idx = np.asarray(correct, dtype=np.int64)
        out["hit"] = float(
            gate_probs[
                np.arange(len(gate_probs))[:, None],
                np.arange(gate_probs.shape[1])[None, :],
                idx,
            ].mean()
        )
    return out


def lock_hash(obj: dict) -> str:
    text = json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(text.encode()).hexdigest()


def quant_dict(q: Quant) -> dict:
    return {
        "schema": "riwf.quant.affine_row.v1",
        "frame_rule": q.frame_rule,
        "canonical_decimals": int(q.canonical_decimals),
        "origin": q.origin.tolist(),
        "basis": q.basis.tolist(),
        "coord_mean": q.coord_mean.tolist(),
        "coord_scale": q.coord_scale.tolist(),
        "basis_rows": q.basis_rows.tolist(),
        "hi": q.hi.tolist(),
        "lo": q.lo.tolist(),
        "sha256": q.sha,
    }


def quant_from(data: dict) -> Quant:
    if data.get("schema") != "riwf.quant.affine_row.v1":
        raise RuntimeError("unsupported quantiser geometry")
    value = Quant(
        np.asarray(data["origin"], dtype=np.float64),
        np.asarray(data["basis"], dtype=np.float64),
        np.asarray(data["coord_mean"], dtype=np.float64),
        np.asarray(data["coord_scale"], dtype=np.float64),
        np.asarray(data["basis_rows"], dtype=np.int64),
        np.asarray(data["hi"], dtype=np.float64),
        np.asarray(data["lo"], dtype=np.float64),
        str(data["frame_rule"]),
        int(data["canonical_decimals"]),
    )
    if value.sha != data.get("sha256"):
        raise RuntimeError("quantiser hash mismatch")
    return value


def load_input(path: Path) -> InputBank:
    with np.load(path, allow_pickle=False) as z:
        expected = {"obs", "valid", "gate", "gate_id", "regime", "cues", "delays", "lengths", "seed"}
        if set(z.files) != expected:
            raise RuntimeError("input archive contains outcome fields")
        return InputBank(
            z["obs"], z["valid"], z["gate"], z["gate_id"], z["regime"],
            z["cues"], z["delays"], z["lengths"], int(z["seed"][0]),
        )


def write_input(root: Path, world_file: Path, path: Path, n: int, seed: int, delays: list[int]) -> InputBank:
    subprocess.run(
        [
            sys.executable,
            str(root / "mkinput.py"),
            "--world", str(world_file),
            "--out", str(path),
            "--n", str(n),
            "--seed", str(seed),
            "--delays", *[str(x) for x in delays],
        ],
        check=True,
        cwd=root,
    )
    return load_input(path)


def phase_a(args, wid: int, out: Path):
    root = Path(__file__).resolve().parent
    wseed = int(args.seed + wid * 100003)
    world = make_world(wseed, args.classes, args.gates, args.cues, args.distractors)
    lay = layout(world.classes, world.distractors, world.gates)

    src_fit = make_bank(world, args.train_n, args.src, wseed + 1)
    src_cal = make_bank(world, args.cal_n, args.src, wseed + 2)
    src_val = make_bank(world, args.val_n, args.src, wseed + 3)
    qhhat, qlhat = estimate_q(src_cal)

    world_file = out / f"wp{wid:02d}.json"
    world_file.write_text(
        json.dumps(
            {
                "classes": world.classes,
                "gates": world.gates,
                "cues": world.cues,
                "distractors": world.distractors,
                "q_high": world.q_high,
                "q_low": world.q_low,
                "high_frac": world.high_frac,
                "tests": world.tests.tolist(),
            },
            sort_keys=True,
        )
        + "\n"
    )

    panel_seed = wseed + 4
    panel_path = out / f"ti{wid:02d}.npz"
    panel_in = write_input(root, world_file, panel_path, args.panel_n, panel_seed, args.tgt)
    panel_hash = input_hash(panel_in)

    # Source policies are fitted on src_fit and evaluated on independent src_val.
    # q is estimated only from src_cal labels. Admission uses empirical source
    # reward on src_val, never the analytic source posterior.
    fit_hat = action_values(estimate_post(src_fit.inputs, qhhat, qlhat, world.classes), world.tests)
    val_hat = action_values(estimate_post(src_val.inputs, qhhat, qlhat, world.classes), world.tests)
    panel_hat = action_values(estimate_post(panel_in, qhhat, qlhat, world.classes), world.tests)

    cfg = TrainCfg(
        updates=args.updates,
        episodes=args.episodes,
        epochs=args.epochs,
        minibatch=args.minibatch,
    )
    rows: list[dict] = []
    artifacts: list[dict] = []
    model_states: list[dict] = []
    cid = 0
    spec_list = specs(wseed + 1000, args.hidden, args.lr, args.ent)
    for bid, spec in enumerate(spec_list):
        tmp = out / f"tb{wid:02d}{bid}.pt"
        subprocess.run(
            [
                sys.executable, str(root / "train.py"),
                "--world", str(world_file),
                "--out", str(tmp),
                "--arch", spec.arch,
                "--focus", spec.focus,
                "--hidden", str(spec.hidden),
                "--seed", str(spec.seed),
                "--lr", str(spec.lr),
                "--ent", str(spec.ent),
                "--obs", str(lay.dim),
                "--base", str(wseed + 5000 + bid * 37),
                "--updates", str(cfg.updates),
                "--episodes", str(cfg.episodes),
                "--epochs", str(cfg.epochs),
                "--minibatch", str(cfg.minibatch),
                "--delays", *[str(x) for x in args.src],
                "--snaps", *[str(x) for x in args.snap],
            ],
            check=True,
            cwd=root,
        )
        trained = torch.load(tmp, map_location="cpu", weights_only=False)
        tmp.unlink(missing_ok=True)
        snapshots = trained["snaps"]
        train_meta = trained["meta"]
        for snap in args.snap:
            state = snapshots[int(snap)]
            model = load_state(lay.dim, world.actions, spec, state)
            fit_h, _fit_p, _ = run_model(model, src_fit.inputs)
            val_h, val_p, _ = run_model(model, src_val.inputs)
            panel_h, panel_p, _ = run_model(model, panel_in)
            model_id = len(model_states)
            model_states.append({"spec": asdict(spec), "snap": int(snap), "state": state, "train": train_meta})
            frame = fit_frame(fit_h)
            for khi, klo in allocations(args.states):
                quant = fit_quant_frame(frame, src_fit.inputs.regime, khi, klo, spec.seed + int(snap) * 13 + khi)
                fit_codes = repeat_codes(encode(quant, fit_h, src_fit.inputs.regime), world.gates)
                src_codes = repeat_codes(encode(quant, val_h, src_val.inputs.regime), world.gates)
                panel_codes = repeat_codes(encode(quant, panel_h, panel_in.regime), world.gates)
                src_score = cell_scores(src_codes, val_hat)
                panel_score = cell_scores(panel_codes, panel_hat)
                src_pol = make_policy(fit_codes, fit_hat, quant.states, True)
                panel_pol = make_policy(panel_codes, panel_hat, quant.states, True)
                raw_pol = make_policy(panel_codes, panel_hat, quant.states, False)
                src_eval = eval_policy(src_codes, src_pol, val_hat, src_val.correct)
                native = native_scores(val_p, val_hat, src_codes, src_val.correct)
                rows.append(
                    {
                        "world": wid,
                        "candidate": cid,
                        "model_id": model_id,
                        "base": bid,
                        "arch": spec.arch,
                        "focus": spec.focus,
                        "seed": spec.seed,
                        "snap": int(snap),
                        "khi": khi,
                        "klo": klo,
                        "states": khi + klo,
                        "train_ret": train_meta["train_return"],
                        "train_loss": train_meta["loss"],
                        "src_ret": src_eval["ret"],
                        "src_reg": src_eval["regret"],
                        "src_acc": src_eval["acc"],
                        "src_hit": src_eval["hit"],
                        "native_src_ret": native["ret"],
                        "native_src_reg": native["regret"],
                        "native_src_hit": native["hit"],
                        "src_k": src_score["krho"],
                        "src_imp": src_score["imp"],
                        "bt_k": panel_score["krho"],
                        "bt_imp": panel_score["imp"],
                        "src_cells": src_score["cells"],
                        "bt_cells": panel_score["cells"],
                        "src_rho": src_score["rho"],
                        "bt_rho": panel_score["rho"],
                    }
                )
                artifacts.append(
                    {
                        "candidate": cid,
                        "model_id": model_id,
                        "quant": quant_dict(quant),
                        "src_pol": src_pol.tolist(),
                        "panel_pol": panel_pol.tolist(),
                        "raw_pol": raw_pol.tolist(),
                        "fit_codes": fit_codes,
                        "src_codes": src_codes,
                        "panel_codes": panel_codes,
                        "panel_probs": panel_p,
                    }
                )
                cid += 1
        print(
            f"world {wid} base {bid + 1}/{len(spec_list)} {spec.name} train={train_meta['train_return']:.4f}",
            flush=True,
        )

    pre = pd.DataFrame(rows)
    best = float(pre.src_hit.max())
    admitted = pre[pre.src_hit >= best - args.band].copy()
    if len(admitted) < args.min_admit:
        admitted = pre.nlargest(args.min_admit, "src_hit").copy()
    rr = np.random.default_rng(wseed + 99991)
    selectors = {
        "kbt": int(admitted.sort_values(["bt_k", "src_hit", "src_reg"], ascending=[True, False, True]).iloc[0].candidate),
        "raw": int(admitted.sort_values(["bt_imp", "src_hit", "src_reg"], ascending=[True, False, True]).iloc[0].candidate),
        "kb": int(admitted.sort_values(["src_k", "src_hit", "src_reg"], ascending=[True, False, True]).iloc[0].candidate),
        "val": int(admitted.sort_values(["src_hit", "src_reg", "src_k"], ascending=[False, True, True]).iloc[0].candidate),
        "rand": int(rr.choice(admitted.candidate.to_numpy())),
    }

    eval_seed = wseed + 5
    lock = {
        "schema": "riwf-kbin-lock-v3",
        "quantity": "literal_binary_K_rho",
        "representation_geometry": geometry_receipt(),
        "world": wid,
        "world_seed": wseed,
        "world_params": {
            "classes": world.classes,
            "gates": world.gates,
            "cues": world.cues,
            "distractors": world.distractors,
            "q_high": world.q_high,
            "q_low": world.q_low,
            "high_frac": world.high_frac,
            "tests": world.tests.tolist(),
        },
        "qhat": [qhhat, qlhat],
        "qerr": [abs(qhhat - world.q_high), abs(qlhat - world.q_low)],
        "calibration_n": int(args.cal_n),
        "source_policy_fit_seed": wseed + 1,
        "source_policy_eval_seed": wseed + 3,
        "source_admission_metric": "empirical mean reward on independent source validation histories",
        "memory_time": "immediately_before_first_test",
        "one_code_reused_for_all_tests": True,
        "representation_states": int(args.states),
        "panel_seed": panel_seed,
        "panel_input_hash": panel_hash,
        "eval_seed": eval_seed,
        "evaluation": "fresh target histories drawn after selector and policy lock",
        "target_truth_fields_available": [],
        "admitted": admitted.candidate.astype(int).tolist(),
        "selectors": selectors,
        "pre": pre.to_dict(orient="records"),
        "policies": {
            str(art["candidate"]): {
                "source": art["src_pol"],
                "panel": art["panel_pol"],
                "raw": art["raw_pol"],
            }
            for art in artifacts
        },
    }
    lock["sha256"] = lock_hash(lock)
    lock_path = out / f"lk{wid:02d}.json"
    lock_path.write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n")
    torch.save({"models": model_states, "artifacts": artifacts}, out / f"st{wid:02d}.pt")
    pre.to_csv(out / f"pr{wid:02d}.csv", index=False)
    return world, pre, model_states, artifacts, lock, world_file


def phase_b(
    args,
    world: World,
    pre: pd.DataFrame,
    model_states: list[dict],
    artifacts: list[dict],
    lock: dict,
    world_file: Path,
    out: Path,
):
    root = Path(__file__).resolve().parent
    eval_path = out / f"ei{int(lock['world']):02d}.npz"
    eval_in = write_input(root, world_file, eval_path, args.eval_n, int(lock["eval_seed"]), args.tgt)
    eval_hash = input_hash(eval_in)
    target = make_bank(world, args.eval_n, args.tgt, int(lock["eval_seed"]))
    if input_hash(target.inputs) != eval_hash:
        raise RuntimeError("fresh target regeneration mismatch")
    true_vals = action_values(target.post, world.tests)
    eval_hat = action_values(estimate_post(eval_in, *lock["qhat"], world.classes), world.tests)
    lay = layout(world.classes, world.distractors, world.gates)

    model_cache: dict[int, tuple[np.ndarray, np.ndarray]] = {}
    for model_id, record in enumerate(model_states):
        spec = NetSpec(**record["spec"])
        model = load_state(lay.dim, world.actions, spec, record["state"])
        mem, probs, _ = run_model(model, eval_in)
        model_cache[model_id] = (mem, probs)

    rows: list[dict] = []
    eval_artifacts: list[dict] = []
    for art in artifacts:
        cid = int(art["candidate"])
        row = dict(pre.loc[pre.candidate == cid].iloc[0])
        quant = quant_from(art["quant"])
        mem, gate_probs = model_cache[int(art["model_id"])]
        codes = repeat_codes(encode(quant, mem, eval_in.regime), world.gates)
        panel_pol = np.asarray(art["panel_pol"], dtype=np.int64)
        raw_pol = np.asarray(art["raw_pol"], dtype=np.int64)
        src_pol = np.asarray(art["src_pol"], dtype=np.int64)
        opt_pol = make_policy(codes, true_vals, args.states, True)

        tgt_eval = eval_policy(codes, panel_pol, true_vals, target.correct)
        raw_eval = eval_policy(codes, raw_pol, true_vals, target.correct)
        src_eval = eval_policy(codes, src_pol, true_vals, target.correct)
        opt_eval = eval_policy(codes, opt_pol, true_vals, target.correct)
        native = native_scores(gate_probs, true_vals, codes, target.correct)
        score = cell_scores(codes, true_vals)
        score_hat = cell_scores(codes, eval_hat)

        row.update({f"tgt_{k}": v for k, v in tgt_eval.items()})
        row.update({f"raw_{k}": v for k, v in raw_eval.items()})
        row.update({f"srcp_{k}": v for k, v in src_eval.items()})
        row.update({f"opt_{k}": v for k, v in opt_eval.items()})
        row.update({f"native_{k}": v for k, v in native.items()})
        row["tgt_krho"] = score["krho"]
        row["tgt_imp"] = score["imp"]
        row["eval_khat"] = score_hat["krho"]
        row["eval_ihat"] = score_hat["imp"]
        for delay in args.tgt:
            ids = target.inputs.delays == delay
            for prefix, pol in (("tgt", panel_pol), ("raw", raw_pol), ("srcp", src_pol), ("opt", opt_pol)):
                part = eval_policy(codes[ids], pol, true_vals[ids], target.correct[ids])
                row[f"{prefix}_ret{delay}"] = part["ret"]
                row[f"{prefix}_reg{delay}"] = part["regret"]
                row[f"{prefix}_hit{delay}"] = part["hit"]
                row[f"{prefix}_k{delay}"] = part["krho"]
        rows.append(row)
        eval_artifacts.append({"candidate": cid, "eval_codes": codes, "eval_probs": gate_probs})

    full = pd.DataFrame(rows)
    admitted = full[full.candidate.isin(lock["admitted"])].copy()
    selectors = dict(lock["selectors"])
    selectors["oracle"] = int(
        admitted.sort_values(["tgt_krho", "src_ret"], ascending=[True, False]).iloc[0].candidate
    )
    rec: dict = {
        "world": int(lock["world"]),
        "lock": lock["sha256"],
        "eval_hash": eval_hash,
        "nadm": len(admitted),
        "q_high": world.q_high,
        "q_low": world.q_low,
        "high_frac": world.high_frac,
        "qherr": lock["qerr"][0],
        "qlerr": lock["qerr"][1],
    }
    for name, cid in selectors.items():
        row = full.loc[full.candidate == cid].iloc[0]
        if name == "raw":
            prefix = "raw"
        elif name in ("kb", "val"):
            prefix = "srcp"
        elif name == "oracle":
            prefix = "opt"
        else:
            prefix = "tgt"
        rec.update(
            {
                f"{name}idx": int(cid),
                f"{name}name": f"{row.arch}_{row.focus}_u{int(row.snap)}_h{int(row.khi)}l{int(row.klo)}",
                f"{name}ret": float(row[f"{prefix}_ret"]),
                f"{name}reg": float(row[f"{prefix}_regret"]),
                f"{name}k": float(row.tgt_krho),
                f"{name}exec": float(row[f"{prefix}_exec"]),
                f"{name}acc": float(row[f"{prefix}_acc"]),
                f"{name}hit": float(row[f"{prefix}_hit"]),
                f"{name}sret": float(row.src_ret),
                f"{name}shit": float(row.src_hit),
                f"{name}bk": float(row.bt_k),
                f"{name}bi": float(row.bt_imp),
                f"{name}khi": int(row.khi),
                f"{name}klo": int(row.klo),
                f"{name}native": float(row.native_ret),
                f"{name}nhit": float(row.native_hit),
            }
        )
        if name == "raw":
            rec["rawwret"] = float(row.tgt_ret)
            rec["rawwreg"] = float(row.tgt_regret)
            rec["rawwk"] = float(row.tgt_krho)
            rec["rawwexec"] = float(row.tgt_exec)
            rec["rawwacc"] = float(row.tgt_acc)
            rec["rawwhit"] = float(row.tgt_hit)
        for delay in args.tgt:
            rec[f"{name}ret{delay}"] = float(row[f"{prefix}_ret{delay}"])
            rec[f"{name}reg{delay}"] = float(row[f"{prefix}_reg{delay}"])
            rec[f"{name}hit{delay}"] = float(row[f"{prefix}_hit{delay}"])
            rec[f"{name}k{delay}"] = float(row[f"{prefix}_k{delay}"])

    wid = int(lock["world"])
    torch.save({"eval_hash": eval_hash, "artifacts": eval_artifacts}, out / f"ev{wid:02d}.pt")
    full.to_csv(out / f"md{wid:02d}.csv", index=False)
    (out / f"sl{wid:02d}.json").write_text(json.dumps(rec, indent=2, sort_keys=True) + "\n")
    return full, rec


def recode_audit(artifacts: list[dict], pre: pd.DataFrame, seed: int) -> bool:
    art = artifacts[0]
    cid = int(art["candidate"])
    row = pre.loc[pre.candidate == cid].iloc[0]
    codes = np.asarray(art["src_codes"], dtype=np.int64)
    recoded, mapping = permute_codes(codes, int(row.khi), int(row.klo), seed)
    pol = np.asarray(art["src_pol"], dtype=np.int64)
    recoded_pol = np.zeros_like(pol)
    for old, new in mapping.items():
        recoded_pol[:, new] = pol[:, old]
    a = np.stack([pol[j, codes[:, j]] for j in range(codes.shape[1])], axis=1)
    b = np.stack([recoded_pol[j, recoded[:, j]] for j in range(recoded.shape[1])], axis=1)
    return bool(np.array_equal(a, b))


def run_world(args, wid: int, out: Path):
    world, pre, states, artifacts, lock, world_file = phase_a(args, wid, out)
    if not recode_audit(artifacts, pre, int(lock["world_seed"]) + 400):
        raise RuntimeError("code relabel audit failed")
    full, rec = phase_b(args, world, pre, states, artifacts, lock, world_file, out)
    print(
        f"DONE world {wid} K={rec['kbtk']:.5f}/{rec['rawk']:.5f} "
        f"R={rec['kbtreg']:.5f}/{rec['rawwreg']:.5f}",
        flush=True,
    )
    return full, rec


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=84431)
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--worlds", type=int, default=1)
    parser.add_argument("--classes", type=int, default=4)
    parser.add_argument("--gates", type=int, default=3)
    parser.add_argument("--cues", type=int, default=3)
    parser.add_argument("--distractors", type=int, default=5)
    parser.add_argument("--src", type=int, nargs="+", default=[3, 5, 7])
    parser.add_argument("--tgt", type=int, nargs="+", default=[12, 20, 28])
    parser.add_argument("--train_n", type=int, default=3000)
    parser.add_argument("--cal_n", type=int, default=1000)
    parser.add_argument("--val_n", type=int, default=2400)
    parser.add_argument("--panel_n", type=int, default=1600)
    parser.add_argument("--eval_n", type=int, default=2400)
    parser.add_argument("--updates", type=int, default=120)
    parser.add_argument("--snap", type=int, nargs="+", default=[60, 120])
    parser.add_argument("--episodes", type=int, default=192)
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--minibatch", type=int, default=192)
    parser.add_argument("--hidden", type=int, default=32)
    parser.add_argument("--lr", type=float, default=0.0025)
    parser.add_argument("--ent", type=float, default=0.01)
    parser.add_argument("--states", type=int, default=6)
    parser.add_argument("--band", type=float, default=0.025)
    parser.add_argument("--min_admit", type=int, default=12)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if max(args.snap) != args.updates:
        raise ValueError("last snapshot must equal update count")
    allocations(args.states)

    t0 = time.time()
    all_models = []
    all_selectors = []
    for wid in range(args.start, args.start + args.worlds):
        models, selectors = run_world(args, wid, args.out)
        all_models.append(models)
        all_selectors.append(selectors)
    pd.concat(all_models, ignore_index=True).to_csv(args.out / f"mo{args.start:02d}.csv", index=False)
    pd.DataFrame(all_selectors).to_csv(args.out / f"se{args.start:02d}.csv", index=False)
    meta = {
        "schema": "riwf-kbin-v3",
        "quantity": "literal_binary_K_rho",
        "representation_geometry": geometry_receipt(),
        "config": {key: (str(value) if isinstance(value, Path) else value) for key, value in vars(args).items()},
        "runtime_s": time.time() - t0,
        "worlds": args.worlds,
        "models_per_world": len(specs(args.seed, args.hidden, args.lr, args.ent)) * len(args.snap),
        "candidates_per_world": len(specs(args.seed, args.hidden, args.lr, args.ent)) * len(args.snap) * len(allocations(args.states)),
        "fixed_representation_states": args.states,
        "one_code_reused_for_all_tests": True,
        "source_policy_fit_eval_independent": True,
        "source_admission_uses_empirical_reward": True,
        "target_labels_before_lock": False,
        "fresh_target_evaluation": True,
        "code_relabel_invariant": True,
        "dense_affine_hidden_recode_invariant": True,
    }
    (args.out / f"mt{args.start:02d}.json").write_text(json.dumps(meta, indent=2, sort_keys=True) + "\n")
    print(json.dumps(meta, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
