#!/usr/bin/env python3
"""Independent audit for binary K-rho recurrent PPO study."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from env import InputBank, World, action_values, estimate_post, estimate_q, input_hash, layout, make_bank
from net import NetSpec
from quant import Quant, encode, fit_quant, geometry_receipt, permute_codes
from core import allocations, cell_scores, load_state, make_policy, repeat_codes, run_model, specs


def load_input(path: Path) -> InputBank:
    with np.load(path, allow_pickle=False) as z:
        expected = {"obs", "valid", "gate", "gate_id", "regime", "cues", "delays", "lengths", "seed"}
        if set(z.files) != expected:
            raise RuntimeError(f"unexpected fields in {path.name}")
        return InputBank(
            z["obs"], z["valid"], z["gate"], z["gate_id"], z["regime"],
            z["cues"], z["delays"], z["lengths"], int(z["seed"][0]),
        )


def qfrom(data: dict) -> Quant:
    if data.get("schema") != "riwf.quant.affine_row.v1":
        raise RuntimeError("unsupported quantiser geometry")
    value = Quant(
        np.asarray(data["origin"], dtype=np.float64),
        np.asarray(data["basis"], dtype=np.float64),
        np.asarray(data["coord_mean"], dtype=np.float64),
        np.asarray(data["coord_scale"], dtype=np.float64),
        np.asarray(data["basis_rows"], dtype=np.int64),
        np.asarray(data["hi"], dtype=np.float64),
        np.asarray(data["lo"], dtype=np.float64),
        str(data["frame_rule"]),
        int(data["canonical_decimals"]),
    )
    if value.sha != data.get("sha256"):
        raise RuntimeError("quantiser hash mismatch")
    return value


def lock_hash(lock: dict) -> str:
    cp = dict(lock)
    cp.pop("sha256", None)
    text = json.dumps(cp, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(text.encode()).hexdigest()


def terms_ref(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 3 or values.shape[2] != 2:
        raise ValueError("reference computation requires two actions")
    y = np.argmax(values, axis=2).astype(np.int64)
    hi = np.max(values, axis=2)
    lo = np.min(values, axis=2)
    rho = 1.0 - lo / np.maximum(hi, 1e-12)
    return y, np.clip(rho, 0.0, 1.0)


def krho_ref(codes: np.ndarray, values: np.ndarray) -> float:
    y, rho = terms_ref(values)
    total = 0.0
    for test in range(y.shape[1]):
        for code in np.unique(codes[:, test]):
            ids = np.flatnonzero(codes[:, test] == code)
            w0 = float(rho[ids, test][y[ids, test] == 0].sum())
            w1 = float(rho[ids, test][y[ids, test] == 1].sum())
            total += min(w0, w1)
    return total / float(y.size)


def imp_ref(codes: np.ndarray, values: np.ndarray) -> float:
    y, _rho = terms_ref(values)
    total = 0
    for test in range(y.shape[1]):
        for code in np.unique(codes[:, test]):
            ids = np.flatnonzero(codes[:, test] == code)
            freq = np.bincount(y[ids, test], minlength=2)
            total += int(np.min(freq))
    return float(total / y.size)


def policy_ref(codes: np.ndarray, values: np.ndarray, states: int, weighted: bool) -> np.ndarray:
    y, rho = terms_ref(values)
    policy = np.zeros((y.shape[1], states), dtype=np.int64)
    for test in range(y.shape[1]):
        w = rho[:, test] if weighted else None
        policy[test, :] = int(np.argmax(np.bincount(y[:, test], weights=w, minlength=2)))
        for code in np.unique(codes[:, test]):
            ids = np.flatnonzero(codes[:, test] == code)
            w = rho[ids, test] if weighted else None
            mass = np.bincount(y[ids, test], weights=w, minlength=2)
            policy[test, int(code)] = int(np.argmax(mass))
    return policy


def eval_ref(codes: np.ndarray, policy: np.ndarray, values: np.ndarray, correct: np.ndarray | None = None) -> dict:
    y, rho = terms_ref(values)
    acts = np.stack([policy[j, codes[:, j]] for j in range(codes.shape[1])], axis=1)
    regret = float(np.mean(rho * (acts != y)))
    got = values[np.arange(len(codes))[:, None], np.arange(values.shape[1])[None, :], acts]
    direct = float(np.mean(1.0 - got / np.maximum(values.max(axis=2), 1e-12)))
    out = {
        "reg": regret,
        "direct": direct,
        "ret": float(got.mean()),
        "acc": float((acts == y).mean()),
    }
    if correct is not None:
        out["hit"] = float((acts == np.asarray(correct, dtype=np.int64)).mean())
    return out


def native_ref(probs: np.ndarray, values: np.ndarray, correct: np.ndarray) -> dict:
    probs = np.asarray(probs, dtype=np.float64)
    got = (probs * values).sum(axis=2)
    out = {
        "ret": float(got.mean()),
        "reg": float(np.mean(1.0 - got / np.maximum(values.max(axis=2), 1e-12))),
        "acc": float((np.argmax(probs, axis=2) == np.argmax(values, axis=2)).mean()),
    }
    idx = np.asarray(correct, dtype=np.int64)
    out["hit"] = float(
        probs[np.arange(len(probs))[:, None], np.arange(probs.shape[1])[None, :], idx].mean()
    )
    return out


def relabel_policy(policy: np.ndarray, mapping: dict[int, int]) -> np.ndarray:
    out = np.zeros_like(policy)
    for old, new in mapping.items():
        out[:, new] = policy[:, old]
    return out


def qerr(a: Quant, b: Quant) -> float:
    if a.frame_rule != b.frame_rule or a.canonical_decimals != b.canonical_decimals:
        return float("inf")
    return max(
        float(np.max(np.abs(a.origin - b.origin))),
        float(np.max(np.abs(a.basis - b.basis))),
        float(np.max(np.abs(a.coord_mean - b.coord_mean))),
        float(np.max(np.abs(a.coord_scale - b.coord_scale))),
        float(np.max(np.abs(a.basis_rows - b.basis_rows))),
        float(np.max(np.abs(a.hi - b.hi))),
        float(np.max(np.abs(a.lo - b.lo))),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", type=Path, required=True)
    parser.add_argument("--expect", type=int, required=True)
    parser.add_argument("--ids", type=Path, default=None)
    args = parser.parse_args()
    out = args.dir
    if args.ids is None:
        ids = sorted(int(path.stem[2:]) for path in out.glob("mt*.json"))
    else:
        data = json.loads(args.ids.read_text())
        ids = [int(x) for x in data.get("selected", data.get("ids", []))]
    if len(ids) != args.expect or len(set(ids)) != len(ids):
        raise RuntimeError("unexpected world id total")
    metas = [out / f"mt{wid:02d}.json" for wid in ids]
    if not all(path.exists() for path in metas):
        raise RuntimeError("meta file missing")
    cfgs = [json.loads(path.read_text())["config"] for path in metas]
    cfg = cfgs[0]
    states = int(cfg["states"])
    candidates_per_world = (
        len(specs(int(cfg["seed"]), int(cfg["hidden"]), float(cfg["lr"]), float(cfg["ent"])))
        * len(cfg["snap"])
        * len(allocations(states))
    )

    checks = {
        "world_count": True,
        "config_match": True,
        "candidate_count": True,
        "lock_hashes": True,
        "panel_before_lock": True,
        "lock_before_eval": True,
        "input_only_archives": True,
        "panel_hashes": True,
        "eval_hashes": True,
        "panel_eval_independent": True,
        "source_calibration": True,
        "source_policy_fit_eval_independent": True,
        "admission_empirical_source_reward": True,
        "balanced_tests": True,
        "tests_distinguish_classes": True,
        "binary_action_values": True,
        "one_code_all_tests": True,
        "quantisers_recomputed": True,
        "affine_geometry_serialised": True,
        "dense_affine_recode_invariant": True,
        "source_codes_recomputed": True,
        "panel_codes_recomputed": True,
        "eval_codes_recomputed": True,
        "panel_probs_recomputed": True,
        "eval_probs_recomputed": True,
        "source_scores_recomputed": True,
        "panel_scores_recomputed": True,
        "target_scores_recomputed": True,
        "selectors_recomputed": True,
        "policies_recomputed": True,
        "floor_identity": True,
        "direct_regret_identity": True,
        "execution_nonnegative": True,
        "code_relabels": True,
        "truth_absent_prelock": True,
        "fresh_target_evaluation": True,
    }
    maxerr = {
        "q": 0.0,
        "quant": 0.0,
        "fit_code": 0.0,
        "source_code": 0.0,
        "panel_code": 0.0,
        "eval_code": 0.0,
        "panel_prob": 0.0,
        "eval_prob": 0.0,
        "source_score": 0.0,
        "panel_score": 0.0,
        "target_score": 0.0,
        "floor": 0.0,
        "regret": 0.0,
    }
    totals = {"worlds": 0, "candidates": 0, "relabels": 0}
    details = []

    stable = [key for key in cfg if key not in {"out", "start", "worlds"}]
    for other in cfgs[1:]:
        checks["config_match"] &= all(other[key] == cfg[key] for key in stable)

    for wid in ids:
        paths = {
            "lock": out / f"lk{wid:02d}.json",
            "model": out / f"md{wid:02d}.csv",
            "pre": out / f"pr{wid:02d}.csv",
            "state": out / f"st{wid:02d}.pt",
            "panel": out / f"ti{wid:02d}.npz",
            "eval": out / f"ei{wid:02d}.npz",
            "evalart": out / f"ev{wid:02d}.pt",
            "selector": out / f"sl{wid:02d}.json",
        }
        for path in paths.values():
            if not path.exists():
                raise RuntimeError(f"missing {path}")
        checks["panel_before_lock"] &= paths["panel"].stat().st_mtime_ns <= paths["lock"].stat().st_mtime_ns
        for key in ("eval", "evalart", "model", "selector"):
            checks["lock_before_eval"] &= paths["lock"].stat().st_mtime_ns <= paths[key].stat().st_mtime_ns

        lock = json.loads(paths["lock"].read_text())
        selector_rec = json.loads(paths["selector"].read_text())
        checks["lock_hashes"] &= lock_hash(lock) == lock["sha256"]
        checks["truth_absent_prelock"] &= lock.get("target_truth_fields_available") == []
        checks["truth_absent_prelock"] &= lock.get("quantity") == "literal_binary_K_rho"
        checks["affine_geometry_serialised"] &= lock.get("representation_geometry") == geometry_receipt()
        checks["fresh_target_evaluation"] &= (
            lock.get("evaluation") == "fresh target histories drawn after selector and policy lock"
        )

        wp = dict(lock["world_params"])
        wp["tests"] = np.asarray(wp["tests"], dtype=np.int64)
        world = World(**wp)
        checks["balanced_tests"] &= bool(np.all(world.tests.sum(axis=1) == 2))
        checks["tests_distinguish_classes"] &= (
            len({tuple(world.tests[:, g].tolist()) for g in range(world.classes)}) == world.classes
        )
        checks["binary_action_values"] &= world.actions == 2

        wseed = int(lock["world_seed"])
        src_fit = make_bank(world, int(cfg["train_n"]), cfg["src"], wseed + 1)
        src_cal = make_bank(world, int(cfg["cal_n"]), cfg["src"], wseed + 2)
        src_val = make_bank(world, int(cfg["val_n"]), cfg["src"], wseed + 3)
        qh, ql = estimate_q(src_cal)
        qe = max(abs(qh - float(lock["qhat"][0])), abs(ql - float(lock["qhat"][1])))
        maxerr["q"] = max(maxerr["q"], qe)
        checks["source_calibration"] &= qe < 1e-15

        panel_in = load_input(paths["panel"])
        eval_in = load_input(paths["eval"])
        checks["panel_hashes"] &= input_hash(panel_in) == lock["panel_input_hash"]
        checks["eval_hashes"] &= input_hash(eval_in) == selector_rec["eval_hash"]
        checks["panel_eval_independent"] &= (
            panel_in.seed != eval_in.seed
            and input_hash(panel_in) != input_hash(eval_in)
            and panel_in.obs.shape[0] == int(cfg["panel_n"])
            and eval_in.obs.shape[0] == int(cfg["eval_n"])
        )

        fit_hat = action_values(estimate_post(src_fit.inputs, qh, ql, world.classes), world.tests)
        val_hat = action_values(estimate_post(src_val.inputs, qh, ql, world.classes), world.tests)
        panel_hat = action_values(estimate_post(panel_in, qh, ql, world.classes), world.tests)
        checks["source_policy_fit_eval_independent"] &= (
            int(lock.get("source_policy_fit_seed", -1)) == wseed + 1
            and int(lock.get("source_policy_eval_seed", -1)) == wseed + 3
            and int(lock.get("source_policy_fit_seed", -1)) != int(lock.get("source_policy_eval_seed", -1))
        )
        checks["admission_empirical_source_reward"] &= (
            lock.get("source_admission_metric")
            == "empirical mean reward on independent source validation histories"
        )
        target = make_bank(world, int(cfg["eval_n"]), cfg["tgt"], int(lock["eval_seed"]))
        checks["eval_hashes"] &= input_hash(target.inputs) == selector_rec["eval_hash"]
        target_true = action_values(target.post, world.tests)

        pre = pd.read_csv(paths["pre"])
        md = pd.read_csv(paths["model"])
        pack = torch.load(paths["state"], map_location="cpu", weights_only=False)
        models = pack["models"]
        arts = pack["artifacts"]
        evpack = torch.load(paths["evalart"], map_location="cpu", weights_only=False)
        evarts = {int(art["candidate"]): art for art in evpack["artifacts"]}
        checks["eval_hashes"] &= evpack["eval_hash"] == selector_rec["eval_hash"]

        totals["worlds"] += 1
        totals["candidates"] += len(arts)
        checks["candidate_count"] &= (
            len(arts) == candidates_per_world
            and len(pre) == candidates_per_world
            and len(md) == candidates_per_world
            and len(evarts) == candidates_per_world
        )

        best = float(pre.src_hit.max())
        admitted = pre[pre.src_hit >= best - float(cfg["band"])].copy()
        if len(admitted) < int(cfg["min_admit"]):
            admitted = pre.nlargest(int(cfg["min_admit"]), "src_hit").copy()
        checks["selectors_recomputed"] &= admitted.candidate.astype(int).tolist() == lock["admitted"]
        rr = np.random.default_rng(wseed + 99991)
        selectors = {
            "kbt": int(admitted.sort_values(["bt_k", "src_hit", "src_reg"], ascending=[True, False, True]).iloc[0].candidate),
            "raw": int(admitted.sort_values(["bt_imp", "src_hit", "src_reg"], ascending=[True, False, True]).iloc[0].candidate),
            "kb": int(admitted.sort_values(["src_k", "src_hit", "src_reg"], ascending=[True, False, True]).iloc[0].candidate),
            "val": int(admitted.sort_values(["src_hit", "src_reg", "src_k"], ascending=[False, True, True]).iloc[0].candidate),
            "rand": int(rr.choice(admitted.candidate.to_numpy())),
        }
        checks["selectors_recomputed"] &= selectors == lock["selectors"]

        lay = layout(world.classes, world.distractors, world.gates)
        fit_cache: dict[int, np.ndarray] = {}
        source_cache: dict[int, tuple[np.ndarray, np.ndarray]] = {}
        panel_cache: dict[int, tuple[np.ndarray, np.ndarray]] = {}
        eval_cache: dict[int, tuple[np.ndarray, np.ndarray]] = {}
        for model_id, record in enumerate(models):
            spec = NetSpec(**record["spec"])
            model = load_state(lay.dim, world.actions, spec, record["state"])
            fit_h, _fit_p, _ = run_model(model, src_fit.inputs)
            source_h, source_p, _ = run_model(model, src_val.inputs)
            panel_h, panel_p, _ = run_model(model, panel_in)
            eval_h, eval_p, _ = run_model(model, eval_in)
            fit_cache[model_id] = fit_h
            source_cache[model_id] = (source_h, source_p)
            panel_cache[model_id] = (panel_h, panel_p)
            eval_cache[model_id] = (eval_h, eval_p)

        audited_models: set[int] = set()
        for art in arts:
            cid = int(art["candidate"])
            row = md.loc[md.candidate == cid].iloc[0]
            model_id = int(art["model_id"])
            model_rec = models[model_id]
            spec = NetSpec(**model_rec["spec"])
            stored_q = qfrom(art["quant"])
            rebuilt_q = fit_quant(
                fit_cache[model_id],
                src_fit.inputs.regime,
                int(row.khi),
                int(row.klo),
                spec.seed + int(row.snap) * 13 + int(row.khi),
            )
            qe = qerr(stored_q, rebuilt_q)
            maxerr["quant"] = max(maxerr["quant"], qe)
            checks["quantisers_recomputed"] &= qe < 2e-10

            fit_h = fit_cache[model_id]
            if model_id not in audited_models:
                rng = np.random.default_rng(int(lock["world_seed"]) + 700001 + model_id)
                dim = fit_h.shape[-1]
                transform = rng.normal(size=(dim, dim)) + 5.0 * np.eye(dim)
                shift = rng.normal(size=dim)
                recoded_q = fit_quant(
                    fit_h @ transform + shift,
                    src_fit.inputs.regime,
                    int(row.khi),
                    int(row.klo),
                    spec.seed + int(row.snap) * 13 + int(row.khi),
                )
                original_panel = encode(stored_q, panel_cache[model_id][0], panel_in.regime)
                recoded_panel = encode(
                    recoded_q,
                    panel_cache[model_id][0] @ transform + shift,
                    panel_in.regime,
                )
                original_eval = encode(stored_q, eval_cache[model_id][0], eval_in.regime)
                recoded_eval = encode(
                    recoded_q,
                    eval_cache[model_id][0] @ transform + shift,
                    eval_in.regime,
                )
                checks["dense_affine_recode_invariant"] &= bool(
                    np.array_equal(original_panel, recoded_panel)
                    and np.array_equal(original_eval, recoded_eval)
                )
                audited_models.add(model_id)

            source_h, source_p = source_cache[model_id]
            panel_h, panel_p = panel_cache[model_id]
            eval_h, eval_p = eval_cache[model_id]
            fit_codes = repeat_codes(encode(stored_q, fit_h, src_fit.inputs.regime), world.gates)
            source_codes = repeat_codes(encode(stored_q, source_h, src_val.inputs.regime), world.gates)
            panel_codes = repeat_codes(encode(stored_q, panel_h, panel_in.regime), world.gates)
            eval_codes = repeat_codes(encode(stored_q, eval_h, eval_in.regime), world.gates)
            eva = evarts[cid]

            fit_code_err = float(np.max(np.abs(fit_codes - np.asarray(art["fit_codes"]))))
            source_code_err = float(np.max(np.abs(source_codes - np.asarray(art["src_codes"]))))
            panel_code_err = float(np.max(np.abs(panel_codes - np.asarray(art["panel_codes"]))))
            eval_code_err = float(np.max(np.abs(eval_codes - np.asarray(eva["eval_codes"]))))
            maxerr["fit_code"] = max(maxerr["fit_code"], fit_code_err)
            maxerr["source_code"] = max(maxerr["source_code"], source_code_err)
            maxerr["panel_code"] = max(maxerr["panel_code"], panel_code_err)
            maxerr["eval_code"] = max(maxerr["eval_code"], eval_code_err)
            checks["source_codes_recomputed"] &= fit_code_err == 0.0 and source_code_err == 0.0
            checks["panel_codes_recomputed"] &= panel_code_err == 0.0
            checks["eval_codes_recomputed"] &= eval_code_err == 0.0
            checks["one_code_all_tests"] &= bool(
                np.all(fit_codes == fit_codes[:, :1])
                and np.all(source_codes == source_codes[:, :1])
                and np.all(panel_codes == panel_codes[:, :1])
                and np.all(eval_codes == eval_codes[:, :1])
            )

            panel_prob_err = float(np.max(np.abs(panel_p - np.asarray(art["panel_probs"]))))
            eval_prob_err = float(np.max(np.abs(eval_p - np.asarray(eva["eval_probs"]))))
            maxerr["panel_prob"] = max(maxerr["panel_prob"], panel_prob_err)
            maxerr["eval_prob"] = max(maxerr["eval_prob"], eval_prob_err)
            checks["panel_probs_recomputed"] &= panel_prob_err < 2e-7
            checks["eval_probs_recomputed"] &= eval_prob_err < 2e-7

            source_pol = np.asarray(art["src_pol"], dtype=np.int64)
            panel_pol = np.asarray(art["panel_pol"], dtype=np.int64)
            raw_pol = np.asarray(art["raw_pol"], dtype=np.int64)
            checks["policies_recomputed"] &= np.array_equal(
                source_pol, policy_ref(fit_codes, fit_hat, states, True)
            )
            checks["policies_recomputed"] &= np.array_equal(
                panel_pol, policy_ref(panel_codes, panel_hat, states, True)
            )
            checks["policies_recomputed"] &= np.array_equal(
                raw_pol, policy_ref(panel_codes, panel_hat, states, False)
            )
            checks["policies_recomputed"] &= (
                lock["policies"][str(cid)]["source"] == art["src_pol"]
                and lock["policies"][str(cid)]["panel"] == art["panel_pol"]
                and lock["policies"][str(cid)]["raw"] == art["raw_pol"]
            )

            source_k = krho_ref(source_codes, val_hat)
            source_i = imp_ref(source_codes, val_hat)
            panel_k = krho_ref(panel_codes, panel_hat)
            panel_i = imp_ref(panel_codes, panel_hat)
            source_score_err = max(abs(float(row.src_k) - source_k), abs(float(row.src_imp) - source_i))
            panel_score_err = max(abs(float(row.bt_k) - panel_k), abs(float(row.bt_imp) - panel_i))
            maxerr["source_score"] = max(maxerr["source_score"], source_score_err)
            maxerr["panel_score"] = max(maxerr["panel_score"], panel_score_err)
            checks["source_scores_recomputed"] &= source_score_err < 3e-10
            checks["panel_scores_recomputed"] &= panel_score_err < 3e-10

            source_eval = eval_ref(source_codes, source_pol, val_hat, src_val.correct)
            source_native = native_ref(source_p, val_hat, src_val.correct)
            target_k = krho_ref(eval_codes, target_true)
            opt_pol = policy_ref(eval_codes, target_true, states, True)
            target_eval = eval_ref(eval_codes, panel_pol, target_true, target.correct)
            raw_eval = eval_ref(eval_codes, raw_pol, target_true, target.correct)
            source_target_eval = eval_ref(eval_codes, source_pol, target_true, target.correct)
            opt_eval = eval_ref(eval_codes, opt_pol, target_true, target.correct)
            native = native_ref(eval_p, target_true, target.correct)

            target_score_err = abs(float(row.tgt_krho) - target_k)
            maxerr["target_score"] = max(maxerr["target_score"], target_score_err)
            checks["target_scores_recomputed"] &= target_score_err < 3e-10
            floor_err = abs(opt_eval["reg"] - target_k)
            maxerr["floor"] = max(maxerr["floor"], floor_err)
            checks["floor_identity"] &= floor_err < 3e-10
            direct_err = max(
                abs(target_eval["reg"] - target_eval["direct"]),
                abs(raw_eval["reg"] - raw_eval["direct"]),
                abs(opt_eval["reg"] - opt_eval["direct"]),
            )
            maxerr["regret"] = max(maxerr["regret"], direct_err)
            checks["direct_regret_identity"] &= direct_err < 3e-10
            checks["execution_nonnegative"] &= (
                target_eval["reg"] - target_k >= -3e-10
                and raw_eval["reg"] - target_k >= -3e-10
                and source_target_eval["reg"] - target_k >= -3e-10
            )

            expected = {
                "src_ret": source_eval["ret"],
                "src_reg": source_eval["reg"],
                "src_acc": source_eval["acc"],
                "src_hit": source_eval["hit"],
                "native_src_ret": source_native["ret"],
                "native_src_reg": source_native["reg"],
                "native_src_hit": source_native["hit"],
                "tgt_ret": target_eval["ret"],
                "tgt_regret": target_eval["reg"],
                "tgt_acc": target_eval["acc"],
                "tgt_hit": target_eval["hit"],
                "raw_ret": raw_eval["ret"],
                "raw_regret": raw_eval["reg"],
                "raw_acc": raw_eval["acc"],
                "raw_hit": raw_eval["hit"],
                "srcp_ret": source_target_eval["ret"],
                "srcp_regret": source_target_eval["reg"],
                "opt_ret": opt_eval["ret"],
                "opt_regret": opt_eval["reg"],
                "native_ret": native["ret"],
                "native_regret": native["reg"],
                "native_hit": native["hit"],
            }
            for key, value in expected.items():
                err = abs(float(row[key]) - float(value))
                maxerr["target_score"] = max(maxerr["target_score"], err)
                checks["target_scores_recomputed"] &= err < 3e-8

            recoded, mapping = permute_codes(
                eval_codes, int(row.khi), int(row.klo), wseed + 200000 + cid
            )
            recoded_policy = relabel_policy(panel_pol, mapping)
            old = eval_ref(eval_codes, panel_pol, target_true)
            new = eval_ref(recoded, recoded_policy, target_true)
            checks["code_relabels"] &= (
                abs(old["reg"] - new["reg"]) < 1e-12
                and abs(old["ret"] - new["ret"]) < 1e-12
            )
            totals["relabels"] += 1

            checks["truth_absent_prelock"] &= not (
                {"goal", "correct", "post", "target_labels", "target_rewards", "eval_codes", "eval_probs"}
                & set(art.keys())
            )

        details.append(
            {
                "world": wid,
                "admitted": len(admitted),
                "kbt": selectors["kbt"],
                "raw": selectors["raw"],
                "qerr": list(lock["qerr"]),
                "panel_seed": int(lock["panel_seed"]),
                "eval_seed": int(lock["eval_seed"]),
            }
        )

    checks["world_count"] &= totals["worlds"] == len(ids)
    checks["candidate_count"] &= totals["candidates"] == len(ids) * candidates_per_world
    result = {
        "schema": "riwf-kbin-audit-v2",
        "checks": checks,
        "pass": bool(all(checks.values())),
        "totals": totals,
        "max_abs_error": maxerr,
        "details": details,
    }
    (out / "audx.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    if not result["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
