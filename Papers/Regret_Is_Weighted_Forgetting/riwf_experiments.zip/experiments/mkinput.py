#!/usr/bin/env python3
"""Write target observations while omitting outcomes."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
from env import World, make_bank


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--world", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--n", type=int, required=True)
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--delays", type=int, nargs="+", required=True)
    args = p.parse_args()
    data = json.loads(args.world.read_text())
    data["tests"] = np.asarray(data["tests"], dtype=np.int64)
    world = World(**data)
    bank = make_bank(world, args.n, args.delays, args.seed).inputs
    np.savez_compressed(
        args.out,
        obs=bank.obs,
        valid=bank.valid,
        gate=bank.gate,
        gate_id=bank.gate_id,
        regime=bank.regime,
        cues=bank.cues,
        delays=bank.delays,
        lengths=bank.lengths,
        seed=np.asarray([bank.seed], dtype=np.int64),
    )


if __name__ == "__main__":
    main()
