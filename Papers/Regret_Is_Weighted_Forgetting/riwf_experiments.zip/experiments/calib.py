#!/usr/bin/env python3
"""Fold-robust source calibration used by corrected RIWF PPO code."""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd

from env import FullBank


@dataclass(frozen=True)
class FoldCalibration:
    folds: int
    seed: int
    q: tuple[tuple[float, float], ...]
    held: tuple[tuple[int, ...], ...]


def stratified_folds(regime: np.ndarray, folds: int, seed: int) -> tuple[np.ndarray, ...]:
    """Partition episode indices once, stratified by visible regime."""
    regime = np.asarray(regime, dtype=np.int64)
    if regime.ndim != 1:
        raise ValueError("regime must be one dimensional")
    if folds < 2 or folds > len(regime):
        raise ValueError("invalid fold total")
    rng = np.random.default_rng(int(seed))
    parts: list[list[int]] = [[] for _ in range(int(folds))]
    for value in np.unique(regime):
        ids = np.flatnonzero(regime == value).copy()
        rng.shuffle(ids)
        for fid, block in enumerate(np.array_split(ids, folds)):
            parts[fid].extend(int(x) for x in block)
    out = tuple(np.asarray(sorted(part), dtype=np.int64) for part in parts)
    joined = np.concatenate(out)
    if len(joined) != len(regime) or len(np.unique(joined)) != len(regime):
        raise RuntimeError("folds do not partition calibration episodes")
    if not np.array_equal(np.sort(joined), np.arange(len(regime))):
        raise RuntimeError("fold partition omits an episode")
    return out


def _estimate_excluding(bank: FullBank, held: np.ndarray) -> tuple[float, float]:
    keep = np.ones(len(bank.goal), dtype=bool)
    keep[np.asarray(held, dtype=np.int64)] = False
    match = bank.inputs.cues[keep] == bank.goal[keep, None]
    regime = bank.inputs.regime[keep]
    values: list[float] = []
    for value in (1, 0):
        ids = regime == value
        if not ids.any():
            raise RuntimeError("cross-fit training slice lacks a regime")
        q = float(match[ids].mean())
        values.append(float(np.clip(q, 0.251, 0.999)))
    return values[0], values[1]


def crossfit_q(bank: FullBank, folds: int, seed: int) -> FoldCalibration:
    """Return leave-one-fold-out channel estimates from one source bank."""
    held = stratified_folds(bank.inputs.regime, folds, seed)
    q = tuple(_estimate_excluding(bank, block) for block in held)
    return FoldCalibration(
        int(folds),
        int(seed),
        q,
        tuple(tuple(int(x) for x in block) for block in held),
    )


def rank_matrix(scores: np.ndarray) -> np.ndarray:
    """Rank-normalise candidate scores independently inside every fold."""
    scores = np.asarray(scores, dtype=np.float64)
    if scores.ndim != 2 or scores.shape[0] < 1 or scores.shape[1] < 2:
        raise ValueError("scores must have shape candidates by folds")
    ranks = np.empty_like(scores)
    for fid in range(scores.shape[1]):
        ranks[:, fid] = pd.Series(scores[:, fid]).rank(method="average", ascending=True).to_numpy()
    if scores.shape[0] == 1:
        return np.zeros_like(scores)
    return (ranks - 1.0) / float(scores.shape[0] - 1)


def rank_summary(scores: np.ndarray) -> dict[str, np.ndarray]:
    scores = np.asarray(scores, dtype=np.float64)
    ranks = rank_matrix(scores)
    minima = ranks.min(axis=0, keepdims=True)
    return {
        "rank_mean": ranks.mean(axis=1),
        "rank_max": ranks.max(axis=1),
        "winner_rate": np.isclose(ranks, minima, atol=1e-15, rtol=0.0).mean(axis=1),
        "score_mean": scores.mean(axis=1),
        "score_sd": scores.std(axis=1, ddof=1),
    }
