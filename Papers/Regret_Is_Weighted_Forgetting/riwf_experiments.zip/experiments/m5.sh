#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

mkdir -p .cache/pip .cache/mpl .cache/torch .cache/xdg .cache/py tmp
export PIP_CACHE_DIR="$ROOT/.cache/pip"
export MPLCONFIGDIR="$ROOT/.cache/mpl"
export MPLBACKEND=Agg
export TORCH_HOME="$ROOT/.cache/torch"
export XDG_CACHE_HOME="$ROOT/.cache/xdg"
export PYTHONPYCACHEPREFIX="$ROOT/.cache/py"
export PYTHONNOUSERSITE=1
export PYTHONUNBUFFERED=1
export TMPDIR="$ROOT/tmp"

case "${1:-}" in
  setup)
    exec ./setup.sh
    ;;
  test)
    exec .venv/bin/python tests.py
    ;;
  smoke)
    exec ./smoke.sh
    ;;
  run)
    shift
    if [ ! -x .venv/bin/python ]; then
      echo "Run ./m5.sh setup first"
      exit 1
    fi
    exec .venv/bin/python driver.py --plan plan.json --out out --jobs "${JOBS:-6}" "$@"
    ;;
  status)
    exec .venv/bin/python status.py
    ;;
  *)
    echo "Usage: ./m5.sh {setup|test|smoke|run|status}"
    exit 2
    ;;
esac
