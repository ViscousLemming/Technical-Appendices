#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
root = Path(__file__).resolve().parent / "out"
state = root / "state.json"
if state.exists():
    print(state.read_text())
else:
    print("No run state found")
for name in ("fixed_a", "fixed_b", "screen_a", "screen_b"):
    d = root / name
    if not d.exists():
        continue
    source = len(list(d.glob("s*.ok")))
    target = len(list(d.glob("t*.ok")))
    stable = 0
    for path in d.glob("sc*.json"):
        try:
            stable += int(bool(json.loads(path.read_text()).get("stable_disagreement")))
        except Exception:
            pass
    print(f"{name} source {source} target {target} stable {stable}")
