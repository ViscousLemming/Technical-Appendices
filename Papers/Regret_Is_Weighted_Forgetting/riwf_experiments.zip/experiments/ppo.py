#!/usr/bin/env python3
"""Episodic recurrent PPO trainer using source rewards only."""
from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Sequence
import numpy as np
import torch

from env import FullBank, World, make_bank
from net import NetSpec, RNet


@dataclass(frozen=True)
class TrainCfg:
    updates: int = 120
    episodes: int = 192
    epochs: int = 2
    minibatch: int = 64
    gamma: float = 0.99
    gae: float = 0.95
    clip: float = 0.2
    vf: float = 0.5
    grad: float = 1.0


def tensors(bank: FullBank):
    inp = bank.inputs
    return (
        torch.from_numpy(inp.obs),
        torch.from_numpy(inp.valid),
        torch.from_numpy(inp.gate),
        torch.from_numpy(bank.correct),
    )


def rewards(actions: torch.Tensor, bank: FullBank) -> torch.Tensor:
    gid = torch.from_numpy(bank.inputs.gate_id)
    correct = torch.from_numpy(bank.correct)
    reward = torch.zeros_like(actions, dtype=torch.float32)
    rows, cols = torch.where(gid >= 0)
    wanted = correct[rows, gid[rows, cols]]
    reward[rows, cols] = (actions[rows, cols] == wanted).float()
    return reward


def gae(rew, val, valid, gamma: float, lam: float):
    b, tmax = rew.shape
    adv = torch.zeros_like(rew)
    x = torch.zeros(b, dtype=torch.float32)
    for t in range(tmax - 1, -1, -1):
        if t + 1 < tmax:
            nonterm = valid[:, t + 1].float()
            nextv = val[:, t + 1]
        else:
            nonterm = torch.zeros(b)
            nextv = torch.zeros(b)
        delta = rew[:, t] + gamma * nextv * nonterm - val[:, t]
        x = (delta + gamma * lam * nonterm * x) * valid[:, t].float()
        adv[:, t] = x
    return adv, adv + val


def focus_frac(spec: NetSpec, world: World) -> float:
    if spec.focus == "hi":
        return 0.50
    if spec.focus == "lo":
        return 0.02
    if spec.focus == "nat":
        return world.high_frac
    raise ValueError(spec.focus)


def train_one(
    world: World,
    spec: NetSpec,
    obs_dim: int,
    delays: Sequence[int],
    base_seed: int,
    cfg: TrainCfg,
    snaps: Sequence[int],
) -> tuple[dict[int, dict], dict]:
    model = RNet(obs_dim, world.actions, spec)
    opt = torch.optim.Adam(model.parameters(), lr=spec.lr)
    rng = np.random.default_rng(int(base_seed))
    losses = []
    returns = []
    snapshots: dict[int, dict] = {}
    snapset = set(int(x) for x in snaps)
    for update in range(1, cfg.updates + 1):
        bank = make_bank(
            world,
            cfg.episodes,
            delays,
            int(rng.integers(0, 2**31 - 1)),
            high_frac=focus_frac(spec, world),
        )
        obs, valid, gate, _ = tensors(bank)
        with torch.no_grad():
            old_logits, old_v, _hid = model.unroll(obs)
            dist = torch.distributions.Categorical(logits=old_logits)
            actions = dist.sample()
            old_lp = dist.log_prob(actions)
            rew = rewards(actions, bank)
            adv, ret = gae(rew, old_v, valid, cfg.gamma, cfg.gae)
            dm = gate.bool()
            vals = adv[dm]
            adv = adv.clone()
            adv[dm] = (vals - vals.mean()) / (vals.std(unbiased=False) + 1e-8)
            returns.append(float(rew.sum(1).mean() / world.gates))

        order = np.arange(cfg.episodes)
        last_loss = float("nan")
        for _ in range(cfg.epochs):
            rng.shuffle(order)
            for start in range(0, cfg.episodes, cfg.minibatch):
                ids = torch.from_numpy(order[start : start + cfg.minibatch].astype(np.int64))
                logits, val, _hid = model.unroll(obs[ids])
                dist = torch.distributions.Categorical(logits=logits)
                lp = dist.log_prob(actions[ids])
                ratio = torch.exp(lp - old_lp[ids])
                gm = gate[ids].bool()
                pg1 = ratio[gm] * adv[ids][gm]
                pg2 = torch.clamp(ratio[gm], 1.0 - cfg.clip, 1.0 + cfg.clip) * adv[ids][gm]
                policy = -torch.minimum(pg1, pg2).mean()
                value = ((val - ret[ids]).square() * valid[ids].float()).sum() / valid[ids].float().sum()
                entropy = dist.entropy()[gm].mean()
                loss = policy + cfg.vf * value - spec.ent * entropy
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad)
                opt.step()
                last_loss = float(loss.detach())
        losses.append(last_loss)
        if update in snapset:
            snapshots[update] = copy.deepcopy(model.state_dict())

    meta = {
        "loss": float(np.mean(losses[-10:])),
        "train_return": float(np.mean(returns[-10:])),
        "updates": cfg.updates,
        "episodes_per_update": cfg.episodes,
    }
    return snapshots, meta
