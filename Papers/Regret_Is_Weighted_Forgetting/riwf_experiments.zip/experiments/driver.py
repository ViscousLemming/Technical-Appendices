#!/usr/bin/env python3
"""Resumable local launcher for fixed and stable-disagreement PPO cohorts."""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def _hash(obj: dict) -> str:
    cp = dict(obj)
    cp.pop("sha256", None)
    text = json.dumps(cp, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(text.encode()).hexdigest()


def _write(path: Path, value: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    tmp.replace(path)


def _run(cmd: list[str], log: Path) -> None:
    env = dict(os.environ)
    for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        env[key] = "1"
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("w") as fh:
        proc = subprocess.run(cmd, cwd=ROOT, env=env, stdout=fh, stderr=subprocess.STDOUT)
    if proc.returncode:
        raise RuntimeError(f"command failed. Read {log}")


def _tag(wid: int) -> str:
    return f"{wid:02d}"


def _source_required(out: Path, wid: int) -> list[Path]:
    tag = _tag(wid)
    return [out / f"{p}{tag}{s}" for p, s in (("wp", ".json"), ("ti", ".npz"), ("lk", ".json"), ("st", ".pt"), ("pr", ".csv"), ("sc", ".json"), ("mt", ".json"))]


def _target_required(out: Path, wid: int) -> list[Path]:
    tag = _tag(wid)
    return [out / f"{p}{tag}{s}" for p, s in (("ei", ".npz"), ("ev", ".pt"), ("md", ".csv"), ("sl", ".json"))]


def _remove_world(out: Path, wid: int, target_only: bool = False) -> None:
    tag = _tag(wid)
    prefixes = ("ei", "ev", "md", "sl") if target_only else ("wp", "ti", "lk", "st", "pr", "sc", "mt", "mo", "se", "ei", "ev", "md", "sl")
    for prefix in prefixes:
        for path in out.glob(f"{prefix}{tag}.*"):
            path.unlink(missing_ok=True)
    if not target_only:
        (out / f"s{tag}.ok").unlink(missing_ok=True)
    (out / f"t{tag}.ok").unlink(missing_ok=True)


def _source_one(plan: Path, out: Path, logs: Path, tmp_root: Path, seed: int, wid: int) -> None:
    marker = out / f"s{_tag(wid)}.ok"
    if marker.exists() and all(path.exists() for path in _source_required(out, wid)):
        return
    out.mkdir(parents=True, exist_ok=True)
    _remove_world(out, wid)
    tmp = tmp_root / f"s-{out.name}-{wid}"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    cmd = [sys.executable, str(ROOT / "stage.py"), "source", "--plan", str(plan), "--out", str(tmp), "--seed", str(seed), "--world", str(wid)]
    _run(cmd, logs / f"s-{out.name}-{wid}.txt")
    required = _source_required(tmp, wid)
    if not all(path.exists() for path in required):
        raise RuntimeError(f"source stage did not finish world {wid}")
    for path in tmp.iterdir():
        shutil.move(str(path), str(out / path.name))
    shutil.rmtree(tmp, ignore_errors=True)
    marker.write_text("ok\n")


def _target_one(plan: Path, out: Path, logs: Path, seed: int, wid: int) -> None:
    marker = out / f"t{_tag(wid)}.ok"
    if marker.exists() and all(path.exists() for path in _target_required(out, wid)):
        return
    _remove_world(out, wid, target_only=True)
    cmd = [sys.executable, str(ROOT / "stage.py"), "target", "--plan", str(plan), "--out", str(out), "--seed", str(seed), "--world", str(wid)]
    _run(cmd, logs / f"t-{out.name}-{wid}.txt")
    if not all(path.exists() for path in _target_required(out, wid)):
        raise RuntimeError(f"target stage did not finish world {wid}")
    marker.write_text("ok\n")


def _parallel(fn, values: list[int], jobs: int) -> None:
    if not values:
        return
    with cf.ThreadPoolExecutor(max_workers=jobs) as pool:
        futures = [pool.submit(fn, value) for value in values]
        for future in cf.as_completed(futures):
            future.result()


def _sel(path: Path, seed: int, ids: list[int], screened: list[int] | None = None) -> dict:
    value = {
        "schema": "riwf-world-selection-v1",
        "seed": int(seed),
        "selected": [int(x) for x in ids],
        "ids": [int(x) for x in ids],
        "screened": [int(x) for x in (screened if screened is not None else ids)],
        "screened_n": len(screened if screened is not None else ids),
    }
    value["sha256"] = _hash(value)
    _write(path, value)
    return value


def _fixed_source(plan: dict, plan_path: Path, root: Path, logs: Path, tmp: Path, key: str, jobs: int) -> dict:
    cohort = plan["cohorts"][key]
    out = root / key
    ids = list(range(int(cohort["worlds"])))
    _parallel(lambda wid: _source_one(plan_path, out, logs, tmp, int(cohort["seed"]), wid), ids, jobs)
    return _sel(out / "sel.json", int(cohort["seed"]), ids)


def _screen_source(plan: dict, plan_path: Path, root: Path, logs: Path, tmp: Path, key: str, jobs: int) -> dict:
    cohort = plan["cohorts"][key]
    out = root / key
    out.mkdir(parents=True, exist_ok=True)
    sel_path = out / "sel.json"
    if sel_path.exists():
        value = json.loads(sel_path.read_text())
        if _hash(value) != value.get("sha256"):
            raise RuntimeError(f"bad selection hash in {sel_path}")
        return value
    target = int(plan["screening"]["target_disagreements_per_replication"])
    maximum = int(plan["screening"]["max_worlds_per_replication"])
    batch = int(plan["screening"]["batch_worlds"])
    seed = int(cohort["seed"])
    screened = sorted(int(path.stem[1:]) for path in out.glob("s*.ok"))
    next_id = max(screened, default=-1) + 1
    while True:
        receipts = []
        for wid in sorted(screened):
            path = out / f"sc{_tag(wid)}.json"
            if path.exists():
                receipts.append((wid, json.loads(path.read_text())))
        stable = [wid for wid, rec in receipts if rec.get("stable_disagreement")]
        if len(stable) >= target:
            return _sel(sel_path, seed, stable[:target], sorted(screened))
        if next_id >= maximum:
            raise RuntimeError(f"{key} reached {maximum} screened worlds with only {len(stable)} stable disagreements")
        ids = list(range(next_id, min(maximum, next_id + batch)))
        _parallel(lambda wid: _source_one(plan_path, out, logs, tmp, seed, wid), ids, jobs)
        screened.extend(ids)
        screened = sorted(set(screened))
        next_id = max(screened) + 1
        _write(root / "state.json", {"stage": "screening", "cohort": key, "screened": len(screened), "stable": len(stable)})


def _open(root: Path, sels: dict[str, dict]) -> dict:
    path = root / "open.json"
    value = {
        "schema": "riwf-target-open-v1",
        "source_complete": True,
        "selection_hashes": {key: val["sha256"] for key, val in sels.items()},
        "target_truth_opened_after_all_source_locks": True,
        "time_ns": time.time_ns(),
    }
    value["sha256"] = _hash(value)
    if path.exists():
        old = json.loads(path.read_text())
        if old.get("selection_hashes") != value["selection_hashes"] or _hash(old) != old.get("sha256"):
            raise RuntimeError("existing target-open record disagrees with source selection")
        return old
    for key, sel in sels.items():
        out = root / key
        for wid in sel["screened"]:
            if any((out / f"{p}{_tag(int(wid))}{s}").exists() for p, s in (("ei", ".npz"), ("ev", ".pt"), ("md", ".csv"), ("sl", ".json"))):
                raise RuntimeError("target output exists before global target-open record")
    _write(path, value)
    return value


def _target_all(plan: dict, plan_path: Path, root: Path, logs: Path, sels: dict[str, dict], jobs: int) -> None:
    for key, sel in sels.items():
        seed = int(sel["seed"])
        out = root / key
        ids = [int(x) for x in sel["selected"]]
        _parallel(lambda wid: _target_one(plan_path, out, logs, seed, wid), ids, jobs)


def _post(plan_path: Path, root: Path, sels: dict[str, dict], jobs: int) -> None:
    for key, sel in sels.items():
        out = root / key
        ids_path = out / "sel.json"
        _run([sys.executable, str(ROOT / "ana2.py"), "--dir", str(out), "--tag", key, "--expect", str(len(sel["selected"])), "--ids", str(ids_path)], root / "log" / f"a-{key}.txt")
        _run([sys.executable, str(ROOT / "audit.py"), "--dir", str(out), "--expect", str(len(sel["selected"])), "--ids", str(ids_path)], root / "log" / f"u-{key}.txt")
        if key.startswith("screen"):
            _run([sys.executable, str(ROOT / "scaud.py"), "--plan", str(plan_path), "--dir", str(out), "--sel", str(ids_path), "--open", str(root / "open.json")], root / "log" / f"s-{key}.txt")
    _run([sys.executable, str(ROOT / "master.py"), "--root", str(root)], root / "log" / "master.txt")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", type=Path, default=ROOT / "plan.json")
    ap.add_argument("--out", type=Path, default=ROOT / "out")
    ap.add_argument("--jobs", type=int, default=max(1, min(6, (os.cpu_count() or 4) // 2)))
    ap.add_argument("--source-only", action="store_true")
    ns = ap.parse_args()
    plan = json.loads(ns.plan.read_text())
    root = ns.out.resolve()
    logs = root / "log"
    tmp = root / "tmp"
    root.mkdir(parents=True, exist_ok=True)
    logs.mkdir(exist_ok=True)
    tmp.mkdir(exist_ok=True)
    _write(root / "state.json", {"stage": "source", "jobs": ns.jobs})
    sels = {
        "fixed_a": _fixed_source(plan, ns.plan, root, logs, tmp, "fixed_a", ns.jobs),
        "fixed_b": _fixed_source(plan, ns.plan, root, logs, tmp, "fixed_b", ns.jobs),
        "screen_a": _screen_source(plan, ns.plan, root, logs, tmp, "screen_a", ns.jobs),
        "screen_b": _screen_source(plan, ns.plan, root, logs, tmp, "screen_b", ns.jobs),
    }
    _write(root / "state.json", {"stage": "source_complete", "selection": {key: val["selected"] for key, val in sels.items()}})
    if ns.source_only:
        return
    _open(root, sels)
    _write(root / "state.json", {"stage": "target", "jobs": ns.jobs})
    _target_all(plan, ns.plan, root, logs, sels, ns.jobs)
    _write(root / "state.json", {"stage": "audit"})
    _post(ns.plan, root, sels, ns.jobs)
    _write(root / "state.json", {"stage": "complete", "report": str(root / "report.md")})
    print(f"complete. Read {root / 'report.md'}")


if __name__ == "__main__":
    main()
