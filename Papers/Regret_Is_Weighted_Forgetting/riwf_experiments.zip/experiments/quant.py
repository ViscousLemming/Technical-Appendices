#!/usr/bin/env python3
"""Affine-recoding-invariant fixed-budget categorical representations."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import numpy as np


FRAME_RULE = "source_fit_affine_row_basis_v1"
CANONICAL_DECIMALS = 10




@dataclass(frozen=True)
class Frame:
    origin: np.ndarray
    basis: np.ndarray
    coord_mean: np.ndarray
    coord_scale: np.ndarray
    basis_rows: np.ndarray
    source_coordinates: np.ndarray
    episodes: int
    tests: int
    hidden_dim: int

@dataclass(frozen=True)
class Quant:
    origin: np.ndarray
    basis: np.ndarray
    coord_mean: np.ndarray
    coord_scale: np.ndarray
    basis_rows: np.ndarray
    hi: np.ndarray
    lo: np.ndarray
    frame_rule: str = FRAME_RULE
    canonical_decimals: int = CANONICAL_DECIMALS

    @property
    def states(self) -> int:
        return int(len(self.hi) + len(self.lo))

    @property
    def active_dimensions(self) -> int:
        return int(self.basis.shape[0])

    @property
    def sha(self) -> str:
        h = hashlib.sha256()
        h.update(str(self.frame_rule).encode())
        h.update(str(int(self.canonical_decimals)).encode())
        for value in (
            self.origin,
            self.basis,
            self.coord_mean,
            self.coord_scale,
            self.basis_rows,
            self.hi,
            self.lo,
        ):
            arr = np.ascontiguousarray(value)
            h.update(arr.dtype.str.encode())
            h.update(str(arr.shape).encode())
            h.update(arr.tobytes())
        return h.hexdigest()


def geometry_receipt() -> dict:
    value = {
        "schema": "riwf.quant_geometry.v1",
        "frame_rule": FRAME_RULE,
        "canonical_decimals": CANONICAL_DECIMALS,
        "reference_rows": "deterministic affine basis from source-fit histories",
        "source_only": True,
        "dense_invertible_linear_recode_invariant": True,
        "affine_shift_invariant": True,
        "coordinatewise_scaling_invariant": True,
        "dataset_or_world_name_selects_geometry": False,
    }
    text = json.dumps(value, sort_keys=True, separators=(",", ":"))
    value["sha256"] = hashlib.sha256(text.encode()).hexdigest()
    return value


def _pivot_rows(row_coordinates: np.ndarray) -> np.ndarray:
    """Choose deterministic full-rank rows using rotation-invariant residual norms."""

    u = np.asarray(row_coordinates, dtype=np.float64)
    n, rank = u.shape
    residual = u.copy()
    chosen: list[int] = []
    qrows: list[np.ndarray] = []
    for _ in range(rank):
        norms = np.einsum("ij,ij->i", residual, residual)
        if chosen:
            norms[np.asarray(chosen, dtype=np.int64)] = -1.0
        index = int(np.argmax(norms))
        if not np.isfinite(norms[index]) or norms[index] <= 1.0e-20:
            raise RuntimeError("affine row basis lost rank")
        vector = residual[index].copy()
        vector /= np.linalg.norm(vector)
        nonzero = np.flatnonzero(np.abs(vector) > 1.0e-14)
        if len(nonzero) and vector[int(nonzero[0])] < 0.0:
            vector = -vector
        chosen.append(index)
        qrows.append(vector)
        q = np.asarray(qrows, dtype=np.float64)
        residual = u - (u @ q.T) @ q
    return np.asarray(chosen, dtype=np.int64)


def _fit_frame(x: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Build source-row coordinates invariant under invertible affine recoding."""

    x = np.asarray(x, dtype=np.float64)
    if x.ndim != 2 or not len(x):
        raise ValueError("hidden rows must form a nonempty matrix")
    origin = x[0].copy()
    differences = x - origin
    u, singular, _vt = np.linalg.svd(differences, full_matrices=False)
    if not singular.size:
        raise RuntimeError("source hidden matrix has no active dimension")
    tolerance = (
        max(differences.shape)
        * np.finfo(np.float64).eps
        * float(singular[0])
        * 32.0
    )
    rank = int(np.sum(singular > tolerance))
    # Current protocol uses 3,000 source histories for 32 hidden dimensions.
    # Full affine rank gives an exact source-defined coordinate map for every
    # target row. A rank-deficient frame would require a target-dependent
    # completion rule and would change declared representation family.
    if rank != x.shape[1]:
        raise RuntimeError(
            f"source hidden matrix has affine rank {rank}, expected {x.shape[1]}"
        )
    u_rank = np.asarray(u[:, :rank], dtype=np.float64)
    basis_rows = _pivot_rows(u_rank)
    pivot = u_rank[basis_rows]
    source_coordinates = u_rank @ np.linalg.inv(pivot)
    basis = differences[basis_rows].copy()
    source_coordinates = np.round(source_coordinates, decimals=CANONICAL_DECIMALS)
    reconstructed = source_coordinates @ basis + origin
    if not np.allclose(reconstructed, x, rtol=2.0e-8, atol=2.0e-8):
        error = float(np.max(np.abs(reconstructed - x)))
        raise RuntimeError(f"affine row reconstruction failed: {error}")
    coord_mean = source_coordinates.mean(axis=0)
    coord_scale = source_coordinates.std(axis=0)
    coord_scale[coord_scale < 1.0e-12] = 1.0
    z = (source_coordinates - coord_mean) / coord_scale
    return origin, basis, coord_mean, coord_scale, basis_rows, z


def _coordinates(q: Quant, hidden: np.ndarray) -> np.ndarray:
    hidden = np.asarray(hidden, dtype=np.float64)
    h = int(hidden.shape[-1])
    rows = hidden.reshape(-1, h)
    if q.basis.shape != (h, h):
        raise ValueError("quantiser affine basis does not match hidden dimension")
    coordinates = np.linalg.solve(q.basis.T, (rows - q.origin).T).T
    coordinates = np.round(coordinates, decimals=int(q.canonical_decimals))
    return (coordinates - q.coord_mean) / q.coord_scale


def _kpp(x: np.ndarray, k: int, rng: np.random.Generator) -> np.ndarray:
    n = len(x)
    cent = np.empty((k, x.shape[1]), dtype=np.float64)
    cent[0] = x[int(rng.integers(n))]
    d2 = ((x - cent[0]) ** 2).sum(1)
    for j in range(1, k):
        total = d2.sum()
        index = int(rng.integers(n)) if total <= 1.0e-15 else int(rng.choice(n, p=d2 / total))
        cent[j] = x[index]
        d2 = np.minimum(d2, ((x - cent[j]) ** 2).sum(1))
    return cent


def _fit(x: np.ndarray, k: int, seed: int, iters: int = 30) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    if len(x) < k:
        raise ValueError("fewer points than states")
    rng = np.random.default_rng(int(seed))
    cent = _kpp(x, k, rng)
    for _ in range(iters):
        distance = ((x[:, None, :] - cent[None, :, :]) ** 2).sum(2)
        labels = distance.argmin(1)
        new = cent.copy()
        nearest = distance.min(1)
        for j in range(k):
            ids = np.flatnonzero(labels == j)
            if len(ids):
                new[j] = x[ids].mean(0)
            else:
                new[j] = x[int(nearest.argmax())]
        if np.allclose(new, cent, atol=1.0e-7, rtol=1.0e-7):
            cent = new
            break
        cent = new
    return cent


def fit_frame(hidden: np.ndarray) -> Frame:
    """Fit one source-only affine frame, reusable across memory allocations."""

    hidden = np.asarray(hidden, dtype=np.float64)
    if hidden.ndim != 3:
        raise ValueError("hidden states must have shape (episodes, tests, hidden_dim)")
    n, g, h = hidden.shape
    rows = hidden.reshape(n * g, h)
    origin, basis, coord_mean, coord_scale, basis_rows, z = _fit_frame(rows)
    return Frame(origin, basis, coord_mean, coord_scale, basis_rows, z, n, g, h)


def fit_quant_frame(frame: Frame, regime: np.ndarray, khi: int, klo: int, seed: int) -> Quant:
    """Fit one categorical allocation inside a previously frozen source frame."""

    reg0 = np.asarray(regime, dtype=np.int64)
    if reg0.shape != (frame.episodes,):
        raise ValueError("regime vector does not match source frame")
    reg = np.repeat(reg0, frame.tests)
    z = np.asarray(frame.source_coordinates, dtype=np.float64)
    hi = _fit(z[reg == 1], int(khi), int(seed) + 11)
    lo = _fit(z[reg == 0], int(klo), int(seed) + 29)
    return Quant(
        frame.origin,
        frame.basis,
        frame.coord_mean,
        frame.coord_scale,
        frame.basis_rows,
        hi,
        lo,
    )


def fit_quant(hidden: np.ndarray, regime: np.ndarray, khi: int, klo: int, seed: int) -> Quant:
    """Compatibility wrapper fitting a frame and one categorical allocation."""

    return fit_quant_frame(fit_frame(hidden), regime, khi, klo, seed)


def encode(q: Quant, hidden: np.ndarray, regime: np.ndarray) -> np.ndarray:
    hidden = np.asarray(hidden, dtype=np.float64)
    n, g, _h = hidden.shape
    x = _coordinates(q, hidden)
    reg = np.repeat(np.asarray(regime, dtype=np.int64), g)
    out = np.empty(len(x), dtype=np.int64)
    hi = reg == 1
    if hi.any():
        out[hi] = ((x[hi, None, :] - q.hi[None, :, :]) ** 2).sum(2).argmin(1)
    lo = ~hi
    if lo.any():
        out[lo] = len(q.hi) + ((x[lo, None, :] - q.lo[None, :, :]) ** 2).sum(2).argmin(1)
    return out.reshape(n, g)


def permute_codes(codes: np.ndarray, khi: int, klo: int, seed: int) -> tuple[np.ndarray, dict[int, int]]:
    rng = np.random.default_rng(seed)
    phi = np.arange(khi + klo)
    phi[:khi] = rng.permutation(phi[:khi])
    phi[khi:] = rng.permutation(phi[khi:])
    return phi[codes], {int(i): int(phi[i]) for i in range(len(phi))}
