# Stable disagreement PPO confirmation

This archive reconstructs lost run source from surviving WAMF4 geometry code and recorded protocol. It is not a byte-for-byte recovery of lost files.

## Study

Four cohorts are run.

`fixed_a` and `fixed_b` each contain 24 fresh worlds. Selector agreements remain in these cohorts. Their main endpoint compares candidate ranking quality across every admitted representation.

`screen_a` and `screen_b` search fresh worlds until each cohort has 24 fold-stable selector disagreements. Screening reads source labels and input-only target panels. Target classes, posteriors, rewards, regret, and fresh target values remain sealed during screening.

A disagreement is retained only when pooled KBT and raw-impurity selectors choose different candidates and both candidate identities remain unchanged across every leave-one-panel-fold-out fit. Sixteen source-calibration folds are recorded as an audit and do not alter screening.

All source stages finish before `open.json` is written. Fresh target evaluation begins only after this record exists. Nonselected screening worlds receive no target evaluation.

## Geometry

Categorical memory uses one deterministic affine row frame fitted from source hidden states. Dense invertible affine recoding and affine shifts leave codes unchanged. One frame is reused across all five six-state memory allocations for each recurrent encoder.

## Setup

```bash
./setup.sh
./smoke.sh
```

## Full run

```bash
JOBS=6 ./run.sh
```

Rerun same command after interruption. Finished worlds are skipped. Increase or reduce `JOBS` to match available CPU capacity. Small recurrent networks favour parallel CPU workers. MPS is not required.

Progress can be read with

```bash
.venv/bin/python status.py
```

Final files appear under `out`.

`out/report.md` contains a short report.

`out/master.json` contains combined statistics.

Each cohort contains candidate records, selector locks, quantiser artefacts, source and target input archives, PPO states, independent audits, and cohort summaries.

Package completed output with

```bash
.venv/bin/python pack.py --out out --zip result.zip
```

## Expected scale

Full source stage trains 60 candidate representations per world. Fixed cohorts use 48 worlds. Screening total is data-dependent and stops after 24 stable disagreements per replication. Frozen cap is 160 screened worlds per screening replication.

A prior Linux container run averaged about 67 seconds per world with one CPU thread per world. Local wall time depends on Python build, PyTorch build, CPU load, and `JOBS`.

## Main files

`plan.json` freezes seeds, cohort sizes, screening rule, evaluation sizes, and endpoints.

`driver.py` controls chronology, resume, parallel work, target opening, analysis, and audits.

`stage.py` runs one source-lock stage or one fresh target stage.

`core.py` contains recurrent PPO candidate construction and literal binary K-rho evaluation.

`quant.py` contains affine-recoding-invariant categorical memory geometry.

`audit.py` independently recomputes candidate geometry, scores, policies, selectors, target results, and invariance checks.

`scaud.py` independently recomputes screening decisions and chronology checks.
