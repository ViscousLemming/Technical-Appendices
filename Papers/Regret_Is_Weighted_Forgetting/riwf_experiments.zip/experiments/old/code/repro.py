"""Run the configurations reported in the manuscript on CPU."""

from __future__ import annotations

import json
import os
import time

import torch

import run_experiment as exp


def main() -> None:
    torch.set_num_threads(max(1, (os.cpu_count() or 2) - 1))
    torch.manual_seed(42)
    results = {
        "version": "riwf16",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "torch_version": torch.__version__,
        "n_threads": torch.get_num_threads(),
        "device": "cpu",
    }
    common = {
        "n_states": 16,
        "n_obs": 6,
        "seq_len": 8,
        "n_trials": 20,
        "n_eval": 3000,
        "n_train": 8000,
        "d_hid": 4,
    }
    started = time.perf_counter()
    exp.run_experiment_1(results)
    exp.run_experiment_2(results, **common)
    exp.run_experiment_3(results, **common)
    exp.run_experiment_4(results, **common, n_epochs=500, eval_every=25)
    elapsed = time.perf_counter() - started
    results["total_time_seconds"] = round(elapsed, 1)
    results["total_time_minutes"] = round(elapsed / 60, 1)
    output = os.path.join(os.path.dirname(__file__), "res16.json")
    with open(output, "w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2)
    print(f"Results written to {output}")


if __name__ == "__main__":
    main()
