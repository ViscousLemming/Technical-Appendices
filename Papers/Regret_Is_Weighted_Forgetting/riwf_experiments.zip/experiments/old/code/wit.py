"""Exhaustive check of the strictness witness (Example 30 of Regret Is Weighted Forgetting).

Enumerates the whole embodied language, filters to admissible policies, and
confirms that the weighted weakness deficit strictly exceeds the partition
Bayes error because the cellwise Bayes-optimal retained set is not expressible.

Run with: python3 wit.py     (no dependencies beyond the standard library)
"""

from itertools import combinations

# Environment, vocabulary, embodied language ---------------------------------
PHI = {1, 2, 3, 4}
PROG = {'c1': {1, 2}, 'c2': {3, 4}, 'g1': {1, 3}, 'g0': {2, 4}}


def truth_set(statement):
    s = set(PHI)
    for p in statement:
        s &= PROG[p]
    return s


LV = [frozenset(c)
      for r in range(len(PROG) + 1)
      for c in combinations(PROG, r)
      if truth_set(c)]

# Lifted diagnostic support --------------------------------------------------
U = {1: frozenset({'c1', 'g1'}), 2: frozenset({'c1', 'g0'}),
     3: frozenset({'c2', 'g1'}), 4: frozenset({'c2', 'g0'})}
LABEL = {1: 1, 2: 0, 3: 1, 4: 0}
WEIGHT = {1: 0.3, 2: 0.2, 3: 0.1, 4: 0.4}
CELL = {1: 'C1', 2: 'C1', 3: 'C2', 4: 'C2'}
CELLS = ('C1', 'C2')


def mass(cell, label):
    return sum(WEIGHT[i] for i in U if CELL[i] == cell and LABEL[i] == label)


A = {c: mass(c, 1) for c in CELLS}
B = {c: mass(c, 0) for c in CELLS}
Z = sum(WEIGHT.values())
K_rho = sum(min(A[c], B[c]) for c in CELLS)
W_lift = sum(max(A[c], B[c]) for c in CELLS)


def retained(theta):
    return {i for i in U if theta <= U[i]}


def admissible(theta):
    R = retained(theta)
    return all(len({LABEL[i] for i in R if CELL[i] == c}) <= 1 for c in CELLS)


ADM = [(th, retained(th), round(sum(WEIGHT[i] for i in retained(th)), 10))
       for th in LV if admissible(th)]
W_A = max(m for _, _, m in ADM)
BAYES_OPT = {i for i in U if (CELL[i] == 'C1') == (LABEL[i] == 1)}

# Report ---------------------------------------------------------------------
print("|L_v| = %d" % len(LV))
print("A = %s   B = %s   Z = %g" % (A, B, Z))
print("K_rho(M)            = %g" % K_rho)
print("Z - W*_lift(M)      = %g   (equality on the lift)" % round(Z - W_lift, 10))
print("\nadmissible policies: %d" % len(ADM))
for th, R, m in sorted(ADM, key=lambda t: -t[2]):
    print("  %-14s retains %-12s weight %g"
          % (sorted(th) if th else '{}', sorted(R), m))
print("\nW*_A(M)             = %g" % W_A)
print("Z - W*_A(M)         = %g" % round(Z - W_A, 10))
print("strict inequality   : %s" % (round(Z - W_A, 10) > K_rho))
print("cellwise Bayes-optimal set %s expressible: %s"
      % (sorted(BAYES_OPT), any(R == BAYES_OPT for _, R, _ in ADM)))
print("every admissible retained set is a per-cell product selection: %s"
      % all(len({LABEL[i] for i in R if CELL[i] == c}) <= 1
            for _, R, _ in ADM for c in CELLS))

assert len(LV) == 9
assert len(ADM) == 6
assert abs(K_rho - 0.3) < 1e-12
assert abs((Z - W_lift) - K_rho) < 1e-12
assert abs(W_A - 0.6) < 1e-12
assert round(Z - W_A, 10) > K_rho
assert not any(R == BAYES_OPT for _, R, _ in ADM)
print("\nall assertions passed")
