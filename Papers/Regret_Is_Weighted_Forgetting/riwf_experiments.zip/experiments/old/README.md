# Regret Is Weighted Forgetting

This archive accompanies the Proceedings A submission.

## Contents

- `code/run_experiment.py` runs the Boolean verification and the three structured-POMDP studies reported in the paper. It writes `code/res16.json`.
- `code/repro.py` runs the same reported configuration on CPU with every parameter fixed in one entry point.
- `code/res16.json` contains the reproduced aggregate measurements and every trial record.
- `code/run_experiment_rl.py` runs the four auxiliary-loss studies discussed in Section 9. It checkpoints each environment-condition pair.
- `code/results_v27_rl.json` contains the per-seed auxiliary-loss curves. The producing script differs from `run_experiment_rl.py` only in its version and output-file labels.
- `code/verify_reduction.py` checks the finite regret identity on a small example.
- `code/wit.py` constructs the strictness witness from the paper.
- `code/test.py` runs the unit tests.
- `code/sts/` contains the Stack Theory Suite snapshot used for the Boolean verification.
- `tests.txt` records the complete test result.

## Installation

Create a Python environment, then run:

```bash
python -m pip install -r deps.txt
```

## Reproduction

From this directory, run:

```bash
cd code
python test.py
python repro.py
```

`repro.py` fixes the structured POMDP at 16 states and 6 observations, sequence length 8, 20 trials, 8,000 training sequences, 3,000 evaluation sequences, and hidden width 4. It fixes the PyTorch seed at 42. Individual experiment functions fix their NumPy or Python seeds.

The auxiliary-loss study is longer:

```bash
python run_experiment_rl.py
```

It runs four environments, four training conditions, and ten seeds from 1000 through 1009. It resumes from its JSON checkpoint.

## Recorded environment

I reproduced `res16.json` on an Apple M5 Max with 18 CPU cores and 128 GB RAM under macOS 26.5.1. I used Python 3.12.13, PyTorch 2.12.0, and NumPy 2.4.6. The run used 17 CPU threads and took 66.7 seconds.

The auxiliary-loss JSON records an MPS run of 10 seeds completed in 15,718.8 seconds. Its initial environment metadata did not retain the processor, memory, operating-system, or library versions.

## Licence

The software in `code/` is licensed under the MIT License. See
`code/LICENSE`.

The experimental results in the JSON files and `tests.txt` are licensed
under the Creative Commons Attribution 4.0 International licence. See
<https://creativecommons.org/licenses/by/4.0/>.
