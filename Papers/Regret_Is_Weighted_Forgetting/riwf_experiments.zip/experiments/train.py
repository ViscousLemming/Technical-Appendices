#!/usr/bin/env python3
"""Train one recurrent PPO base model in an isolated process."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[key] = "1"

import numpy as np
import torch

from env import World
from net import NetSpec
from ppo import TrainCfg, train_one


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--world", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--arch", required=True)
    parser.add_argument("--focus", required=True)
    parser.add_argument("--hidden", type=int, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--lr", type=float, required=True)
    parser.add_argument("--ent", type=float, required=True)
    parser.add_argument("--obs", type=int, required=True)
    parser.add_argument("--base", type=int, required=True)
    parser.add_argument("--updates", type=int, required=True)
    parser.add_argument("--episodes", type=int, required=True)
    parser.add_argument("--epochs", type=int, required=True)
    parser.add_argument("--minibatch", type=int, required=True)
    parser.add_argument("--delays", type=int, nargs="+", required=True)
    parser.add_argument("--snaps", type=int, nargs="+", required=True)
    args = parser.parse_args()

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.backends.mkldnn.enabled = True
    torch.use_deterministic_algorithms(True)

    data = json.loads(args.world.read_text())
    data["tests"] = np.asarray(data["tests"], dtype=np.int64)
    world = World(**data)
    spec = NetSpec(args.arch, args.focus, args.hidden, args.seed, args.lr, args.ent)
    cfg = TrainCfg(args.updates, args.episodes, args.epochs, args.minibatch)
    snaps, meta = train_one(world, spec, args.obs, args.delays, args.base, cfg, args.snaps)
    torch.save({"snaps": snaps, "meta": meta}, args.out)


if __name__ == "__main__":
    main()
