#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if command -v sha256sum >/dev/null 2>&1; then
  sha256sum -c SHA256.txt
elif command -v shasum >/dev/null 2>&1; then
  shasum -a 256 -c SHA256.txt
else
  echo "A SHA-256 checker is required"
  exit 1
fi

python3 - <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import os
from pathlib import Path

root = Path.cwd()
pub = root / "pub"


def record_hash(value: dict) -> str:
    copied = dict(value)
    copied.pop("sha256", None)
    text = json.dumps(copied, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(text.encode()).hexdigest()

for line in (root / "MTIME.txt").read_text().splitlines():
    timestamp, name = line.split("  ", 1)
    path = root / name
    value = int(timestamp)
    os.utime(path, ns=(value, value))

for path in pub.rglob("*"):
    if path.suffix in {".pt", ".npz", ".ok"}:
        raise SystemExit(f"Excluded artifact found at {path.relative_to(root)}")
if (pub / "log").exists():
    raise SystemExit("Excluded log directory found")

state = json.loads((pub / "state.json").read_text())
master = json.loads((pub / "master.json").read_text())
opened = json.loads((pub / "open.json").read_text())
checks = {
    "state_complete": state.get("stage") == "complete",
    "combined_pass": master.get("pass") is True,
    "fixed_pass": master.get("decision", {}).get("fixed_pass") is True,
    "conditional_pass": master.get("decision", {}).get("conditional_pass") is True,
    "cohort_audits": all(master.get("audits", {}).values()),
    "screen_audits": all(master.get("screen_audit", {}).values()),
    "report_exists": (pub / "report.md").is_file(),
    "open_hash": record_hash(opened) == opened.get("sha256"),
    "source_complete": opened.get("source_complete") is True,
    "opening_rule": opened.get("target_truth_opened_after_all_source_locks") is True,
}

expected = {
    "fixed_a": (24, 24),
    "fixed_b": (24, 24),
    "screen_a": (24, 128),
    "screen_b": (24, 96),
}
for cohort, (selected_count, screened_count) in expected.items():
    folder = pub / cohort
    selection = json.loads((folder / "sel.json").read_text())
    selected = [int(value) for value in selection.get("selected", [])]
    screened = [int(value) for value in selection.get("screened", [])]
    checks[f"{cohort}_selection_hash"] = record_hash(selection) == selection.get("sha256")
    checks[f"{cohort}_opening_hash"] = (
        opened.get("selection_hashes", {}).get(cohort) == selection.get("sha256")
    )
    checks[f"{cohort}_selected"] = len(selected) == selected_count and len(set(selected)) == selected_count
    checks[f"{cohort}_screened"] = (
        len(screened) == screened_count
        and len(set(screened)) == screened_count
        and int(selection.get("screened_n", -1)) == screened_count
    )
    checks[f"{cohort}_audit"] = json.loads((folder / "audx.json").read_text()).get("pass") is True
    stable = []
    for world in screened:
        for prefix, suffix in (("wp", ".json"), ("sc", ".json"), ("lk", ".json"), ("mt", ".json"), ("pr", ".csv")):
            if not (folder / f"{prefix}{world:02d}{suffix}").is_file():
                raise SystemExit(f"Missing {cohort} screening record for world {world}")
        receipt = json.loads((folder / f"sc{world:02d}.json").read_text())
        lock = json.loads((folder / f"lk{world:02d}.json").read_text())
        if record_hash(receipt) != receipt.get("sha256"):
            raise SystemExit(f"Invalid {cohort} screening hash for world {world}")
        if record_hash(lock) != lock.get("sha256"):
            raise SystemExit(f"Invalid {cohort} lock hash for world {world}")
        if int(receipt.get("world", -1)) != world or receipt.get("screening_uses_target_truth") is not False:
            raise SystemExit(f"Invalid {cohort} screening record for world {world}")
        if receipt.get("stable_disagreement") is True:
            stable.append(world)
    if cohort.startswith("screen_") and selected != stable[:selected_count]:
        raise SystemExit(f"{cohort} selection is not the first {selected_count} stable receipts")

    md_worlds = {int(path.stem[2:]) for path in folder.glob("md*.csv")}
    sl_worlds = {int(path.stem[2:]) for path in folder.glob("sl*.json")}
    if md_worlds != set(selected) or sl_worlds != set(selected):
        raise SystemExit(f"{cohort} target records differ from selected worlds")
    for world in selected:
        table = folder / f"md{world:02d}.csv"
        selector = folder / f"sl{world:02d}.json"
        if not table.is_file() or not selector.is_file():
            raise SystemExit(f"Missing {cohort} result for world {world}")
        with table.open(newline="") as handle:
            rows = list(csv.DictReader(handle))
        if len(rows) != 60 or {int(row["world"]) for row in rows} != {world}:
            raise SystemExit(f"Malformed {cohort} table for world {world}")

failed = [name for name, value in checks.items() if not value]
if failed:
    raise SystemExit("Failed result checks\n" + "\n".join(failed))
print(f"Recorded results passed {len(checks)} checks")
PY

PYTHON=""
if [[ -x .venv/bin/python ]]; then
  PYTHON=.venv/bin/python
elif python3 -c 'import numpy, pandas, scipy' >/dev/null 2>&1; then
  PYTHON=python3
fi

if [[ -n "$PYTHON" ]]; then
  "$PYTHON" stats.py --root pub
else
  echo "Statistical recomputation skipped. Run setup.sh and then run verify.sh again."
fi
