# Binary K_rho recurrent PPO test

Status: fixed_a

Worlds: 24

Candidates: 1440

KBT fresh target K_rho: 0.099800

Raw-impurity selection fresh target K_rho: 0.101551

Paired K_rho reduction: 0.001752

95% bootstrap interval: [0.000462, 0.003236]

One-sided exact sign-flip p: 0.01171875

Wins, ties, losses: 8, 15, 1

Actual normalised-regret reduction under one common panel-fitted K policy: 0.002608

Sampled target-success gain: 0.004566

KBT source empirical reward: 0.540093

Raw source empirical reward: 0.539109

Expected target-return gain: 0.003410

Native PPO target-return gain: 0.002210

KBT oracle match rate: 0.791667

Mean within-world rank correlation between panel estimate and fresh target K_rho: 0.975634

Mean absolute K_rho estimation error: 0.006062

KBT candidate-ranking Spearman: 0.955841

Raw-impurity candidate-ranking Spearman: 0.906367

Paired ranking-correlation gain: 0.049474

Ranking 95% interval: [0.022232, 0.079700]

Ranking sign-flip p: 0.00063801

KBT mean rare-regime states: 1.708333

Raw mean rare-regime states: 1.458333

Primary pass: True

Audit pass: True
