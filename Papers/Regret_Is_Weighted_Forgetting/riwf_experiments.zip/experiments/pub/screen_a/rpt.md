# Binary K_rho recurrent PPO test

Status: screen_a

Worlds: 24

Candidates: 1440

KBT fresh target K_rho: 0.089779

Raw-impurity selection fresh target K_rho: 0.096360

Paired K_rho reduction: 0.006581

95% bootstrap interval: [0.004887, 0.008294]

One-sided exact sign-flip p: 0.00000048

Wins, ties, losses: 21, 0, 3

Actual normalised-regret reduction under one common panel-fitted K policy: 0.008707

Sampled target-success gain: 0.012234

KBT source empirical reward: 0.532546

Raw source empirical reward: 0.528924

Expected target-return gain: 0.012754

Native PPO target-return gain: 0.013816

KBT oracle match rate: 0.791667

Mean within-world rank correlation between panel estimate and fresh target K_rho: 0.970535

Mean absolute K_rho estimation error: 0.009132

KBT candidate-ranking Spearman: 0.961252

Raw-impurity candidate-ranking Spearman: 0.866101

Paired ranking-correlation gain: 0.095151

Ranking 95% interval: [0.064201, 0.127955]

Ranking sign-flip p: 0.00000089

KBT mean rare-regime states: 2.750000

Raw mean rare-regime states: 1.375000

Primary pass: True

Audit pass: True
