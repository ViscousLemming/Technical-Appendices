# Stable-disagreement PPO confirmation

Fixed-world ranking gain

0.048911 with 95 percent interval [0.032299, 0.066819] and one-sided sign-flip p 0.00000000.

Fixed-world unconditional target K-rho gain

0.001828 with 95 percent interval [0.000748, 0.003016] and one-sided sign-flip p 0.00072000.

Stable-disagreement target K-rho gain

0.006096 with 95 percent interval [0.004713, 0.007485] and one-sided sign-flip p 0.00000000.

Stable-disagreement regret gain

0.008340 with 95 percent interval [0.006753, 0.009916].

Stable-disagreement target-success gain

0.013044 with 95 percent interval [0.010697, 0.015593].

Screening

Replication A retained 24 stable disagreements from 128 screened worlds.

Replication B retained 24 stable disagreements from 96 screened worlds.

All audits passed

True
