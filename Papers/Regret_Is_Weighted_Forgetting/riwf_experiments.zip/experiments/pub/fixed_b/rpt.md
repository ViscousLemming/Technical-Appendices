# Binary K_rho recurrent PPO test

Status: fixed_b

Worlds: 24

Candidates: 1440

KBT fresh target K_rho: 0.100231

Raw-impurity selection fresh target K_rho: 0.102136

Paired K_rho reduction: 0.001905

95% bootstrap interval: [0.000263, 0.003808]

One-sided exact sign-flip p: 0.01953125

Wins, ties, losses: 12, 10, 2

Actual normalised-regret reduction under one common panel-fitted K policy: 0.003588

Sampled target-success gain: 0.007332

KBT source empirical reward: 0.544323

Raw source empirical reward: 0.542957

Expected target-return gain: 0.005593

Native PPO target-return gain: 0.010433

KBT oracle match rate: 0.833333

Mean within-world rank correlation between panel estimate and fresh target K_rho: 0.975227

Mean absolute K_rho estimation error: 0.006192

KBT candidate-ranking Spearman: 0.963100

Raw-impurity candidate-ranking Spearman: 0.914752

Paired ranking-correlation gain: 0.048348

Ranking 95% interval: [0.030646, 0.068734]

Ranking sign-flip p: 0.00000155

KBT mean rare-regime states: 2.125000

Raw mean rare-regime states: 1.291667

Primary pass: True

Audit pass: True
