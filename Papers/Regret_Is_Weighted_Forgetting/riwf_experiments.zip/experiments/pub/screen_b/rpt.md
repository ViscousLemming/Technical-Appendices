# Binary K_rho recurrent PPO test

Status: screen_b

Worlds: 24

Candidates: 1440

KBT fresh target K_rho: 0.091710

Raw-impurity selection fresh target K_rho: 0.097320

Paired K_rho reduction: 0.005610

95% bootstrap interval: [0.003499, 0.007785]

One-sided exact sign-flip p: 0.00001907

Wins, ties, losses: 22, 0, 2

Actual normalised-regret reduction under one common panel-fitted K policy: 0.007973

Sampled target-success gain: 0.013854

KBT source empirical reward: 0.537135

Raw source empirical reward: 0.531366

Expected target-return gain: 0.011998

Native PPO target-return gain: 0.011718

KBT oracle match rate: 0.791667

Mean within-world rank correlation between panel estimate and fresh target K_rho: 0.964323

Mean absolute K_rho estimation error: 0.005823

KBT candidate-ranking Spearman: 0.950481

Raw-impurity candidate-ranking Spearman: 0.844239

Paired ranking-correlation gain: 0.106242

Ranking 95% interval: [0.069223, 0.146429]

Ranking sign-flip p: 0.00000012

KBT mean rare-regime states: 2.750000

Raw mean rare-regime states: 1.250000

Primary pass: True

Audit pass: True
