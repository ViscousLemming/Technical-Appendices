#!/usr/bin/env python3
"""Run one source-lock stage or one sealed target-evaluation stage."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import torch

import core
from calib import crossfit_q
from env import World, action_values, estimate_post, make_bank


def _hash(obj: dict) -> str:
    text = json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(text.encode()).hexdigest()


def _args(plan: dict, out: Path, seed: int) -> SimpleNamespace:
    p = plan["protocol"]
    return SimpleNamespace(
        out=out,
        seed=int(seed),
        start=0,
        worlds=1,
        classes=int(p["classes"]),
        gates=int(p["gates"]),
        cues=int(p["cues"]),
        distractors=int(p["distractors"]),
        src=[int(x) for x in p["source_delays"]],
        tgt=[int(x) for x in p["target_delays"]],
        train_n=int(p["source_fit_n"]),
        cal_n=int(p["source_calibration_n"]),
        val_n=int(p["source_validation_n"]),
        panel_n=int(p["target_panel_n"]),
        eval_n=int(p["fresh_target_evaluation_n"]),
        updates=int(p["updates"]),
        snap=[int(x) for x in p["snapshots"]],
        episodes=int(p["episodes"]),
        epochs=int(p["epochs"]),
        minibatch=int(p["minibatch"]),
        hidden=int(p["hidden_units"]),
        lr=float(p["learning_rate"]),
        ent=float(p["entropy_coefficient"]),
        states=int(p["representation_states"]),
        band=float(p["admission_band"]),
        min_admit=int(p["minimum_admitted"]),
    )


def _world(path: Path) -> World:
    data = json.loads(path.read_text())
    data["tests"] = np.asarray(data["tests"], dtype=np.int64)
    return World(**data)


def _panel_folds(regime: np.ndarray, delays: np.ndarray, folds: int, seed: int) -> tuple[np.ndarray, ...]:
    regime = np.asarray(regime, dtype=np.int64)
    delays = np.asarray(delays, dtype=np.int64)
    if regime.shape != delays.shape:
        raise ValueError("panel fields disagree")
    rng = np.random.default_rng(int(seed))
    parts: list[list[int]] = [[] for _ in range(int(folds))]
    keys = regime * 100000 + delays
    for value in np.unique(keys):
        ids = np.flatnonzero(keys == value).copy()
        rng.shuffle(ids)
        for fid, block in enumerate(np.array_split(ids, folds)):
            parts[fid].extend(int(x) for x in block)
    out = tuple(np.asarray(sorted(x), dtype=np.int64) for x in parts)
    joined = np.concatenate(out)
    if len(joined) != len(regime) or len(np.unique(joined)) != len(regime):
        raise RuntimeError("panel folds are not a partition")
    return out


def _winner(pre: pd.DataFrame, admitted: list[int], scores: dict[int, tuple[float, float]], kind: str) -> int:
    frame = pre[pre.candidate.isin(admitted)].copy()
    if kind == "kbt":
        frame["score"] = [scores[int(x)][0] for x in frame.candidate]
    elif kind == "raw":
        frame["score"] = [scores[int(x)][1] for x in frame.candidate]
    else:
        raise ValueError(kind)
    return int(
        frame.sort_values(
            ["score", "src_hit", "src_reg"],
            ascending=[True, False, True],
        ).iloc[0].candidate
    )


def _screen(plan: dict, args: SimpleNamespace, wid: int, out: Path, world: World, pre: pd.DataFrame, artifacts: list[dict], lock: dict) -> dict:
    wseed = int(lock["world_seed"])
    panel = core.load_input(out / f"ti{wid:02d}.npz")
    admitted = [int(x) for x in lock["admitted"]]
    art = {int(x["candidate"]): x for x in artifacts}

    panel_hat = action_values(
        estimate_post(panel, float(lock["qhat"][0]), float(lock["qhat"][1]), world.classes),
        world.tests,
    )
    panel_folds = _panel_folds(
        panel.regime,
        panel.delays,
        int(plan["screening"]["panel_folds"]),
        wseed + int(plan["screening"]["panel_fold_seed_offset"]),
    )
    panel_k: list[int] = []
    panel_r: list[int] = []
    panel_rows: list[dict] = []
    for fid, held in enumerate(panel_folds):
        keep = np.ones(len(panel.obs), dtype=bool)
        keep[held] = False
        scores = {}
        for cid in admitted:
            codes = np.asarray(art[cid]["panel_codes"], dtype=np.int64)
            value = core.cell_scores(codes[keep], panel_hat[keep])
            scores[cid] = (float(value["krho"]), float(value["imp"]))
        kwin = _winner(pre, admitted, scores, "kbt")
        rwin = _winner(pre, admitted, scores, "raw")
        panel_k.append(kwin)
        panel_r.append(rwin)
        panel_rows.append(
            {
                "fold": fid,
                "held_n": int(len(held)),
                "held_sha256": hashlib.sha256(np.ascontiguousarray(held).tobytes()).hexdigest(),
                "kbt": kwin,
                "raw": rwin,
            }
        )

    src_cal = make_bank(world, args.cal_n, args.src, wseed + 2)
    qfold = crossfit_q(
        src_cal,
        int(plan["screening"]["source_calibration_folds"]),
        wseed + int(plan["screening"]["source_fold_seed_offset"]),
    )
    src_k: list[int] = []
    src_r: list[int] = []
    src_rows: list[dict] = []
    for fid, (qh, ql) in enumerate(qfold.q):
        values = action_values(estimate_post(panel, qh, ql, world.classes), world.tests)
        scores = {}
        for cid in admitted:
            codes = np.asarray(art[cid]["panel_codes"], dtype=np.int64)
            value = core.cell_scores(codes, values)
            scores[cid] = (float(value["krho"]), float(value["imp"]))
        kwin = _winner(pre, admitted, scores, "kbt")
        rwin = _winner(pre, admitted, scores, "raw")
        src_k.append(kwin)
        src_r.append(rwin)
        src_rows.append(
            {
                "fold": fid,
                "held_n": len(qfold.held[fid]),
                "q_high": float(qh),
                "q_low": float(ql),
                "kbt": kwin,
                "raw": rwin,
            }
        )

    pooled_k = int(lock["selectors"]["kbt"])
    pooled_r = int(lock["selectors"]["raw"])
    panel_stable = bool(all(x == pooled_k for x in panel_k) and all(x == pooled_r for x in panel_r))
    source_stable = bool(all(x == pooled_k for x in src_k) and all(x == pooled_r for x in src_r))
    receipt = {
        "schema": "riwf-stable-disagreement-v1",
        "world": int(wid),
        "world_seed": wseed,
        "pooled": {"kbt": pooled_k, "raw": pooled_r},
        "disagreement": pooled_k != pooled_r,
        "panel_stable": panel_stable,
        "source_calibration_stable": source_stable,
        "stable_disagreement": bool(pooled_k != pooled_r and panel_stable),
        "screening_uses_target_truth": False,
        "panel_folds": panel_rows,
        "source_calibration_folds": src_rows,
        "source_stability_is_audit_only": True,
    }
    receipt["sha256"] = _hash(receipt)
    return receipt


def source(plan: dict, out: Path, seed: int, wid: int) -> None:
    args = _args(plan, out, seed)
    world, pre, states, artifacts, lock, _world_file = core.phase_a(args, wid, out)
    receipt = _screen(plan, args, wid, out, world, pre, artifacts, lock)
    (out / f"sc{wid:02d}.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    meta = {
        "schema": "riwf-sd-source-v1",
        "quantity": "literal_binary_K_rho",
        "representation_geometry": core.geometry_receipt(),
        "config": {key: (str(value) if isinstance(value, Path) else value) for key, value in vars(args).items()},
        "world": int(wid),
        "world_seed": int(lock["world_seed"]),
        "screen": receipt,
        "target_evaluated": False,
    }
    (out / f"mt{wid:02d}.json").write_text(json.dumps(meta, indent=2, sort_keys=True) + "\n")
    print(json.dumps(receipt, sort_keys=True))


def target(plan: dict, out: Path, seed: int, wid: int) -> None:
    args = _args(plan, out, seed)
    world_file = out / f"wp{wid:02d}.json"
    world = _world(world_file)
    pre = pd.read_csv(out / f"pr{wid:02d}.csv")
    stored = torch.load(out / f"st{wid:02d}.pt", map_location="cpu", weights_only=False)
    lock = json.loads((out / f"lk{wid:02d}.json").read_text())
    core.phase_b(args, world, pre, stored["models"], stored["artifacts"], lock, world_file, out)
    meta_path = out / f"mt{wid:02d}.json"
    meta = json.loads(meta_path.read_text())
    meta["target_evaluated"] = True
    meta["eval_seed"] = int(lock["eval_seed"])
    meta_path.write_text(json.dumps(meta, indent=2, sort_keys=True) + "\n")
    print(f"target complete {wid}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("source", "target"))
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--world", type=int, required=True)
    ns = parser.parse_args()
    plan = json.loads(ns.plan.read_text())
    ns.out.mkdir(parents=True, exist_ok=True)
    if ns.mode == "source":
        source(plan, ns.out, ns.seed, ns.world)
    else:
        target(plan, ns.out, ns.seed, ns.world)


if __name__ == "__main__":
    main()
