# Reviewer guide

## Package scope

I include the frozen study plan, source code, dependency records, provenance, screening records, selection locks, every selected-world numerical table, cohort summaries, figures, audit records, and combined result.

I omit PyTorch state archives, generated input arrays, completion markers, and execution logs. These deterministic intermediate artifacts occupied about 548 MiB in the 560 MiB archival ZIP. A fresh run regenerates them from the frozen seeds and settings.

The recorded tensor audits remain under `pub`. Repeating those audits against the recorded execution requires the archival ZIP. A fresh run executes the same audits against newly regenerated artifacts.

`SCOPE.json` records the inclusion and exclusion counts.

All commands below start in the extracted `RIWF` directory.

## Archive and result check

Run

```bash
./verify.sh
```

This checks every included file against `SHA256.txt`, restores recorded file times, checks the completion record and cohort structure, and rejects excluded artifact types. If the Python environment exists, it also recomputes the reported endpoints from the per-world tables.

To install the tested environment and repeat the statistical check, run

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r lock.txt
./verify.sh
```

If an exact locked wheel is unavailable on another platform, use

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r req.txt
./verify.sh
```

The statistical check reads each `mdNN.csv`, `slNN.json`, and `lkNN.json`. It reconstructs the selected-candidate deployment contrasts and admitted-candidate rank correlations, recomputes the bootstrap intervals and sign-flip tests, and compares them with `pub/master.json`.

## Recorded result

The combined decision is `pass = true`.

Fixed-world ranking gain is `0.048911` with a 95 percent interval of `[0.032299, 0.066819]`.

Fixed-world unconditional target K-rho gain is `0.001828` with a 95 percent interval of `[0.000748, 0.003016]`.

Stable-disagreement target K-rho gain is `0.006096` with a 95 percent interval of `[0.004713, 0.007485]`.

Replication A retained 24 stable disagreements from 128 screened worlds. Replication B retained 24 from 96 screened worlds.

Read `pub/report.md` for the report and `pub/master.json` for the combined statistics.

## Independent full run

The recorded result is under `pub`. The launcher writes a fresh run under `out`.

Run the unit checks and one small end-to-end world with

```bash
./m5.sh test
./m5.sh smoke
```

Run the complete experiment with

```bash
JOBS=6 ./m5.sh run
```

Repeat the same command after interruption. Finished worlds are skipped. Read `out/state.json` for progress and `out/report.md` after completion.

The M5 Max run used six CPU workers and took about 1 hour 47 minutes. Allow 12 GB for the environment, generated artifacts, and recorded results.

`driver0.py` records the launcher used for the completed experiment. `driver.py` changes one completion-marker condition so an interrupted target stage retains its completed source marker. This bookkeeping correction changes no numerical operation. The standard launcher uses `driver.py`.

## Chronology record

The first complete run wrote `open.json` after every source selection locked and then finished with a passing result. A temporary macOS launch job restarted the driver once after completion. The second deterministic pass regenerated the fixed A and fixed B artifacts after the recorded opening time. Fixed source stages use source data and frozen seeds.

I stopped the redundant job, recomputed both fixed-cohort analyses and audits, and regenerated the combined report. The screening artifacts remained from the first pre-opening stages. Both screening chronology audits pass.

The opening record documents the first run. The stored fixed-cohort records document deterministic recomputation and fresh audit passage.

## File map

`plan.json` fixes seeds, cohort sizes, screening rules, evaluation sizes, and endpoints.

`driver.py` controls chronology, resumption, target opening, analyses, and audits.

`pub/open.json` records target opening after every source cohort locked.

`pub/fixed_a` and `pub/fixed_b` contain the fixed-world replications.

`pub/screen_a` and `pub/screen_b` contain the stable-disagreement replications.

Each cohort includes world parameters, screening receipts, selector locks, source candidate tables, selected-world target tables, summaries, figures, and audit records.

Absolute paths in recorded metadata identify the original M5 host. Commands in this guide use paths relative to the extracted directory.

`prov.md` records reconstruction provenance.
