#!/usr/bin/env python3
"""Combine fixed-world and stable-disagreement replication results."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.stats import combine_pvalues

from ana2 import boot, signflip


def stat(values: list[float], seed: int) -> dict:
    x = np.asarray(values, dtype=np.float64)
    return {
        "gain": float(x.mean()),
        "ci95": boot(x, seed=seed),
        "p": signflip(x),
        "wins": int((x > 1e-12).sum()),
        "ties": int((np.abs(x) <= 1e-12).sum()),
        "losses": int((x < -1e-12).sum()),
        "values": x.tolist(),
    }


def load(root: Path, key: str) -> dict:
    return json.loads((root / key / "sum.json").read_text())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    ns = ap.parse_args()
    root = ns.root
    fa, fb = load(root, "fixed_a"), load(root, "fixed_b")
    sa, sb = load(root, "screen_a"), load(root, "screen_b")

    fixed_rank_a = [float(x["gain"]) for x in fa["ranking"]["worlds"]]
    fixed_rank_b = [float(x["gain"]) for x in fb["ranking"]["worlds"]]
    fixed_k_a = [float(x) for x in fa["paired"]["kbt_raw_k"]["values"]]
    fixed_k_b = [float(x) for x in fb["paired"]["kbt_raw_k"]["values"]]

    cond_k_a = [float(x) for x in sa["paired"]["kbt_raw_k"]["values"]]
    cond_k_b = [float(x) for x in sb["paired"]["kbt_raw_k"]["values"]]
    cond_reg_a = [float(x) for x in sa["paired"]["kbt_raww_reg"]["values"]]
    cond_reg_b = [float(x) for x in sb["paired"]["kbt_raww_reg"]["values"]]
    cond_hit_a = [float(x) for x in sa["paired"]["kbt_raww_hit"]["values"]]
    cond_hit_b = [float(x) for x in sb["paired"]["kbt_raww_hit"]["values"]]

    sela = json.loads((root / "screen_a" / "sel.json").read_text())
    selb = json.loads((root / "screen_b" / "sel.json").read_text())
    screen = {
        "a_screened": int(sela["screened_n"]),
        "b_screened": int(selb["screened_n"]),
        "a_rate": 24.0 / float(sela["screened_n"]),
        "b_rate": 24.0 / float(selb["screened_n"]),
        "combined_rate": 48.0 / float(sela["screened_n"] + selb["screened_n"]),
    }

    result = {
        "schema": "riwf-stable-disagreement-master-v1",
        "fixed": {
            "ranking_a": stat(fixed_rank_a, 301),
            "ranking_b": stat(fixed_rank_b, 302),
            "ranking_combined": stat(fixed_rank_a + fixed_rank_b, 303),
            "deployment_k_a": stat(fixed_k_a, 304),
            "deployment_k_b": stat(fixed_k_b, 305),
            "deployment_k_combined": stat(fixed_k_a + fixed_k_b, 306),
        },
        "conditional": {
            "k_a": stat(cond_k_a, 401),
            "k_b": stat(cond_k_b, 402),
            "k_combined": stat(cond_k_a + cond_k_b, 403),
            "reg_combined": stat(cond_reg_a + cond_reg_b, 404),
            "hit_combined": stat(cond_hit_a + cond_hit_b, 405),
            "fisher_p": float(combine_pvalues([sa["paired"]["kbt_raw_k"]["p"], sb["paired"]["kbt_raw_k"]["p"]], method="fisher").pvalue),
        },
        "screening": screen,
        "audits": {
            key: json.loads((root / key / "audx.json").read_text()).get("pass", False)
            for key in ("fixed_a", "fixed_b", "screen_a", "screen_b")
        },
        "screen_audit": {
            key: json.loads((root / key / "scaud.json").read_text()).get("pass", False)
            for key in ("screen_a", "screen_b")
        },
    }
    fixed_ok = (
        result["fixed"]["ranking_a"]["gain"] > 0
        and result["fixed"]["ranking_b"]["gain"] > 0
        and result["fixed"]["ranking_combined"]["gain"] > 0
        and result["fixed"]["ranking_combined"]["ci95"][0] > 0
        and result["fixed"]["ranking_combined"]["p"] < 0.05
    )
    cond_ok = all(
        result["conditional"][key]["gain"] > 0
        and result["conditional"][key]["ci95"][0] > 0
        and result["conditional"][key]["p"] < 0.05
        for key in ("k_a", "k_b")
    )
    result["decision"] = {"fixed_pass": bool(fixed_ok), "conditional_pass": bool(cond_ok)}
    result["pass"] = bool(
        all(result["audits"].values())
        and all(result["screen_audit"].values())
        and fixed_ok
        and cond_ok
    )
    (root / "master.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")

    fr = result["fixed"]["ranking_combined"]
    fd = result["fixed"]["deployment_k_combined"]
    ck = result["conditional"]["k_combined"]
    cr = result["conditional"]["reg_combined"]
    ch = result["conditional"]["hit_combined"]
    text = f"""# Stable-disagreement PPO confirmation

Fixed-world ranking gain

{fr['gain']:.6f} with 95 percent interval [{fr['ci95'][0]:.6f}, {fr['ci95'][1]:.6f}] and one-sided sign-flip p {fr['p']:.8f}.

Fixed-world unconditional target K-rho gain

{fd['gain']:.6f} with 95 percent interval [{fd['ci95'][0]:.6f}, {fd['ci95'][1]:.6f}] and one-sided sign-flip p {fd['p']:.8f}.

Stable-disagreement target K-rho gain

{ck['gain']:.6f} with 95 percent interval [{ck['ci95'][0]:.6f}, {ck['ci95'][1]:.6f}] and one-sided sign-flip p {ck['p']:.8f}.

Stable-disagreement regret gain

{cr['gain']:.6f} with 95 percent interval [{cr['ci95'][0]:.6f}, {cr['ci95'][1]:.6f}].

Stable-disagreement target-success gain

{ch['gain']:.6f} with 95 percent interval [{ch['ci95'][0]:.6f}, {ch['ci95'][1]:.6f}].

Screening

Replication A retained 24 stable disagreements from {screen['a_screened']} screened worlds.

Replication B retained 24 stable disagreements from {screen['b_screened']} screened worlds.

All audits passed

{result['pass']}
"""
    (root / "report.md").write_text(text)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
