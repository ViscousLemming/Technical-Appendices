#!/usr/bin/env python3
"""Recompute the reported endpoints from the compact review tables."""
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import combine_pvalues, spearmanr


COHORTS = ("fixed_a", "fixed_b", "screen_a", "screen_b")


def boot(x: np.ndarray, seed: int, n: int = 50000) -> list[float]:
    x = np.asarray(x, dtype=np.float64)
    rng = np.random.default_rng(seed)
    draw = rng.choice(x, size=(n, len(x)), replace=True).mean(axis=1)
    return [float(np.quantile(draw, 0.025)), float(np.quantile(draw, 0.975))]


def signed_sums(x: np.ndarray) -> np.ndarray:
    out = np.empty(1 << len(x), dtype=np.float64)
    for mask in range(1 << len(x)):
        total = 0.0
        for index, value in enumerate(x):
            total += value if ((mask >> index) & 1) else -value
        out[mask] = total
    return out


def signflip(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=np.float64)
    if len(x) <= 20:
        totals = [
            float(np.sum(x * np.asarray(signs)))
            for signs in itertools.product((-1.0, 1.0), repeat=len(x))
        ]
        return float((np.asarray(totals) >= x.sum() - 1e-15).mean())
    if len(x) > 26:
        rng = np.random.default_rng(17)
        totals = (rng.choice([-1.0, 1.0], size=(1000000, len(x))) * x).sum(axis=1)
        return float((totals >= x.sum() - 1e-15).mean())
    middle = len(x) // 2
    left = signed_sums(x[:middle])
    right = np.sort(signed_sums(x[middle:]))
    target = float(x.sum() - 1e-15)
    total = 0
    for value in left:
        total += len(right) - int(np.searchsorted(right, target - value, side="left"))
    return float(total / (1 << len(x)))


def stat(values: list[float], seed: int) -> dict[str, Any]:
    x = np.asarray(values, dtype=np.float64)
    return {
        "gain": float(x.mean()),
        "ci95": boot(x, seed),
        "p": signflip(x),
        "wins": int((x > 1e-12).sum()),
        "ties": int((np.abs(x) <= 1e-12).sum()),
        "losses": int((x < -1e-12).sum()),
        "values": x.tolist(),
    }


def close(left: Any, right: Any, path: str = "result") -> None:
    if isinstance(left, dict) and isinstance(right, dict):
        if set(left) != set(right):
            raise RuntimeError(f"{path} keys differ")
        for key in left:
            close(left[key], right[key], f"{path}.{key}")
        return
    if isinstance(left, list) and isinstance(right, list):
        if len(left) != len(right):
            raise RuntimeError(f"{path} lengths differ")
        for index, (a, b) in enumerate(zip(left, right)):
            close(a, b, f"{path}[{index}]")
        return
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        if not np.isclose(float(left), float(right), atol=1e-12, rtol=1e-12):
            raise RuntimeError(f"{path} differs. Recomputed {left!r}, recorded {right!r}")
        return
    if left != right:
        raise RuntimeError(f"{path} differs. Recomputed {left!r}, recorded {right!r}")


def candidate(frame: pd.DataFrame, index: int) -> pd.Series:
    rows = frame[frame.candidate == index]
    if len(rows) != 1:
        raise RuntimeError(f"candidate {index} occurs {len(rows)} times")
    return rows.iloc[0]


def cohort(root: Path, name: str) -> dict[str, Any]:
    folder = root / name
    selection = json.loads((folder / "sel.json").read_text())
    ids = [int(value) for value in selection["selected"]]
    if len(ids) != 24 or len(set(ids)) != 24:
        raise RuntimeError(f"{name} does not contain 24 distinct selected worlds")

    rank: list[float] = []
    deploy: list[float] = []
    regret: list[float] = []
    hit: list[float] = []
    for world in ids:
        frame = pd.read_csv(folder / f"md{world:02d}.csv")
        if len(frame) != 60 or set(frame.world.astype(int)) != {world}:
            raise RuntimeError(f"{name} world {world} candidate table is malformed")
        record = json.loads((folder / f"sl{world:02d}.json").read_text())
        if int(record["world"]) != world:
            raise RuntimeError(f"{name} world {world} selector record differs")
        lock = json.loads((folder / f"lk{world:02d}.json").read_text())
        if record.get("lock") != lock.get("sha256"):
            raise RuntimeError(f"{name} world {world} selector lock differs")

        kbt = candidate(frame, int(record["kbtidx"]))
        raw = candidate(frame, int(record["rawidx"]))
        deploy.append(float(raw.raw_krho - kbt.tgt_krho))
        regret.append(float(raw.tgt_regret - kbt.tgt_regret))
        hit.append(float(kbt.tgt_hit - raw.tgt_hit))

        admitted = frame[frame.candidate.isin([int(value) for value in lock["admitted"]])]
        if len(admitted) != len(lock["admitted"]):
            raise RuntimeError(f"{name} world {world} admitted candidates differ")
        kbt_rho = float(spearmanr(admitted.bt_k, admitted.tgt_krho).statistic)
        raw_rho = float(spearmanr(admitted.bt_imp, admitted.tgt_krho).statistic)
        if not np.isfinite(kbt_rho):
            kbt_rho = 0.0
        if not np.isfinite(raw_rho):
            raw_rho = 0.0
        rank.append(kbt_rho - raw_rho)

    recorded = json.loads((folder / "sum.json").read_text())
    close(rank, [float(row["gain"]) for row in recorded["ranking"]["worlds"]], f"{name}.ranking")
    close(deploy, recorded["paired"]["kbt_raw_k"]["values"], f"{name}.deployment")
    close(regret, recorded["paired"]["kbt_raww_reg"]["values"], f"{name}.regret")
    close(hit, recorded["paired"]["kbt_raww_hit"]["values"], f"{name}.hit")
    return {
        "rank": rank,
        "deploy": deploy,
        "regret": regret,
        "hit": hit,
        "screened": int(selection["screened_n"]),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("pub"))
    args = parser.parse_args()
    root = args.root
    data = {name: cohort(root, name) for name in COHORTS}

    fixed_a = data["fixed_a"]
    fixed_b = data["fixed_b"]
    screen_a = data["screen_a"]
    screen_b = data["screen_b"]
    conditional_a = stat(screen_a["deploy"], 401)
    conditional_b = stat(screen_b["deploy"], 402)
    recomputed = {
        "fixed": {
            "ranking_a": stat(fixed_a["rank"], 301),
            "ranking_b": stat(fixed_b["rank"], 302),
            "ranking_combined": stat(fixed_a["rank"] + fixed_b["rank"], 303),
            "deployment_k_a": stat(fixed_a["deploy"], 304),
            "deployment_k_b": stat(fixed_b["deploy"], 305),
            "deployment_k_combined": stat(fixed_a["deploy"] + fixed_b["deploy"], 306),
        },
        "conditional": {
            "k_a": conditional_a,
            "k_b": conditional_b,
            "k_combined": stat(screen_a["deploy"] + screen_b["deploy"], 403),
            "reg_combined": stat(screen_a["regret"] + screen_b["regret"], 404),
            "hit_combined": stat(screen_a["hit"] + screen_b["hit"], 405),
            "fisher_p": float(
                combine_pvalues([conditional_a["p"], conditional_b["p"]], method="fisher").pvalue
            ),
        },
        "screening": {
            "a_screened": screen_a["screened"],
            "b_screened": screen_b["screened"],
            "a_rate": 24.0 / screen_a["screened"],
            "b_rate": 24.0 / screen_b["screened"],
            "combined_rate": 48.0 / (screen_a["screened"] + screen_b["screened"]),
        },
    }
    recorded = json.loads((root / "master.json").read_text())
    for key in recomputed:
        close(recomputed[key], recorded[key], key)

    rank = recomputed["fixed"]["ranking_combined"]
    deploy = recomputed["fixed"]["deployment_k_combined"]
    conditional = recomputed["conditional"]["k_combined"]
    print("Statistical recomputation passed")
    print(f"Fixed ranking gain {rank['gain']:.12f}")
    print(f"Fixed target K-rho gain {deploy['gain']:.12f}")
    print(f"Stable-disagreement K-rho gain {conditional['gain']:.12f}")


if __name__ == "__main__":
    main()
