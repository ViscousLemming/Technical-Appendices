#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
import zipfile
from pathlib import Path
ap = argparse.ArgumentParser()
ap.add_argument("--out", type=Path, default=Path("out"))
ap.add_argument("--zip", type=Path, default=Path("result.zip"))
ns = ap.parse_args()
if not (ns.out / "master.json").exists():
    raise SystemExit("Run is incomplete")
with zipfile.ZipFile(ns.zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
    for path in sorted(ns.out.rglob("*")):
        if path.is_file():
            z.write(path, path.relative_to(ns.out.parent))
h = hashlib.sha256(ns.zip.read_bytes()).hexdigest()
ns.zip.with_suffix(ns.zip.suffix + ".sha").write_text(h + "  " + ns.zip.name + "\n")
print(h)
