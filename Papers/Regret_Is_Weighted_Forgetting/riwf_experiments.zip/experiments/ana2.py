#!/usr/bin/env python3
"""Aggregate binary K-rho recurrent PPO worlds."""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import warnings
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from env import InputBank, World, action_values, binary_terms, input_hash, make_bank
from core import lock_hash

warnings.filterwarnings("ignore", category=pd.errors.PerformanceWarning)


def boot(x: np.ndarray, seed: int = 91, n: int = 50000) -> list[float]:
    x = np.asarray(x, dtype=np.float64)
    rng = np.random.default_rng(seed)
    draw = rng.choice(x, size=(n, len(x)), replace=True).mean(axis=1)
    return [float(np.quantile(draw, 0.025)), float(np.quantile(draw, 0.975))]


def _signed_sums(x: np.ndarray) -> np.ndarray:
    out = np.empty(1 << len(x), dtype=np.float64)
    for mask in range(1 << len(x)):
        total = 0.0
        for j, value in enumerate(x):
            total += value if ((mask >> j) & 1) else -value
        out[mask] = total
    return out


def signflip(x: np.ndarray) -> float:
    """Exact one-sided paired sign-flip value for up to 26 pairs."""
    x = np.asarray(x, dtype=np.float64)
    if len(x) <= 20:
        vals = []
        for signs in itertools.product((-1.0, 1.0), repeat=len(x)):
            vals.append(float(np.sum(x * np.asarray(signs))))
        return float((np.asarray(vals) >= x.sum() - 1e-15).mean())
    if len(x) > 26:
        rng = np.random.default_rng(17)
        vals = (rng.choice([-1.0, 1.0], size=(1000000, len(x))) * x).sum(axis=1)
        return float((vals >= x.sum() - 1e-15).mean())
    mid = len(x) // 2
    a = _signed_sums(x[:mid])
    b = np.sort(_signed_sums(x[mid:]))
    target = float(x.sum() - 1e-15)
    total = 0
    for value in a:
        total += len(b) - int(np.searchsorted(b, target - value, side="left"))
    return float(total / ((1 << len(x))))


def pair(frame: pd.DataFrame, a: str, b: str, field: str, lower: bool) -> dict:
    av = frame[f"{a}{field}"].to_numpy(dtype=np.float64)
    bv = frame[f"{b}{field}"].to_numpy(dtype=np.float64)
    diff = bv - av if lower else av - bv
    return {
        "gain": float(diff.mean()),
        "ci95": boot(diff),
        "p": signflip(diff),
        "wins": int((diff > 1e-12).sum()),
        "ties": int((np.abs(diff) <= 1e-12).sum()),
        "losses": int((diff < -1e-12).sum()),
        "values": diff.tolist(),
    }


def load_input(path: Path) -> InputBank:
    with np.load(path, allow_pickle=False) as z:
        expected = {"obs", "valid", "gate", "gate_id", "regime", "cues", "delays", "lengths", "seed"}
        if set(z.files) != expected:
            raise RuntimeError("input archive contains outcome fields")
        return InputBank(
            z["obs"], z["valid"], z["gate"], z["gate_id"], z["regime"],
            z["cues"], z["delays"], z["lengths"], int(z["seed"][0]),
        )


def add_row(frame: pd.DataFrame, ridx: int, name: str, row: pd.Series, prefix: str, delays: list[int]) -> None:
    vals = {
        "idx": int(row.candidate),
        "name": f"{row.arch}_{row.focus}_u{int(row.snap)}_h{int(row.khi)}l{int(row.klo)}",
        "ret": float(row[f"{prefix}_ret"]),
        "reg": float(row[f"{prefix}_regret"]),
        "acc": float(row[f"{prefix}_acc"]),
        "exec": float(row[f"{prefix}_exec"]),
        "hit": float(row[f"{prefix}_hit"]),
        "k": float(row.tgt_krho),
        "native": float(row.native_ret),
        "nhit": float(row.native_hit),
        "sret": float(row.src_ret),
        "shit": float(row.src_hit),
        "khi": int(row.khi),
        "klo": int(row.klo),
        "bk": float(row.bt_k),
        "bi": float(row.bt_imp),
    }
    for delay in delays:
        vals[f"ret{delay}"] = float(row[f"{prefix}_ret{delay}"])
        vals[f"reg{delay}"] = float(row[f"{prefix}_reg{delay}"])
        vals[f"hit{delay}"] = float(row[f"{prefix}_hit{delay}"])
        vals[f"k{delay}"] = float(row[f"tgt_k{delay}"])
    for key, value in vals.items():
        frame.loc[ridx, f"{name}{key}"] = value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", type=Path, required=True)
    parser.add_argument("--tag", default="confirmation")
    parser.add_argument("--expect", type=int, default=None)
    parser.add_argument("--ids", type=Path, default=None)
    args = parser.parse_args()
    root = args.dir
    if args.ids is None:
        ids = sorted(int(path.stem[2:]) for path in root.glob("md*.csv"))
    else:
        data = json.loads(args.ids.read_text())
        ids = [int(x) for x in data.get("selected", data.get("ids", []))]
    if args.expect is not None and len(ids) != args.expect:
        raise RuntimeError("unexpected selected world total")
    md_files = [root / f"md{wid:02d}.csv" for wid in ids]
    sl_files = [root / f"sl{wid:02d}.json" for wid in ids]
    mt_files = [root / f"mt{wid:02d}.json" for wid in ids]
    if not md_files or not sl_files or not mt_files:
        raise RuntimeError("world outputs missing")
    md = pd.concat([pd.read_csv(path) for path in md_files], ignore_index=True)
    sl = pd.DataFrame([json.loads(path.read_text()) for path in sl_files])
    metas = [json.loads(path.read_text()) for path in mt_files]
    cfg = metas[0]["config"]
    delays = [int(x) for x in cfg["tgt"]]
    states = int(cfg["states"])

    actual_prefix = {
        "kbt": "tgt",
        "raw": "raw",
        "kb": "srcp",
        "val": "srcp",
        "rand": "tgt",
        "oracle": "opt",
    }
    for ridx, rec in sl.iterrows():
        wid = int(rec.world)
        world_md = md[md.world == wid]
        for name, prefix in actual_prefix.items():
            cid = int(rec[f"{name}idx"])
            row = world_md[world_md.candidate == cid].iloc[0]
            add_row(sl, ridx, name, row, prefix, delays)
        for name, base in (("raww", "raw"), ("kbw", "kb"), ("valw", "val"), ("oraclew", "oracle")):
            cid = int(rec[f"{base}idx"])
            row = world_md[world_md.candidate == cid].iloc[0]
            add_row(sl, ridx, name, row, "tgt", delays)

        lock = json.loads((root / f"lk{wid:02d}.json").read_text())
        admitted = world_md[world_md.candidate.isin(lock["admitted"])]
        vals = {
            "idx": -1,
            "name": "uniform_admitted",
            "ret": float(admitted.tgt_ret.mean()),
            "reg": float(admitted.tgt_regret.mean()),
            "acc": float(admitted.tgt_acc.mean()),
            "exec": float(admitted.tgt_exec.mean()),
            "hit": float(admitted.tgt_hit.mean()),
            "k": float(admitted.tgt_krho.mean()),
            "native": float(admitted.native_ret.mean()),
            "nhit": float(admitted.native_hit.mean()),
            "sret": float(admitted.src_ret.mean()),
            "shit": float(admitted.src_hit.mean()),
            "khi": float(admitted.khi.mean()),
            "klo": float(admitted.klo.mean()),
            "bk": float(admitted.bt_k.mean()),
            "bi": float(admitted.bt_imp.mean()),
        }
        for delay in delays:
            vals[f"ret{delay}"] = float(admitted[f"tgt_ret{delay}"].mean())
            vals[f"reg{delay}"] = float(admitted[f"tgt_reg{delay}"].mean())
            vals[f"hit{delay}"] = float(admitted[f"tgt_hit{delay}"].mean())
            vals[f"k{delay}"] = float(admitted[f"tgt_k{delay}"].mean())
        for key, value in vals.items():
            sl.loc[ridx, f"rmean{key}"] = value

        wp = dict(lock["world_params"])
        wp["tests"] = np.asarray(wp["tests"], dtype=np.int64)
        world = World(**wp)
        target = make_bank(world, int(cfg["eval_n"]), delays, int(lock["eval_seed"]))
        values = action_values(target.post, world.tests)
        _y, rho = binary_terms(values)
        hi = target.inputs.regime == 1
        sl.loc[ridx, "margin_hi"] = float(rho[hi].mean())
        sl.loc[ridx, "margin_lo"] = float(rho[~hi].mean())
        sl.loc[ridx, "target_hi_frac"] = float(hi.mean())

    md.to_csv(root / "mods.csv", index=False)
    sl.to_csv(root / "sels.csv", index=False)

    names = ["kbt", "raww", "raw", "kbw", "kb", "valw", "val", "rmean", "rand", "oraclew", "oracle"]
    metrics = ("ret", "reg", "k", "exec", "acc", "sret", "shit", "native", "hit", "nhit", "khi", "klo")
    means = {name: {key: float(sl[f"{name}{key}"].mean()) for key in metrics} for name in names}

    pairs: dict[str, dict] = {}
    for base in ("raww", "raw", "kbw", "kb", "valw", "val", "rmean", "rand", "oraclew", "oracle"):
        pairs[f"kbt_{base}_k"] = pair(sl, "kbt", base, "k", True)
        pairs[f"kbt_{base}_reg"] = pair(sl, "kbt", base, "reg", True)
        pairs[f"kbt_{base}_ret"] = pair(sl, "kbt", base, "ret", False)
        pairs[f"kbt_{base}_hit"] = pair(sl, "kbt", base, "hit", False)
        pairs[f"kbt_{base}_native"] = pair(sl, "kbt", base, "native", False)

    relations: dict[str, dict] = {}
    for x, y in (
        ("bt_k", "tgt_krho"),
        ("bt_imp", "tgt_krho"),
        ("src_k", "tgt_krho"),
        ("src_ret", "tgt_krho"),
        ("bt_k", "tgt_regret"),
        ("bt_k", "native_ret"),
    ):
        values = []
        for _wid, group in md.groupby("world"):
            rho = spearmanr(group[x], group[y]).statistic
            if np.isfinite(rho):
                values.append(float(rho))
        relations[f"{x}_{y}"] = {"mean_within_world_rho": float(np.mean(values)), "worlds": values}

    rank_rows = []
    for wid, group in md.groupby("world"):
        lock = json.loads((root / f"lk{int(wid):02d}.json").read_text())
        admitted = group[group.candidate.isin(lock["admitted"])].copy()
        rk = float(spearmanr(admitted.bt_k, admitted.tgt_krho).statistic)
        rr = float(spearmanr(admitted.bt_imp, admitted.tgt_krho).statistic)
        if not np.isfinite(rk):
            rk = 0.0
        if not np.isfinite(rr):
            rr = 0.0
        rank_rows.append({"world": int(wid), "kbt_rho": rk, "raw_rho": rr, "gain": rk - rr})
    rank_frame = pd.DataFrame(rank_rows)
    rank_gain = rank_frame.gain.to_numpy(dtype=np.float64)
    ranking = {
        "kbt_mean_rho": float(rank_frame.kbt_rho.mean()),
        "raw_mean_rho": float(rank_frame.raw_rho.mean()),
        "gain": float(rank_gain.mean()),
        "ci95": boot(rank_gain, seed=173),
        "p": signflip(rank_gain),
        "wins": int((rank_gain > 1e-12).sum()),
        "ties": int((np.abs(rank_gain) <= 1e-12).sum()),
        "losses": int((rank_gain < -1e-12).sum()),
        "worlds": rank_rows,
    }
    rank_frame.to_csv(root / "ranks.csv", index=False)

    calibration = {
        "mean_abs_error": float(np.mean(np.abs(md.bt_k - md.tgt_krho))),
        "median_abs_error": float(np.median(np.abs(md.bt_k - md.tgt_krho))),
        "max_abs_error": float(np.max(np.abs(md.bt_k - md.tgt_krho))),
    }

    delay = {}
    for length in delays:
        delay[str(length)] = {
            name: {
                "k": float(sl[f"{name}k{length}"].mean()),
                "reg": float(sl[f"{name}reg{length}"].mean()),
                "ret": float(sl[f"{name}ret{length}"].mean()),
                "hit": float(sl[f"{name}hit{length}"].mean()),
            }
            for name in ("kbt", "raww", "raw", "kbw", "valw", "rmean", "rand", "oracle")
        }

    checks = {
        "world_count": args.expect is None or len(sl) == args.expect,
        "candidate_count": len(md) == len(sl) * 60,
        "literal_binary_quantity": True,
        "fixed_six_states": bool((md.states == states).all() and states == 6),
        "one_code_for_all_tests": True,
        "input_only_archives": True,
        "lock_hashes": True,
        "panel_before_lock": True,
        "lock_before_eval": True,
        "panel_eval_independent": True,
        "source_policy_fit_eval_independent": True,
        "admission_empirical_source_reward": True,
        "floor_identity": bool(np.allclose(md.opt_regret, md.tgt_krho, atol=3e-10, rtol=3e-10)),
        "execution_nonnegative": bool((md.tgt_exec >= -3e-10).all() and (md.raw_exec >= -3e-10).all()),
        "selector_differs": bool((sl.kbtidx != sl.rawidx).any()),
    }
    for _, rec in sl.iterrows():
        wid = int(rec.world)
        lp = root / f"lk{wid:02d}.json"
        pp = root / f"ti{wid:02d}.npz"
        ep = root / f"ei{wid:02d}.npz"
        mp = root / f"md{wid:02d}.csv"
        vp = root / f"ev{wid:02d}.pt"
        sp = root / f"sl{wid:02d}.json"
        lock = json.loads(lp.read_text())
        checks["lock_hashes"] &= lock["sha256"] == lock_hash({k: v for k, v in lock.items() if k != "sha256"})
        checks["input_only_archives"] &= input_hash(load_input(pp)) == lock["panel_input_hash"]
        checks["input_only_archives"] &= input_hash(load_input(ep)) == rec.eval_hash
        checks["panel_before_lock"] &= pp.stat().st_mtime_ns <= lp.stat().st_mtime_ns
        checks["lock_before_eval"] &= all(lp.stat().st_mtime_ns <= path.stat().st_mtime_ns for path in (ep, mp, vp, sp))
        checks["panel_eval_independent"] &= lock["panel_seed"] != lock["eval_seed"]
        checks["panel_eval_independent"] &= input_hash(load_input(pp)) != input_hash(load_input(ep))
        checks["literal_binary_quantity"] &= lock.get("quantity") == "literal_binary_K_rho"
        checks["one_code_for_all_tests"] &= bool(lock.get("one_code_reused_for_all_tests"))
        checks["source_policy_fit_eval_independent"] &= (
            lock.get("source_policy_fit_seed") != lock.get("source_policy_eval_seed")
        )
        checks["admission_empirical_source_reward"] &= (
            lock.get("source_admission_metric")
            == "empirical mean reward on independent source validation histories"
        )
    audit = {**checks, "pass": bool(all(checks.values()))}

    allocation = {
        "kbt_hi_mean": float(sl.kbtkhi.mean()),
        "raw_hi_mean": float(sl.rawkhi.mean()),
        "kbt": {str(int(k)): int(v) for k, v in sl.kbtkhi.value_counts().sort_index().items()},
        "raw": {str(int(k)): int(v) for k, v in sl.rawkhi.value_counts().sort_index().items()},
    }

    primary = pairs["kbt_raw_k"]
    actual = pairs["kbt_raww_reg"]
    behaviour = pairs["kbt_raww_hit"]
    pass_primary = primary["gain"] > 0 and primary["ci95"][0] > 0 and primary["p"] < 0.05
    decision = {
        "pass_primary": bool(pass_primary),
        "pass_audit": bool(audit["pass"]),
        "pass": bool(pass_primary and audit["pass"]),
        "primary": "fresh-evaluation target K_rho of KBT-selected representation versus raw-impurity-selected representation",
    }

    summary = {
        "schema": "riwf-kbin-agg-v2",
        "tag": args.tag,
        "worlds": len(sl),
        "candidates": len(md),
        "means": means,
        "paired": pairs,
        "relations": relations,
        "ranking": ranking,
        "calibration": calibration,
        "delay": delay,
        "audit": audit,
        "decision": decision,
        "allocation": allocation,
        "kbt_raw_differ_rate": float((sl.kbtidx != sl.rawidx).mean()),
        "kbt_oracle_match_rate": float((sl.kbtidx == sl.oracleidx).mean()),
        "kbt_oracle_k_gap": float((sl.kbtk - sl.oraclek).mean()),
        "q_error": {"high": float(sl.qherr.mean()), "low": float(sl.qlerr.mean())},
        "margins": {
            "high": float(sl.margin_hi.mean()),
            "low": float(sl.margin_lo.mean()),
            "high_frac": float(sl.target_hi_frac.mean()),
        },
        "admitted": {"mean": float(sl.nadm.mean()), "min": int(sl.nadm.min()), "max": int(sl.nadm.max())},
    }
    (root / "sum.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    (root / "audit.json").write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")
    (root / "dec.json").write_text(json.dumps(decision, indent=2, sort_keys=True) + "\n")

    order = ["kbt", "raww", "kbw", "valw", "rmean", "oracle"]
    fig, ax = plt.subplots(figsize=(7.8, 4.6))
    ax.bar(np.arange(len(order)), [means[name]["k"] for name in order])
    ax.set_xticks(np.arange(len(order)), ["KBT", "Raw", "KB", "Val", "Random", "Oracle"])
    ax.set_ylabel("Fresh target K_rho")
    fig.tight_layout()
    fig.savefig(root / "krho.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.8, 4.6))
    ax.bar(np.arange(len(order)), [means[name]["reg"] for name in order])
    ax.set_xticks(np.arange(len(order)), ["KBT", "Raw + K", "KB + K", "Val + K", "Random", "Oracle"])
    ax.set_ylabel("Fresh target normalised regret")
    fig.tight_layout()
    fig.savefig(root / "reg.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    xs = np.asarray(delays)
    ax.plot(xs, [delay[str(x)]["kbt"]["k"] for x in delays], marker="o", label="KBT")
    ax.plot(xs, [delay[str(x)]["raww"]["k"] for x in delays], marker="o", label="Raw")
    ax.set_xlabel("Target delay")
    ax.set_ylabel("Fresh target K_rho")
    ax.legend()
    fig.tight_layout()
    fig.savefig(root / "delay.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 5.2))
    ax.scatter(md.bt_k, md.tgt_krho, s=8, alpha=0.35)
    lo = min(float(md.bt_k.min()), float(md.tgt_krho.min()))
    hi = max(float(md.bt_k.max()), float(md.tgt_krho.max()))
    ax.plot([lo, hi], [lo, hi])
    ax.set_xlabel("Panel estimate of K_rho")
    ax.set_ylabel("Fresh target K_rho")
    fig.tight_layout()
    fig.savefig(root / "cal.png", dpi=180)
    plt.close(fig)

    report = f"""# Binary K_rho recurrent PPO test

Status: {args.tag}

Worlds: {len(sl)}

Candidates: {len(md)}

KBT fresh target K_rho: {means['kbt']['k']:.6f}

Raw-impurity selection fresh target K_rho: {means['raw']['k']:.6f}

Paired K_rho reduction: {primary['gain']:.6f}

95% bootstrap interval: [{primary['ci95'][0]:.6f}, {primary['ci95'][1]:.6f}]

One-sided exact sign-flip p: {primary['p']:.8f}

Wins, ties, losses: {primary['wins']}, {primary['ties']}, {primary['losses']}

Actual normalised-regret reduction under one common panel-fitted K policy: {actual['gain']:.6f}

Sampled target-success gain: {behaviour['gain']:.6f}

KBT source empirical reward: {means['kbt']['shit']:.6f}

Raw source empirical reward: {means['raw']['shit']:.6f}

Expected target-return gain: {pairs['kbt_raww_ret']['gain']:.6f}

Native PPO target-return gain: {pairs['kbt_raww_native']['gain']:.6f}

KBT oracle match rate: {summary['kbt_oracle_match_rate']:.6f}

Mean within-world rank correlation between panel estimate and fresh target K_rho: {relations['bt_k_tgt_krho']['mean_within_world_rho']:.6f}

Mean absolute K_rho estimation error: {calibration['mean_abs_error']:.6f}

KBT candidate-ranking Spearman: {ranking['kbt_mean_rho']:.6f}

Raw-impurity candidate-ranking Spearman: {ranking['raw_mean_rho']:.6f}

Paired ranking-correlation gain: {ranking['gain']:.6f}

Ranking 95% interval: [{ranking['ci95'][0]:.6f}, {ranking['ci95'][1]:.6f}]

Ranking sign-flip p: {ranking['p']:.8f}

KBT mean rare-regime states: {allocation['kbt_hi_mean']:.6f}

Raw mean rare-regime states: {allocation['raw_hi_mean']:.6f}

Primary pass: {decision['pass_primary']}

Audit pass: {audit['pass']}
"""
    (root / "rpt.md").write_text(report)
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
