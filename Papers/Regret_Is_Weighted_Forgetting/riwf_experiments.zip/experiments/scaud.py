#!/usr/bin/env python3
"""Audit outcome-blind screening and stable-disagreement selection."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd
import torch

import core
import stage


def _hash(obj: dict) -> str:
    cp = dict(obj)
    cp.pop("sha256", None)
    text = json.dumps(cp, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(text.encode()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", type=Path, required=True)
    ap.add_argument("--dir", type=Path, required=True)
    ap.add_argument("--sel", type=Path, required=True)
    ap.add_argument("--open", type=Path, required=True)
    ns = ap.parse_args()
    plan = json.loads(ns.plan.read_text())
    selected = json.loads(ns.sel.read_text())
    opened = json.loads(ns.open.read_text())
    ids = [int(x) for x in selected["screened"]]
    chosen = [int(x) for x in selected["selected"]]
    seed = int(selected["seed"])
    checks = {
        "selection_hash": _hash(selected) == selected.get("sha256"),
        "open_hash": _hash(opened) == opened.get("sha256"),
        "screen_total": len(ids) == int(selected["screened_n"]),
        "selected_total": len(chosen) == int(plan["screening"]["target_disagreements_per_replication"]),
        "first_stable": True,
        "receipts": True,
        "outcome_blind": True,
        "target_only_selected": True,
        "lock_before_open": True,
        "open_before_target": True,
    }
    stable = []
    details = []
    for wid in ids:
        scp = ns.dir / f"sc{wid:02d}.json"
        lkp = ns.dir / f"lk{wid:02d}.json"
        mtp = ns.dir / f"mt{wid:02d}.json"
        stp = ns.dir / f"st{wid:02d}.pt"
        prp = ns.dir / f"pr{wid:02d}.csv"
        wpp = ns.dir / f"wp{wid:02d}.json"
        for path in (scp, lkp, mtp, stp, prp, wpp, ns.dir / f"ti{wid:02d}.npz"):
            if not path.exists():
                raise RuntimeError(f"missing {path}")
        receipt = json.loads(scp.read_text())
        checks["receipts"] &= _hash(receipt) == receipt.get("sha256")
        checks["outcome_blind"] &= receipt.get("screening_uses_target_truth") is False
        lock = json.loads(lkp.read_text())
        pre = pd.read_csv(prp)
        stored = torch.load(stp, map_location="cpu", weights_only=False)
        world = stage._world(wpp)
        args = stage._args(plan, ns.dir, seed)
        rebuilt = stage._screen(plan, args, wid, ns.dir, world, pre, stored["artifacts"], lock)
        checks["receipts"] &= rebuilt == receipt
        if receipt["stable_disagreement"]:
            stable.append(wid)
        is_selected = wid in chosen
        has_target = all((ns.dir / f"{pref}{wid:02d}{suf}").exists() for pref, suf in (("ei", ".npz"), ("ev", ".pt"), ("md", ".csv"), ("sl", ".json")))
        checks["target_only_selected"] &= has_target == is_selected
        checks["lock_before_open"] &= lkp.stat().st_mtime_ns <= ns.open.stat().st_mtime_ns
        if has_target:
            checks["open_before_target"] &= ns.open.stat().st_mtime_ns <= (ns.dir / f"ei{wid:02d}.npz").stat().st_mtime_ns
        details.append({"world": wid, "stable": bool(receipt["stable_disagreement"]), "selected": is_selected})
    checks["first_stable"] &= chosen == stable[: len(chosen)]
    result = {"schema": "riwf-screen-audit-v1", "checks": checks, "pass": bool(all(checks.values())), "details": details}
    (ns.dir / "scaud.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    if not result["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
