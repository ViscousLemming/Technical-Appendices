#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PY=.venv/bin/python
if [ ! -x "$PY" ]; then
  echo "Run ./setup.sh first"
  exit 1
fi
rm -rf smoke
mkdir -p smoke
"$PY" tests.py
"$PY" stage.py source --plan smoke.json --out smoke --seed 321 --world 0
cat > smoke/sel.json <<'JSON'
{"schema":"riwf-world-selection-v1","seed":321,"selected":[0],"ids":[0],"screened":[0],"screened_n":1}
JSON
"$PY" stage.py target --plan smoke.json --out smoke --seed 321 --world 0
"$PY" ana2.py --dir smoke --tag smoke --expect 1 --ids smoke/sel.json
"$PY" audit.py --dir smoke --expect 1 --ids smoke/sel.json
printf 'smoke passed\n'
