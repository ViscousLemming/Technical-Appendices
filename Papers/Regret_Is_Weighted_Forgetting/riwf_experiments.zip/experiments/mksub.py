#!/usr/bin/env python3
"""Build the compact peer-review archive."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
import zipfile
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EXCLUDED_PARTS = {".venv", ".cache", "tmp", "smoke", "__pycache__"}
EXCLUDED_FILES = {
    ".DS_Store",
    "run.log",
    "run.err",
    "SHA256.txt",
    "MTIME.txt",
    "REVIEW.md",
    "verify.sh",
    "mkpeer.py",
}
EXCLUDED_SUFFIXES = {".pt", ".npz", ".ok"}
RENAMED = {"SUBMIT.md": "REVIEW.md", "versub.sh": "verify.sh"}


def digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest_file(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(8 * 1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


def exclusion(path: Path) -> str | None:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDED_PARTS for part in rel.parts):
        return "working directory"
    if rel.parts[:2] == ("out", "log"):
        return "execution log"
    if path.name in EXCLUDED_FILES:
        return "local package file"
    if path.suffix in EXCLUDED_SUFFIXES:
        return {
            ".pt": "PyTorch state archive",
            ".npz": "generated input array",
            ".ok": "completion marker",
        }[path.suffix]
    if path.is_symlink():
        raise RuntimeError(f"symbolic link is not permitted in peer archive: {rel}")
    if not path.is_file():
        return "directory"
    return None


def archive_path(path: Path) -> Path:
    rel = path.relative_to(ROOT)
    if rel.parts and rel.parts[0] == "out":
        return Path("pub", *rel.parts[1:])
    if rel.as_posix() in RENAMED:
        return Path(RENAMED[rel.as_posix()])
    return rel


def zip_info(path: Path, arcname: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo.from_file(path, arcname)
    info.compress_type = zipfile.ZIP_DEFLATED
    return info


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip", type=Path, default=ROOT.parent / "riwfsm.zip")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    master = json.loads((ROOT / "out" / "master.json").read_text())
    state = json.loads((ROOT / "out" / "state.json").read_text())
    if master.get("pass") is not True or state.get("stage") != "complete":
        raise SystemExit("completed passing result is required")

    destination = args.zip.resolve()
    checksum = destination.with_suffix(".sha")
    temporary = destination.with_suffix(".tmp")
    for path in (destination, checksum, temporary):
        if path.exists() and not args.force:
            raise SystemExit(f"refusing to replace {path}")

    included: list[Path] = []
    excluded_count: Counter[str] = Counter()
    excluded_bytes: Counter[str] = Counter()
    for path in sorted(ROOT.rglob("*")):
        reason = exclusion(path)
        if reason is None:
            included.append(path)
        elif path.is_file():
            excluded_count[reason] += 1
            excluded_bytes[reason] += path.stat().st_size

    mapped = [archive_path(path) for path in included]
    if len(mapped) != len(set(mapped)):
        raise SystemExit("archive paths collide")

    scope = {
        "schema": "riwf-submission-scope-v1",
        "profile": "compact peer review",
        "capabilities": {
            "inspect_recorded_results": True,
            "recompute_statistics_from_tables": True,
            "fresh_run_from_frozen_seeds": True,
            "audit_recorded_tensor_states": False,
        },
        "included": {
            "files": len(included),
            "bytes": sum(path.stat().st_size for path in included),
        },
        "excluded": {
            reason: {"files": excluded_count[reason], "bytes": excluded_bytes[reason]}
            for reason in sorted(excluded_count)
        },
    }
    scope_data = (json.dumps(scope, indent=2, sort_keys=True) + "\n").encode()

    manifest: list[str] = []
    mtimes: list[str] = []
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(
        temporary,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
        allowZip64=True,
    ) as archive:
        directory = zipfile.ZipInfo("RIWF/")
        directory.create_system = 3
        directory.external_attr = (0o40755 << 16) | 0x10
        archive.writestr(directory, b"")

        for path in included:
            rel = archive_path(path)
            data = path.read_bytes()
            manifest.append(f"{digest_bytes(data)}  {rel.as_posix()}")
            mtimes.append(f"{path.stat().st_mtime_ns}  {rel.as_posix()}")
            archive.writestr(
                zip_info(path, f"RIWF/{rel.as_posix()}"),
                data,
                compress_type=zipfile.ZIP_DEFLATED,
                compresslevel=9,
            )

        scope_info = zipfile.ZipInfo("RIWF/SCOPE.json", time.localtime()[:6])
        scope_info.create_system = 3
        scope_info.external_attr = 0o100644 << 16
        archive.writestr(scope_info, scope_data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        manifest.append(f"{digest_bytes(scope_data)}  SCOPE.json")

        mtime_data = ("\n".join(mtimes) + "\n").encode()
        mtime_info = zipfile.ZipInfo("RIWF/MTIME.txt", time.localtime()[:6])
        mtime_info.create_system = 3
        mtime_info.external_attr = 0o100644 << 16
        archive.writestr(mtime_info, mtime_data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        manifest.append(f"{digest_bytes(mtime_data)}  MTIME.txt")

        manifest_data = ("\n".join(manifest) + "\n").encode()
        manifest_info = zipfile.ZipInfo("RIWF/SHA256.txt", time.localtime()[:6])
        manifest_info.create_system = 3
        manifest_info.external_attr = 0o100644 << 16
        archive.writestr(
            manifest_info,
            manifest_data,
            compress_type=zipfile.ZIP_DEFLATED,
            compresslevel=9,
        )

    os.replace(temporary, destination)
    archive_hash = digest_file(destination)
    checksum.write_text(f"{archive_hash}  {destination.name}\n")
    print(f"archive {destination}")
    print(f"size {destination.stat().st_size} bytes")
    print(f"sha256 {archive_hash}")


if __name__ == "__main__":
    main()
