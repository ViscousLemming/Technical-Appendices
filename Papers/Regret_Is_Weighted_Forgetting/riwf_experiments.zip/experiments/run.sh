#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PY=.venv/bin/python
if [ ! -x "$PY" ]; then
  echo "Run ./setup.sh first"
  exit 1
fi
JOBS="${JOBS:-6}"
exec "$PY" driver.py --plan plan.json --out out --jobs "$JOBS"
