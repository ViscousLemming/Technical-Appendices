#!/usr/bin/env python3
"""Vectorised delayed-cue POMDP with binary diagnostic actions."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence
import hashlib
import numpy as np


@dataclass(frozen=True)
class InputBank:
    obs: np.ndarray
    valid: np.ndarray
    gate: np.ndarray
    gate_id: np.ndarray
    regime: np.ndarray
    cues: np.ndarray
    delays: np.ndarray
    lengths: np.ndarray
    seed: int


@dataclass(frozen=True)
class FullBank:
    inputs: InputBank
    goal: np.ndarray
    correct: np.ndarray
    post: np.ndarray


@dataclass(frozen=True)
class World:
    classes: int
    gates: int
    cues: int
    distractors: int
    q_high: float
    q_low: float
    high_frac: float
    tests: np.ndarray

    @property
    def actions(self) -> int:
        return int(np.max(self.tests)) + 1


@dataclass(frozen=True)
class ObsLayout:
    regimes: slice
    cues: slice
    distractors: slice
    gates: slice
    start: int
    pad: int
    dim: int


def layout(classes: int, distractors: int, gates: int) -> ObsLayout:
    p = 0
    regimes = slice(p, p + 2)
    p += 2
    cues = slice(p, p + classes)
    p += classes
    ds = slice(p, p + distractors)
    p += distractors
    gs = slice(p, p + gates)
    p += gates
    start = p
    p += 1
    pad = p
    p += 1
    return ObsLayout(regimes, cues, ds, gs, start, pad, p)


def sym_post(cues: np.ndarray, q: np.ndarray, classes: int) -> np.ndarray:
    cues = np.asarray(cues, dtype=np.int64)
    q = np.asarray(q, dtype=np.float64)
    n, nc = cues.shape
    logp = np.full((n, classes), -np.log(classes), dtype=np.float64)
    wrong = np.log((1.0 - q) / (classes - 1))
    right = np.log(q)
    for j in range(nc):
        obs = cues[:, j]
        logp += wrong[:, None]
        logp[np.arange(n), obs] += right - wrong
    logp -= logp.max(axis=1, keepdims=True)
    p = np.exp(logp)
    return p / p.sum(axis=1, keepdims=True)


def _sample_cues(
    rng: np.random.Generator,
    goal: np.ndarray,
    q: np.ndarray,
    classes: int,
    cues: int,
) -> np.ndarray:
    n = len(goal)
    out = np.empty((n, cues), dtype=np.int64)
    for j in range(cues):
        ok = rng.random(n) < q
        wrong = rng.integers(0, classes - 1, size=n, dtype=np.int64)
        wrong = wrong + (wrong >= goal)
        out[:, j] = np.where(ok, goal, wrong)
    return out


def make_bank(
    world: World,
    n: int,
    delays: Sequence[int],
    seed: int,
    high_frac: float | None = None,
) -> FullBank:
    """Generate passive histories followed by three binary tests.

    High-regime cues occur near start. Low-regime cues occur immediately before
    first test. Actions score tests but do not alter later observations.
    """
    rng = np.random.default_rng(int(seed))
    delays = np.asarray([int(x) for x in delays], dtype=np.int64)
    if np.any(delays < 1):
        raise ValueError("delays must be positive")
    frac = world.high_frac if high_frac is None else float(high_frac)
    goal = rng.integers(0, world.classes, size=n, dtype=np.int64)
    regime = (rng.random(n) < frac).astype(np.int64)
    q = np.where(regime == 1, world.q_high, world.q_low)
    cue_vals = _sample_cues(rng, goal, q, world.classes, world.cues)
    d = rng.choice(delays, size=n, replace=True)

    gate0 = 1 + world.cues + d
    gate1 = gate0 + 3
    gate2 = gate1 + 3
    if world.gates != 3:
        raise ValueError("current environment uses three tests")
    lengths = gate2 + 1
    tmax = int(lengths.max())
    lay = layout(world.classes, world.distractors, world.gates)
    obs = np.zeros((n, tmax, lay.dim), dtype=np.float32)
    valid = np.zeros((n, tmax), dtype=bool)
    gate = np.zeros((n, tmax), dtype=bool)
    gid = np.full((n, tmax), -1, dtype=np.int64)

    for i in range(n):
        length = int(lengths[i])
        valid[i, :length] = True
        obs[i, :length, lay.regimes.start + int(regime[i])] = 1.0
        obs[i, 0, lay.start] = 1.0
        for t in range(1, length):
            did = int(rng.integers(0, world.distractors))
            obs[i, t, lay.distractors.start + did] = 1.0

        if regime[i] == 1:
            cue_pos = np.arange(1, 1 + world.cues)
        else:
            cue_pos = np.arange(int(gate0[i]) - world.cues, int(gate0[i]))
        for j, t in enumerate(cue_pos):
            obs[i, t, lay.distractors] = 0.0
            obs[i, t, lay.cues.start + int(cue_vals[i, j])] = 1.0

        for j, t in enumerate((int(gate0[i]), int(gate1[i]), int(gate2[i]))):
            obs[i, t, lay.distractors] = 0.0
            obs[i, t, lay.gates.start + j] = 1.0
            gate[i, t] = True
            gid[i, t] = j

        if length < tmax:
            obs[i, length:, lay.pad] = 1.0

    post = sym_post(cue_vals, q, world.classes)
    correct = np.empty((n, world.gates), dtype=np.int64)
    for j in range(world.gates):
        correct[:, j] = world.tests[j, goal]
    inp = InputBank(obs, valid, gate, gid, regime, cue_vals, d, lengths, int(seed))
    return FullBank(inp, goal, correct, post)


def as_input(bank: FullBank) -> InputBank:
    return bank.inputs


def estimate_q(bank: FullBank) -> tuple[float, float]:
    match = bank.inputs.cues == bank.goal[:, None]
    hi = bank.inputs.regime == 1
    lo = ~hi
    qh = float(match[hi].mean()) if hi.any() else float("nan")
    ql = float(match[lo].mean()) if lo.any() else float("nan")
    qh = float(np.clip(qh, 0.251, 0.999))
    ql = float(np.clip(ql, 0.251, 0.999))
    return qh, ql


def estimate_post(bank: InputBank, qh: float, ql: float, classes: int) -> np.ndarray:
    q = np.where(bank.regime == 1, qh, ql)
    return sym_post(bank.cues, q, classes)


def action_values(post: np.ndarray, tests: np.ndarray) -> np.ndarray:
    """Expected reward for binary answers to each diagnostic test."""
    n, classes = post.shape
    gates = tests.shape[0]
    actions = int(np.max(tests)) + 1
    out = np.zeros((n, gates, actions), dtype=np.float64)
    for j in range(gates):
        for g in range(classes):
            out[:, j, int(tests[j, g])] += post[:, g]
    return out


def binary_terms(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Optimal binary label and normalised wrong-action regret weight."""
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 3 or values.shape[2] != 2:
        raise ValueError("literal K_rho requires two actions")
    y = values.argmax(axis=2).astype(np.int64)
    vmax = values.max(axis=2)
    vmin = values.min(axis=2)
    rho = 1.0 - vmin / np.maximum(vmax, 1e-12)
    return y, np.clip(rho, 0.0, 1.0)


def input_hash(bank: InputBank) -> str:
    h = hashlib.sha256()
    arrays = (
        bank.obs,
        bank.valid,
        bank.gate,
        bank.gate_id,
        bank.regime,
        bank.cues,
        bank.delays,
        bank.lengths,
    )
    for arr in arrays:
        h.update(np.asarray(arr).tobytes())
    h.update(str(bank.seed).encode())
    return h.hexdigest()
