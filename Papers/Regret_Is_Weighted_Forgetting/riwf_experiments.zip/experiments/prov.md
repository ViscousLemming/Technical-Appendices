# Provenance

Original source from failed 180-world run was lost with its runtime. This package reconstructs that protocol from four surviving sources.

1. WAMF4-style affine row geometry in `quant.py`.
2. Fresh 48-world corrected PPO source in `core.py`.
3. Recorded stable-disagreement design from prior discussion.
4. Source-calibration fold audit from corrected calibration code.

Reconstruction adds resumable local launch, fixed-world ranking cohorts, outcome-blind stable-disagreement screening, deferred target opening, independent screening audit, and combined analysis.

No result value from failed run is embedded or assumed. New execution starts from frozen seeds in `plan.json`.
