#!/usr/bin/env python3
"""Recurrent actor-critic encoders for RIWF PPO test."""
from __future__ import annotations

from dataclasses import dataclass
import math

import torch
import torch.nn as nn


@dataclass(frozen=True)
class NetSpec:
    arch: str
    focus: str
    hidden: int
    seed: int
    lr: float
    ent: float

    @property
    def name(self) -> str:
        return f"{self.arch}_{self.focus}_{self.seed}"


class RNet(nn.Module):
    def __init__(self, obs_dim: int, actions: int, spec: NetSpec):
        super().__init__()
        torch.manual_seed(int(spec.seed))
        self.obs_dim = int(obs_dim)
        self.actions = int(actions)
        self.hidden_n = int(spec.hidden)
        self.arch = spec.arch
        if spec.arch == "gru":
            self.rnn = nn.GRU(obs_dim, spec.hidden, batch_first=True)
        elif spec.arch == "lstm":
            self.rnn = nn.LSTM(obs_dim, spec.hidden, batch_first=True)
        elif spec.arch == "rnn":
            self.rnn = nn.RNN(obs_dim, spec.hidden, nonlinearity="tanh", batch_first=True)
        else:
            raise ValueError(spec.arch)
        self.actor = nn.Sequential(
            nn.Linear(spec.hidden, spec.hidden),
            nn.Tanh(),
            nn.Linear(spec.hidden, actions),
        )
        self.critic = nn.Sequential(
            nn.Linear(spec.hidden, spec.hidden),
            nn.Tanh(),
            nn.Linear(spec.hidden, 1),
        )
        for name, p in self.named_parameters():
            if p.ndim >= 2:
                nn.init.orthogonal_(p, gain=1.0)
            else:
                nn.init.zeros_(p)
        nn.init.orthogonal_(self.actor[-1].weight, gain=0.01)
        nn.init.orthogonal_(self.critic[-1].weight, gain=1.0)

    def unroll(self, obs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        hidden, _ = self.rnn(obs)
        logits = self.actor(hidden)
        values = self.critic(hidden).squeeze(-1)
        return logits, values, hidden
