#!/usr/bin/env python3
from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np
import torch

from env import action_values, binary_terms, estimate_post, estimate_q, input_hash, layout, make_bank
from net import NetSpec, RNet
from quant import encode, fit_quant, geometry_receipt, permute_codes
from core import allocations, cell_scores, eval_policy, make_policy, make_world, repeat_codes, run_model


def main() -> None:
    torch.set_num_threads(1)
    world = make_world(123)
    assert world.actions == 2
    assert np.all(world.tests.sum(axis=1) == 2)
    assert len({tuple(world.tests[:, g]) for g in range(world.classes)}) == world.classes

    bank = make_bank(world, 3000, [3, 5, 7], 991)
    assert np.allclose(bank.post.sum(axis=1), 1.0)
    qh, ql = estimate_q(bank)
    assert abs(qh - world.q_high) < 0.035
    assert abs(ql - world.q_low) < 0.035
    values = action_values(estimate_post(bank.inputs, qh, ql, world.classes), world.tests)
    assert values.shape == (3000, 3, 2)
    assert np.allclose(values.sum(axis=2), 1.0)
    y, rho = binary_terms(values)
    assert y.shape == (3000, 3)
    assert np.all((rho >= 0) & (rho <= 1))

    lay = layout(world.classes, world.distractors, world.gates)
    spec = NetSpec("gru", "nat", 16, 55, 0.002, 0.01)
    model = RNet(lay.dim, world.actions, spec)
    memory, probs, _ = run_model(model, bank.inputs)
    assert memory.shape == (3000, 1, 16)
    assert probs.shape == (3000, 3, 2)

    quant = fit_quant(memory, bank.inputs.regime, 4, 2, 77)
    assert quant.frame_rule == geometry_receipt()["frame_rule"]
    one = encode(quant, memory, bank.inputs.regime)
    codes = repeat_codes(one, world.gates)
    assert codes.shape == (3000, 3)
    assert np.all(codes == codes[:, :1])
    assert codes.min() >= 0 and codes.max() < 6

    score = cell_scores(codes, values)
    policy = make_policy(codes, values, 6, True)
    result = eval_policy(codes, policy, values, bank.correct)
    assert abs(result["regret"] - score["krho"]) < 1e-10
    raw = make_policy(codes, values, 6, False)
    raw_result = eval_policy(codes, raw, values, bank.correct)
    assert raw_result["exec"] >= -1e-10

    recoded, mapping = permute_codes(codes, 4, 2, 88)
    recoded_policy = np.zeros_like(policy)
    for old, new in mapping.items():
        recoded_policy[:, new] = policy[:, old]
    result2 = eval_policy(recoded, recoded_policy, values)
    assert abs(result2["regret"] - result["regret"]) < 1e-12

    # Dense affine hidden recoding can be inverted before actor and critic heads,
    # so it leaves recurrent policy function unchanged. Representation codes and
    # selector scores must therefore remain unchanged.
    rng = np.random.default_rng(9917)
    transform = rng.normal(size=(memory.shape[-1], memory.shape[-1])) + 5.0 * np.eye(memory.shape[-1])
    shift = rng.normal(size=memory.shape[-1])
    recoded_memory = memory @ transform + shift
    quant2 = fit_quant(recoded_memory, bank.inputs.regime, 4, 2, 77)
    codes2 = repeat_codes(encode(quant2, recoded_memory, bank.inputs.regime), world.gates)
    assert np.array_equal(codes2, codes)
    assert cell_scores(codes2, values) == score

    panel = make_bank(world, 200, [12, 20, 28], 44).inputs
    evaluation = make_bank(world, 200, [12, 20, 28], 45).inputs
    assert panel.seed != evaluation.seed
    assert input_hash(panel) != input_hash(evaluation)
    assert len(allocations(6)) == 5

    print("tests passed")


if __name__ == "__main__":
    main()
