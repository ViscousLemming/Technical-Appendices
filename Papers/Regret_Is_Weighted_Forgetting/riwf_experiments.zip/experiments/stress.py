#!/usr/bin/env python3
"""Compare original coordinatewise geometry with corrected affine-row geometry."""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch

from env import World, action_values, estimate_post, estimate_q, layout, make_bank
from net import NetSpec
from quant import encode as encode_new, fit_frame, fit_quant_frame
from core import allocations, cell_scores, load_state, repeat_codes, run_model


def load_old_quant(path: Path):
    spec = importlib.util.spec_from_file_location("old_quant", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load original quantizer")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", type=Path, required=True)
    ap.add_argument("--old-quant", type=Path, required=True)
    ap.add_argument("--world", type=int, default=0)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    oldq = load_old_quant(args.old_quant)
    wid = int(args.world)
    lock = json.loads((args.source / f"lk{wid:02d}.json").read_text())
    meta = json.loads((args.source / f"mt{wid:02d}.json").read_text())
    cfg = meta["config"]
    wp = dict(lock["world_params"])
    wp["tests"] = np.asarray(wp["tests"], dtype=np.int64)
    world = World(**wp)
    wseed = int(lock["world_seed"])
    src_fit = make_bank(world, int(cfg["train_n"]), cfg["src"], wseed + 1)
    src_cal = make_bank(world, int(cfg["cal_n"]), cfg["src"], wseed + 2)
    panel = make_bank(world, int(cfg["panel_n"]), cfg["tgt"], int(lock["panel_seed"]))
    qh, ql = estimate_q(src_cal)
    panel_hat = action_values(estimate_post(panel.inputs, qh, ql, world.classes), world.tests)
    pack = torch.load(args.source / f"st{wid:02d}.pt", map_location="cpu", weights_only=False)
    lay = layout(world.classes, world.distractors, world.gates)

    old_score_changed = 0
    old_imp_changed = 0
    old_code_agreement = []
    old_max_k = 0.0
    old_max_imp = 0.0
    new_code_changed = 0
    ranks = []
    candidates = 0
    for model_id, rec in enumerate(pack["models"]):
        spec = NetSpec(**rec["spec"])
        model = load_state(lay.dim, world.actions, spec, rec["state"])
        fit_h, _fit_p, _ = run_model(model, src_fit.inputs)
        panel_h, _panel_p, _ = run_model(model, panel.inputs)
        x = fit_h.reshape(-1, fit_h.shape[-1]).astype(np.float64)
        rank = int(np.linalg.matrix_rank(x - x[[0]]))
        ranks.append(rank)
        rng = np.random.default_rng(wseed + 700001 + model_id)
        dim = fit_h.shape[-1]
        transform = rng.normal(size=(dim, dim)) + 5.0 * np.eye(dim)
        shift = rng.normal(size=dim)
        fit_r = fit_h @ transform + shift
        panel_r = panel_h @ transform + shift
        frame = fit_frame(fit_h)
        frame_r = fit_frame(fit_r)
        for khi, klo in allocations(int(cfg["states"])):
            seed = spec.seed + int(rec["snap"]) * 13 + khi
            qo = oldq.fit_quant(fit_h, src_fit.inputs.regime, khi, klo, seed)
            qor = oldq.fit_quant(fit_r, src_fit.inputs.regime, khi, klo, seed)
            co = repeat_codes(oldq.encode(qo, panel_h, panel.inputs.regime), world.gates)
            cor = repeat_codes(oldq.encode(qor, panel_r, panel.inputs.regime), world.gates)
            so = cell_scores(co, panel_hat)
            sor = cell_scores(cor, panel_hat)
            dk = abs(float(so["krho"]) - float(sor["krho"]))
            di = abs(float(so["imp"]) - float(sor["imp"]))
            old_max_k = max(old_max_k, dk)
            old_max_imp = max(old_max_imp, di)
            old_score_changed += int(dk > 1e-12)
            old_imp_changed += int(di > 1e-12)
            old_code_agreement.append(float(np.mean(co == cor)))

            qn = fit_quant_frame(frame, src_fit.inputs.regime, khi, klo, seed)
            qnr = fit_quant_frame(frame_r, src_fit.inputs.regime, khi, klo, seed)
            cn = encode_new(qn, panel_h, panel.inputs.regime)
            cnr = encode_new(qnr, panel_r, panel.inputs.regime)
            new_code_changed += int(not np.array_equal(cn, cnr))
            candidates += 1

    result = {
        "schema": "riwf.geometry_stress.v1",
        "world": wid,
        "models": len(pack["models"]),
        "candidates": candidates,
        "hidden_dim": int(fit_h.shape[-1]),
        "source_affine_rank_min": int(min(ranks)),
        "source_affine_rank_max": int(max(ranks)),
        "original": {
            "kbt_scores_changed": int(old_score_changed),
            "raw_impurity_scores_changed": int(old_imp_changed),
            "max_abs_kbt_change": float(old_max_k),
            "max_abs_raw_impurity_change": float(old_max_imp),
            "mean_panel_code_agreement": float(np.mean(old_code_agreement)),
            "dense_affine_recode_invariant": False,
        },
        "corrected": {
            "panel_code_arrays_changed": int(new_code_changed),
            "dense_affine_recode_invariant": bool(new_code_changed == 0),
        },
    }
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
