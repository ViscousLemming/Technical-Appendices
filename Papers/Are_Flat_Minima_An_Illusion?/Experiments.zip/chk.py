#!/usr/bin/env python3
# Copyright 2026 Michael Timothy Bennett
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import numpy as np
from scipy import sparse
from scipy.optimize import linprog


def margin_rows(features: np.ndarray, labels: np.ndarray, k: int, margin: float = 1.0):
    features = np.asarray(features, dtype=float)
    labels = np.asarray(labels, dtype=int)
    n, d = features.shape
    rr, cc, vv = [], [], []
    b = np.full(n * (k - 1), -margin)
    r = 0
    for i in range(n):
        y = int(labels[i])
        for c in range(k):
            if c == y:
                continue
            for j, z in enumerate(features[i]):
                if z:
                    rr += [r, r]
                    cc += [y * d + j, c * d + j]
                    vv += [-z, z]
            rr += [r, r]
            cc += [k * d + y, k * d + c]
            vv += [-1.0, 1.0]
            r += 1
    A = sparse.csr_matrix((vv, (rr, cc)), shape=(r, k * d + k))
    return A, b


def feasible(features: np.ndarray, labels: np.ndarray, k: int) -> bool:
    A, b = margin_rows(features, labels, k)
    res = linprog(np.zeros(A.shape[1]), A_ub=A, b_ub=b, bounds=(None, None), method='highs')
    if res.status == 0:
        return True
    if res.status == 2:
        return False
    raise RuntimeError(f'unresolved LP status {res.status}')


base_x = np.array([[-2.0, 0.0], [0.0, 2.0], [2.0, 0.0]])
base_y = np.array([0, 1, 2])
probe_x = np.array([[-1.0, 0.1], [0.1, 1.2], [0.25, 0.25], [0.25, 0.25]])
labels_2 = np.array([0, 1])
labels_4 = np.array([0, 1, 0, 1])
assert feasible(base_x, base_y, 3)
assert feasible(np.vstack([base_x, probe_x[:2]]), np.concatenate([base_y, labels_2]), 3)
assert not feasible(np.vstack([base_x, probe_x]), np.concatenate([base_y, labels_4]), 3)
A = np.array([[2.0, 0.5], [-0.25, 1.5]])
a = np.array([0.4, -0.7])
for px, py in [(probe_x[:2], labels_2), (probe_x, labels_4)]:
    one = feasible(np.vstack([base_x, px]), np.concatenate([base_y, py]), 3)
    two = feasible(np.vstack([base_x @ A.T + a, px @ A.T + a]), np.concatenate([base_y, py]), 3)
    assert one == two
print('joint LP, nesting, and affine-invariance checks passed')

# Verify the closed form used for final-layer relative flatness against an exact Hessian.
import torch

torch.manual_seed(7)
n, d, k = 7, 3, 4
z = torch.randn(n, d, dtype=torch.double)
w = torch.randn(k, d, dtype=torch.double)
bias = torch.randn(k, dtype=torch.double)
y = torch.randint(0, k, (n,))

def ce(flat: torch.Tensor) -> torch.Tensor:
    ww = flat.reshape(k, d)
    return torch.nn.functional.cross_entropy(z @ ww.T + bias, y)

h = torch.autograd.functional.hessian(ce, w.clone().requires_grad_().reshape(-1))
exact = torch.zeros((), dtype=torch.double)
for s in range(k):
    for sp in range(k):
        block = h[s*d:(s+1)*d, sp*d:(sp+1)*d]
        exact = exact + (w[s] @ w[sp]) * torch.trace(block)
prob = torch.softmax(z @ w.T + bias, dim=1)
q2 = (z * z).sum(dim=1)
cov = torch.diag_embed(prob) - prob[:, :, None] * prob[:, None, :]
block_trace = (cov * q2[:, None, None]).mean(dim=0)
closed = ((w @ w.T) * block_trace).sum()
assert torch.allclose(exact, closed, atol=1e-10, rtol=1e-10)
print('relative-flatness Hessian check passed')
