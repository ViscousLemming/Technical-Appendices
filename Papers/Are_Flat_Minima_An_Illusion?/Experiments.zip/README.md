# AFMaI experiments

The executed notebooks are in `experiments/joint`. The completed reducer outputs are in `results`.

The three cohort notebooks train MNIST, Fashion-MNIST, and fixed random-label cohorts. Each notebook requests an L4 GPU and high memory. Each one resumes by seed and saves LP progress after every 32 new solves.

Each cohort uses one fixed empirical base statement per network. It contains the 250 child labels and the network predictions on 32 fixed anchor inputs. The matched bank uses 128 free probes and 128 nested demand paths at orders 2, 4, 8, and 16. No one-input statistic is computed.

For each bank entry, one LP asks whether a replacement affine head can preserve the base statement and satisfy every added label commitment together. The joint bank score `J_H` is the fraction of sampled path prefixes that are feasible. It samples completion membership in the Stack Theory feature-classifier language. It is not another definition of weakness and it is not the complete extension count.

The run uses one declared abstraction. The penultimate layer, anchor count, order mixture, and label law are constant across networks. The cohort notebooks compute and hash model-side quantities before their final cell loads the official test partition. The run does not use the WAM meta learner or a validation-trained composite.

The cohort notebook hashes every model-side measure into `lock.json` before its final cell loads the official test partition. The reducer verifies those locks, orients each diagnostic in its predicted direction, and computes the declared tests.

The reducer also computes a PAC-Bayes certificate. One path is one independent bounded observation. Its score is the mean feasibility of the four nested prefixes. A uniform prior over the 100 frozen networks is independent of the path assignments. The bank may choose a posterior network. The resulting lower bound concerns expected joint-demand feasibility under the path law. It does not bound image-classification error.

The positive joint-bank associations pass the declared gate. They do not exceed every baseline. The random-label cohort has a larger mean joint bank score and no score-accuracy association. See `res.md`.

The book's held-out Unagi score has additional task and semantic premises. Network-specific anchor labels do not establish those premises. The construction does not enforce agreement across networks, so one anchor disagreement rules out a common nonempty task for the anchor-augmented policies. The paper therefore reports `J_H` as an operational cross-representation statistic.

This supplement excludes every legacy one-input experiment.

## License

The code is licensed under Apache License 2.0. Attribution and copyright notices are in `NOTICE`.

## Retained rescaling material

`legacy/rescale` contains the notebooks and recorded cross-regime outputs used for the function-preserving rescaling values in the manuscript. The original checkpoints are not included. The former one-input and activation-region experiments are not part of this package.

## Current files

Future cohort rows retain `anchor_pred` in `rows.json` and `anchor_hash` in both JSON and CSV. The completed aggregate archive predates this field. Run `experiments/joint/anc.ipynb` against the saved checkpoints to audit the common-task compatibility condition without repeating training or LP measurement.

The reducer writes `cond.csv`, a secondary partial-rank analysis of joint completion score conditional on spectral-product margin when raw rows are present. It is not part of the primary testing family.

`task.py` checks the common-task obstruction in a finite language. `notation.md` records why the local symbols for normalized unseen-region and buffer measures were removed.
