# Dataset sources and terms notes

## MNIST

- **Loader used in the notebooks:** `torchvision.datasets.MNIST`
- **Original benchmark homepage:** https://yann.lecun.org/exdb/mnist/
- **Use in this submission:** standard academic benchmark for image classification
- **Terms / license note:** the official MNIST benchmark page describes the dataset and its provenance but does **not** clearly state a separate standalone license on that page. In this submission we therefore treat MNIST as a standard benchmark asset, cite the original creators, and access it through the standard `torchvision` loader rather than redistributing a modified copy.

## Fashion-MNIST

- **Loader used in the notebooks:** `torchvision.datasets.FashionMNIST`
- **Official repository:** https://github.com/zalandoresearch/fashion-mnist
- **License:** MIT License
- **Use in this submission:** standard academic benchmark and direct drop-in replacement for MNIST in the replication experiment

## Torchvision access path

Both benchmarks are downloaded automatically through `torchvision.datasets` into the local `./data` directory during execution. The supplementary bundle does not contain redistributed copies of the raw datasets.
