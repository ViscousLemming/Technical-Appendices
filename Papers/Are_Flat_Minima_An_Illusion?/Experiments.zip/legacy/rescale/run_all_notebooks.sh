#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

run_nb() {
  local dir="$1"
  local nb="$2"
  local out="$3"
  pushd "$ROOT/$dir" >/dev/null
  jupyter nbconvert --to notebook --execute "$nb" --output "$out" --ExecutePreprocessor.timeout=-1
  popd >/dev/null
}

copy_cross_generic() {
  local tag="$1"
  cp "$ROOT/experiments/01_vanishing_advantage/experiment_results_v6.json" "$ROOT/results/cross_regime/results_${tag}.json"
  cp "$ROOT/experiments/01_vanishing_advantage/fig1_reparam_v6.pdf" "$ROOT/results/cross_regime/fig_reparam_${tag}.pdf"
  cp "$ROOT/experiments/01_vanishing_advantage/fig2_corr_v6.pdf" "$ROOT/results/cross_regime/fig_corr_${tag}.pdf"
}

copy_cross_named() {
  local tag="$1"
  cp "$ROOT/experiments/01_vanishing_advantage/results_${tag}.json" "$ROOT/results/cross_regime/results_${tag}.json"
  cp "$ROOT/experiments/01_vanishing_advantage/fig_reparam_${tag}.pdf" "$ROOT/results/cross_regime/fig_reparam_${tag}.pdf"
  cp "$ROOT/experiments/01_vanishing_advantage/fig_corr_${tag}.pdf" "$ROOT/results/cross_regime/fig_corr_${tag}.pdf"
}

mkdir -p "$ROOT/results/cross_regime" "$ROOT/results/model_selection" "$ROOT/results/pair_proxy"

echo "[1/9] 500-point cross-regime run"
run_nb "experiments/01_vanishing_advantage" "500_training_points.ipynb" "500_training_points.executed.ipynb"
copy_cross_generic "500"

echo "[2/9] 2000-point cross-regime run"
run_nb "experiments/01_vanishing_advantage" "2000_training_points.ipynb" "2000_training_points.executed.ipynb"
copy_cross_generic "2000"

echo "[3/9] 6000-point cross-regime run"
run_nb "experiments/01_vanishing_advantage" "6000_training_points.ipynb" "6000_training_points.executed.ipynb"
copy_cross_generic "6000"

echo "[4/9] 12000-point cross-regime run"
run_nb "experiments/01_vanishing_advantage" "12000_training_points.ipynb" "12000_training_points.executed.ipynb"
copy_cross_named "12000"

echo "[5/9] 24000-point cross-regime run"
run_nb "experiments/01_vanishing_advantage" "24000_training_points.ipynb" "24000_training_points.executed.ipynb"
copy_cross_named "24000"

echo "[6/9] 60000-point cross-regime run"
run_nb "experiments/01_vanishing_advantage" "60000_training_points.ipynb" "60000_training_points.executed.ipynb"
copy_cross_generic "60000"

echo "[7/9] model-selection run"
run_nb "experiments/02_model_selection" "300_networks_same_regime.ipynb" "300_networks_same_regime.executed.ipynb"
cp "$ROOT/experiments/02_model_selection/modelselect_results.json" "$ROOT/results/model_selection/results_300nets.json"
if [[ -f "$ROOT/experiments/02_model_selection/fig_modelselect.pdf" ]]; then
  cp "$ROOT/experiments/02_model_selection/fig_modelselect.pdf" "$ROOT/results/model_selection/fig_modelselect.pdf"
fi

echo "[8/9] MNIST pair-proxy run"
run_nb "experiments/03_pair_proxy" "100_networks_linear_feasibility.ipynb" "100_networks_linear_feasibility.executed.ipynb"
cp "$ROOT/experiments/03_pair_proxy/pairproxy_results.json" "$ROOT/results/pair_proxy/results_100nets.json"
cp "$ROOT/experiments/03_pair_proxy/fig_pairproxy.pdf" "$ROOT/results/pair_proxy/fig_pairproxy.pdf"

echo "[9/9] Fashion-MNIST pair-proxy run"
run_nb "experiments/03_pair_proxy" "fmnist_100_networks_linear_feasibility.ipynb" "fmnist_100_networks_linear_feasibility.executed.ipynb"
cp "$ROOT/experiments/03_pair_proxy/fmnist_pairproxy_results.json" "$ROOT/results/pair_proxy/fmnist_pairproxy_results.json"
cp "$ROOT/experiments/03_pair_proxy/fig_fmnist_pairproxy.pdf" "$ROOT/results/pair_proxy/fig_fmnist_pairproxy.pdf"

echo "Done. Canonical outputs are in results/."
