# Reproducibility instructions

This file gives the exact command sequence used to execute the released notebooks from the anonymous supplement.

## 1. Environment setup

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

The notebooks require a CUDA-capable GPU. They were authored for Google Colab with **A100 GPU** and **High RAM**.

## 2. Reproduce everything

From the bundle root:

```bash
bash run_all_notebooks.sh
```

This executes every notebook and copies the generated outputs into the canonical `results/` paths used in the submission.

## 3. Reproduce individual result families

### 3.1 Cross-regime / vanishing-advantage MNIST sweep

Run from the bundle root:

```bash
cd experiments/01_vanishing_advantage
jupyter nbconvert --to notebook --execute 500_training_points.ipynb --output 500_training_points.executed.ipynb --ExecutePreprocessor.timeout=-1
cp experiment_results_v6.json ../../results/cross_regime/results_500.json
cp fig1_reparam_v6.pdf ../../results/cross_regime/fig_reparam_500.pdf
cp fig2_corr_v6.pdf ../../results/cross_regime/fig_corr_500.pdf

jupyter nbconvert --to notebook --execute 2000_training_points.ipynb --output 2000_training_points.executed.ipynb --ExecutePreprocessor.timeout=-1
cp experiment_results_v6.json ../../results/cross_regime/results_2000.json
cp fig1_reparam_v6.pdf ../../results/cross_regime/fig_reparam_2000.pdf
cp fig2_corr_v6.pdf ../../results/cross_regime/fig_corr_2000.pdf

jupyter nbconvert --to notebook --execute 6000_training_points.ipynb --output 6000_training_points.executed.ipynb --ExecutePreprocessor.timeout=-1
cp experiment_results_v6.json ../../results/cross_regime/results_6000.json
cp fig1_reparam_v6.pdf ../../results/cross_regime/fig_reparam_6000.pdf
cp fig2_corr_v6.pdf ../../results/cross_regime/fig_corr_6000.pdf

jupyter nbconvert --to notebook --execute 12000_training_points.ipynb --output 12000_training_points.executed.ipynb --ExecutePreprocessor.timeout=-1
cp results_12000.json ../../results/cross_regime/results_12000.json
cp fig_reparam_12000.pdf ../../results/cross_regime/fig_reparam_12000.pdf
cp fig_corr_12000.pdf ../../results/cross_regime/fig_corr_12000.pdf

jupyter nbconvert --to notebook --execute 24000_training_points.ipynb --output 24000_training_points.executed.ipynb --ExecutePreprocessor.timeout=-1
cp results_24000.json ../../results/cross_regime/results_24000.json
cp fig_reparam_24000.pdf ../../results/cross_regime/fig_reparam_24000.pdf
cp fig_corr_24000.pdf ../../results/cross_regime/fig_corr_24000.pdf

jupyter nbconvert --to notebook --execute 60000_training_points.ipynb --output 60000_training_points.executed.ipynb --ExecutePreprocessor.timeout=-1
cp experiment_results_v6.json ../../results/cross_regime/results_60000.json
cp fig1_reparam_v6.pdf ../../results/cross_regime/fig_reparam_60000.pdf
cp fig2_corr_v6.pdf ../../results/cross_regime/fig_corr_60000.pdf
cd ../..
```

### 3.2 Within-regime model-selection experiment

```bash
cd experiments/02_model_selection
jupyter nbconvert --to notebook --execute 300_networks_same_regime.ipynb --output 300_networks_same_regime.executed.ipynb --ExecutePreprocessor.timeout=-1
cp modelselect_results.json ../../results/model_selection/results_300nets.json
cp fig_modelselect.pdf ../../results/model_selection/fig_modelselect.pdf
cd ../..
```

### 3.3 MNIST pair-proxy / linear-feasibility experiment

```bash
cd experiments/03_pair_proxy
jupyter nbconvert --to notebook --execute 100_networks_linear_feasibility.ipynb --output 100_networks_linear_feasibility.executed.ipynb --ExecutePreprocessor.timeout=-1
cp pairproxy_results.json ../../results/pair_proxy/results_100nets.json
cp fig_pairproxy.pdf ../../results/pair_proxy/fig_pairproxy.pdf
cd ../..
```

### 3.4 Fashion-MNIST pair-proxy replication

```bash
cd experiments/03_pair_proxy
jupyter nbconvert --to notebook --execute fmnist_100_networks_linear_feasibility.ipynb --output fmnist_100_networks_linear_feasibility.executed.ipynb --ExecutePreprocessor.timeout=-1
cp fmnist_pairproxy_results.json ../../results/pair_proxy/fmnist_pairproxy_results.json
cp fig_fmnist_pairproxy.pdf ../../results/pair_proxy/fig_fmnist_pairproxy.pdf
cd ../..
```

## 4. Package requirements

The released notebooks import the following non-standard Python packages:

- `torch`
- `torchvision`
- `numpy`
- `scipy`
- `matplotlib`
- `jupyter`
- `nbconvert`
- `notebook`

## 5. Data access and preparation

All experiments download the benchmark data automatically through `torchvision.datasets` into `./data`:

- `torchvision.datasets.MNIST`
- `torchvision.datasets.FashionMNIST`

The notebooks use the normalization transform:

```python
transforms.Normalize((0.1307,), (0.3081,))
```

No manual preprocessing or custom dataset generation step is required.

## 6. Known execution caveats

- The notebooks were written for Colab and contain optional `google.colab.files` download helpers.
- Some notebooks were saved without populated cell outputs, so reproduction should be judged by the regenerated JSON and figure files rather than by output cells in the raw notebook.
- Pair-proxy runtime depends materially on the linear-program solver backend and the available GPU / CPU combination.
- The bundle includes the precomputed outputs used in the submission so reviewers can verify the reported results without rerunning the full notebook suite.
