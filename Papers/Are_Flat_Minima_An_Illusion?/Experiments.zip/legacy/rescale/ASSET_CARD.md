# Asset card: AFMaI anonymous supplementary bundle

## Asset identity

- **Name:** AFMaI anonymous supplementary material
- **Purpose:** reproduce the experimental results reported in the anonymous NeurIPS submission “Are Flat Minima an Illusion?”
- **Release type:** anonymous peer-review bundle
- **Intended audience:** reviewers and other readers evaluating the submission's reproducibility

## Contents

### Code notebooks
- 6 MNIST cross-regime notebooks at different training-set sizes
- 1 within-regime model-selection notebook
- 1 MNIST pair-proxy notebook
- 1 Fashion-MNIST pair-proxy notebook

### Packaged outputs
- JSON summaries for the released experiments
- figure PDFs corresponding to the released results

## Methods covered

### Cross-regime sweep
- architecture: `784 -> 256 -> 128 -> 10` ReLU MLP
- datasets: MNIST
- regimes:
  - small-batch: batch size 64, learning rate chosen per notebook (`0.05`, `0.03`, or `0.01` depending on scale)
  - large-batch: full-batch at 500 and 2,000; batch size 4,096 at 6,000 and above
- optimizer: plain `torch.optim.SGD(...)`
- number of networks: 25 per regime, 50 total per data scale
- training epochs: 500 at most scales, 600 at 60,000

### Model-selection experiment
- architecture: `784 -> 64 -> 16 -> 10` ReLU MLP
- dataset: MNIST
- 300 random seeds
- batch size 64
- learning rate 0.1
- optimizer: plain `torch.optim.SGD(...)`
- max epochs: 500

### Pair-proxy experiments
- architecture: `784 -> 64 -> 8 -> 10` ReLU MLP
- datasets: MNIST and Fashion-MNIST
- 100 random seeds / networks
- 100 unseen probe points
- 10 classes
- 100,000 linear programs per experiment
- batch size 64
- learning rate 0.1
- optimizer: plain `torch.optim.SGD(...)`
- max epochs: 500
- LP margin: `1e-4`

## Dependencies and hardware

### Software
- Python 3
- PyTorch / Torchvision
- NumPy
- SciPy
- Matplotlib
- Jupyter / nbconvert

### Hardware
- authored for Google Colab with **A100 GPU** and **High RAM**
- notebooks print the detected GPU name and memory at runtime
- execution without a CUDA-capable GPU is not supported by the released notebooks

## Data

The bundle does not redistribute MNIST or Fashion-MNIST directly. Instead, it downloads them through `torchvision.datasets` during execution. See `DATASETS.md` for source and terms notes.

## Outputs

Canonical regenerated outputs are copied into:

- `results/cross_regime/`
- `results/model_selection/`
- `results/pair_proxy/`

## Limitations

- The release artifact is notebook-based, not a fully packaged Python project.
- Package versions are not pinned in the original notebooks; the closest execution environment is Colab A100 / High RAM.
- Several older notebooks emit generic filenames that must be renamed or copied into the canonical `results/` structure; the provided reproduction script handles this automatically.
- The experiments cover MLPs on MNIST and Fashion-MNIST; they are not a claim of out-of-the-box transfer to larger architectures or modern large-scale benchmarks.
- The pair proxy is computationally heavier than the other released experiments because it solves many linear programs.

## Documentation and terms

This anonymous bundle is provided solely to support confidential NeurIPS peer review. It is not the de-anonymized public code release. The public, post-review release should defer to the repository's public license and documentation.
