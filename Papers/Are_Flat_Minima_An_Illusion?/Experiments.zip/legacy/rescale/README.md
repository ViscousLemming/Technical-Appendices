# AFMaI anonymous supplementary material

This anonymous review bundle contains the notebooks, precomputed outputs, and reproduction notes for the submission **“Are Flat Minima an Illusion?”**.

## What is included

- `experiments/01_vanishing_advantage/`
  - cross-regime MNIST notebooks at 500, 2,000, 6,000, 12,000, 24,000, and 60,000 training points
- `experiments/02_model_selection/300_networks_same_regime.ipynb`
  - within-regime model-selection experiment with 300 random seeds
- `experiments/03_pair_proxy/`
  - MNIST pair-proxy / linear-feasibility experiment
  - Fashion-MNIST replication with the same protocol
- `results/`
  - packaged JSON summaries and figure PDFs included with the submission
- `REPRODUCIBILITY.md`
  - exact command-by-command execution instructions
- `run_all_notebooks.sh`
  - shell script that executes every notebook and copies outputs to the canonical `results/` locations
- `ASSET_CARD.md`
  - structured documentation for the released anonymous assets
- `DATASETS.md`
  - benchmark sources and known license / terms notes
- `requirements.txt`
  - Python package requirements for local execution

## Fastest way to reproduce the bundle

### Option A: Google Colab (closest to the author execution environment)

The notebooks were authored for **Google Colab** with:

- **GPU:** A100
- **memory profile:** High RAM
- **kernel:** Python 3

For any single notebook:

1. open the notebook in Colab;
2. set **Runtime → Change runtime type → A100 GPU, High RAM**;
3. run all cells from top to bottom.

### Option B: local execution

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
bash run_all_notebooks.sh
```

The local route still requires a **CUDA-capable GPU**. The notebooks print the detected GPU name and memory at runtime and will error out if no GPU is available.

## Important reproducibility notes

- The data are downloaded automatically through `torchvision.datasets` into `./data`.
- No manual preprocessing is required beyond the transforms in the notebooks.
- Some older notebooks write generic filenames such as `experiment_results_v6.json`, `fig1_reparam_v6.pdf`, and `fig2_corr_v6.pdf`. The reproduction script copies and renames these outputs into the canonical `results/` paths used in the submission.
- The notebooks include `from google.colab import files` only as an optional convenience for downloading generated artifacts from Colab. Those cells can be ignored outside Colab.
- The bundle is notebook-oriented rather than packaged as a Python module; the exact command lines for every released result are listed in `REPRODUCIBILITY.md`.

## Compute summary

- All notebooks were written for an **A100 GPU / High-RAM** Colab session.
- The pair-proxy notebooks each train 100 networks and evaluate **100,000 linear programs** (100 networks × 100 unseen points × 10 classes).
- The Fashion-MNIST pair-proxy notebook bundled here reports **73.8 minutes total runtime** on an **NVIDIA A100-SXM4-80GB** in its saved outputs.
- The MNIST pair-proxy notebook estimates roughly **1.8 hours** for the LP phase on the same class of hardware.
- The 6,000-point cross-regime notebook header notes “come back in ~1 hour”; larger data scales can take longer.
- Wall-clock time varies with GPU availability, Colab backend, solver performance, and whether figures are regenerated.

## Mapping from notebooks to claims

| Claim / result family | Notebook(s) | Canonical packaged outputs |
| --- | --- | --- |
| Vanishing large-batch advantage across MNIST data scales | `experiments/01_vanishing_advantage/*.ipynb` | `results/cross_regime/results_*.json`, `fig_reparam_*.pdf`, `fig_corr_*.pdf` |
| Within-regime model selection / `k_free` | `experiments/02_model_selection/300_networks_same_regime.ipynb` | `results/model_selection/results_300nets.json` |
| Pair-proxy on MNIST | `experiments/03_pair_proxy/100_networks_linear_feasibility.ipynb` | `results/pair_proxy/results_100nets.json`, `fig_pairproxy.pdf` |
| Pair-proxy on Fashion-MNIST | `experiments/03_pair_proxy/fmnist_100_networks_linear_feasibility.ipynb` | `results/pair_proxy/fmnist_pairproxy_results.json`, `fig_fmnist_pairproxy.pdf` |

## Review-use terms

This bundle is an **anonymous review artifact** prepared for confidential NeurIPS peer review. It is not the de-anonymized public release. After review, the public repository and its public license should be used as the authoritative long-term release.
