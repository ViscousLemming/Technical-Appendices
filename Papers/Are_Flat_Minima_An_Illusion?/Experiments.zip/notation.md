# Measure notation

An earlier draft introduced

\[
P_U=\mu(\cdot\mid U),\qquad Q_\pi=\mu(\cdot\mid B_\pi).
\]

These were local abbreviations for normalised restrictions of the existing reference measure. They were not independent Stack Theory objects. The revised paper, book, and appendix write the restrictions directly. Removing the abbreviations changes no theorem.

The generic PAC-Bayes prior and posterior remain theorem variables because they range over distributions chosen for a PAC-Bayes application. They do not redefine Stack Theory.
