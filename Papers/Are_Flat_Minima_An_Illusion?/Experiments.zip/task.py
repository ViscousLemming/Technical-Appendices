#!/usr/bin/env python3
"""Finite checks for the common-task compatibility theorem.

A finite family of policies can all be correct for some task with nonempty
outputs exactly when their union is satisfiable. Incompatible class labels at
one anchor therefore prevent one common task.
"""
from __future__ import annotations

from itertools import chain, combinations


def powerset(items: tuple[str, ...]):
    return [frozenset(x) for r in range(len(items) + 1) for x in combinations(items, r)]


# A tiny language. c is a child-label commitment. a0 and a1 are incompatible
# labels at one anchor. A statement is satisfiable unless it contains both.
VOCAB = ("c", "a0", "a1")
LANG = [s for s in powerset(VOCAB) if not {"a0", "a1"}.issubset(s)]


def ext(statement: frozenset[str]) -> set[frozenset[str]]:
    return {y for y in LANG if statement.issubset(y)}


def ext_set(statements: set[frozenset[str]]) -> set[frozenset[str]]:
    return set(chain.from_iterable(ext(x) for x in statements))


def correct(policy: frozenset[str], inputs: set[frozenset[str]], outputs: set[frozenset[str]]) -> bool:
    return ext_set(inputs) & ext(policy) == outputs


def exhaustive_check() -> None:
    all_stmt_sets = [set(x) for r in range(len(LANG) + 1) for x in combinations(LANG, r)]
    for inputs in all_stmt_sets:
        available = ext_set(inputs)
        output_sets = [set(x) for r in range(len(available) + 1) for x in combinations(available, r)]
        for outputs in output_sets:
            policies = [p for p in LANG if correct(p, inputs, outputs)]
            if outputs:
                for p in policies:
                    for q in policies:
                        assert frozenset(p | q) in LANG, (inputs, outputs, p, q)



def sufficiency_check() -> None:
    # Every jointly satisfiable finite policy family is correct for the task
    # I={union}, O=Ext(union).
    for r in range(1, len(LANG) + 1):
        for family in combinations(LANG, r):
            union = frozenset().union(*family)
            if union not in LANG:
                continue
            inputs = {union}
            outputs = ext(union)
            assert outputs
            assert all(correct(p, inputs, outputs) for p in family)

def incompatible_anchor_example() -> None:
    p0 = frozenset({"c", "a0"})
    p1 = frozenset({"c", "a1"})
    assert frozenset(p0 | p1) not in LANG
    # The theorem says they cannot both be correct when outputs are nonempty.
    for inputs in [set(), {frozenset()}, {frozenset({"c"})}]:
        available = ext_set(inputs)
        for r in range(1, len(available) + 1):
            for out in combinations(available, r):
                outputs = set(out)
                assert not (correct(p0, inputs, outputs) and correct(p1, inputs, outputs))


if __name__ == "__main__":
    exhaustive_check()
    sufficiency_check()
    incompatible_anchor_example()
    print("common-task compatibility checks passed")
