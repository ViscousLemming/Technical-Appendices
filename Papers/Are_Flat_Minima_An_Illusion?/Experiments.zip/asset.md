# Asset card

Primary files

- `experiments/joint/jmn.ipynb` runs the MNIST natural-label cohort.
- `experiments/joint/jfm.ipynb` runs the Fashion-MNIST natural-label cohort.
- `experiments/joint/jrand.ipynb` runs the fixed random-label cohort.
- `experiments/joint/red.ipynb` verifies locks, reduces the cohorts, and emits manuscript fields and PAC-Bayes certificates.
- `chk.py` checks joint LP feasibility, nested infeasibility, affine invariance, and the relative-flatness formula.
- `pac.py` reproduces the path certificate from `results/ord.csv`.
- `method.md` defines the estimator.
- `results` contains the completed reducer output.
- `res.md` states the result interpretation.

The notebooks measure joint commitments only. This supplement contains no prior one-input notebook.
