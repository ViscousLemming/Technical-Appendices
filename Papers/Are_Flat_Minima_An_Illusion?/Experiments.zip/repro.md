# Reproduction

Use Python 3.12 and the packages in `req.txt`. Run

```bash
python chk.py
```

Then execute the three cohort notebooks in Colab. They save to

```text
/content/drive/MyDrive/weakness_experiments/afmai
```

During a rerun, each cohort writes `cfg.json`, `env.json`, `bank.json`, `split.json`, `rows.json`, `rows.csv`, `lock.json`, one model checkpoint per seed, and resumable LP status files to Google Drive. Configuration and bank hashes prevent resume under another protocol.

The model-side stage trains all 100 networks and computes the joint completion rate, raw Hessian trace, final-layer relative flatness, spectral-product margin, and weight norm. It hashes those rows into `lock.json`. The next notebook cell downloads the official test partition and adds test accuracy.

The reducer verifies all three locks and protocol hashes. The primary family contains the joint association on MNIST and Fashion-MNIST. The eight baseline associations form a separate family. Both use Holm correction. Spearman p values come from 50,000 label permutations. Confidence intervals use 10,000 network bootstrap samples. Raw Hessian trace, relative flatness, and weight norm are negated before analysis. Four dependent correlation comparisons within each dataset use Bonferroni 98.75 percent intervals. Odd and even commitment paths provide a split-bank reliability check without further LPs.

The reducer writes `stats.csv`, `cmp.csv`, `rel.csv`, `ord.csv`, `gate.json`, `sum.json`, three PDF figures, `jres.tex`, `jdiag.tex`, `pac.csv`, and `pac.tex`. The completed files are in `results`.

The PAC-Bayes output can also be regenerated from the order summaries.

```bash
python pac.py --ord results/ord.csv --out results --paths 128
```

The two natural cohorts use delta 0.025 each, giving simultaneous confidence at least 0.95 by a union bound. The uniform prior contains 100 networks. `pac.csv` records the empirical path score, KL radius, selected seed, and population lower bound.

The supplied result archive does not contain model checkpoints, raw cohort `rows.json` or `rows.csv` files, LP progress files, or measured wall times. The notebooks and protocol state the hardware request and per-network workload, but the completed wall-time total cannot be reconstructed from these summaries.
