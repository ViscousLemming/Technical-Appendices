#!/usr/bin/env bash
# Copyright 2026 Michael Timothy Bennett
# SPDX-License-Identifier: Apache-2.0
set -euo pipefail
python chk.py
python mathchk.py
python pac.py --ord results/ord.csv --out results --paths 128
printf '%s\n' 'Run experiments/joint/jmn.ipynb, jfm.ipynb, and jrand.ipynb in Colab to reproduce the cohorts.'
printf '%s\n' 'After all cohorts finish, run experiments/joint/red.ipynb.'
