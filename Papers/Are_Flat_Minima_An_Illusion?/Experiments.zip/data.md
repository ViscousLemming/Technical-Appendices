# Datasets

The notebooks download MNIST and Fashion-MNIST through `torchvision`. They redistribute neither dataset.

MNIST is attributed to Yann LeCun, Corinna Cortes, and Christopher Burges. The original distribution page is `http://yann.lecun.com/exdb/mnist/`. The `torchvision` MNIST record does not list a data licence. This package records that omission rather than assigning one.

Fashion-MNIST is attributed to Han Xiao, Kashif Rasul, and Roland Vollgraf. The project repository is `https://github.com/zalandoresearch/fashion-mnist` and carries the MIT licence.

A fixed permutation of each training partition allocates 250 child inputs, 32 anchor inputs, and 128 free probe inputs. The estimator uses child labels and network-predicted anchor labels. It never reads probe labels.

The official test partition is loaded only after all 100 model-side rows have been hashed into `lock.json`. The random-label cohort applies one fixed permutation to training labels and a separate fixed permutation to test labels. Its input split matches the natural-label MNIST cohort.
