#!/usr/bin/env python3
# Copyright 2026 Michael Timothy Bennett
# SPDX-License-Identifier: Apache-2.0
"""Finite checks for the corpus-aligned PAC-Bayes and bank claims."""
from __future__ import annotations

import math
from itertools import combinations

import numpy as np


def kl(q: np.ndarray, p: np.ndarray) -> float:
    q = np.asarray(q, dtype=float)
    p = np.asarray(p, dtype=float)
    mask = q > 0
    if np.any(p[mask] <= 0):
        return math.inf
    return float(np.sum(q[mask] * np.log(q[mask] / p[mask])))


def bern_kl(q: float, p: float) -> float:
    if q == 0.0:
        return -math.log1p(-p)
    if q == 1.0:
        return -math.log(p)
    return q * math.log(q / p) + (1.0 - q) * math.log((1.0 - q) / (1.0 - p))


def kl_lower(q: float, radius: float) -> float:
    lo, hi = 0.0, q
    for _ in range(180):
        mid = (lo + hi) / 2.0
        if bern_kl(q, mid) > radius:
            lo = mid
        else:
            hi = mid
    return hi


# Buffer information projection on a finite measured unseen region.
rng = np.random.default_rng(260725)
prior = rng.random(9)
prior /= prior.sum()
mask = np.array([True, False, True, True, False, False, True, False, True])
buffer_mass = float(prior[mask].sum())
posterior = np.where(mask, prior / buffer_mass, 0.0)
q = np.zeros_like(prior)
q[mask] = rng.random(mask.sum())
q /= q.sum()
assert math.isclose(
    kl(q, prior),
    kl(q, posterior) - math.log(buffer_mass),
    rel_tol=0.0,
    abs_tol=1e-12,
)
assert math.isclose(kl(posterior, prior), -math.log(buffer_mass), abs_tol=1e-12)

# Completion containment. If y completes pi, every completion of y completes pi.
atoms = frozenset(range(5))
language = [frozenset(c) for r in range(6) for c in combinations(atoms, r)]
pi = frozenset({0})
ext_pi = {z for z in language if pi <= z}
seen = {z for z in language if 4 in z}
unseen = set(language) - seen
buffer = ext_pi & unseen
for y in buffer:
    ext_y = {z for z in language if y <= z}
    assert ext_y <= ext_pi
    assert (ext_y & unseen) <= buffer

# Joint pushforward invariance under a common permutation.
perm = rng.permutation(len(prior))
assert math.isclose(kl(posterior, prior), kl(posterior[perm], prior[perm]), abs_tol=1e-12)
assert math.isclose(buffer_mass, float(prior[perm][mask[perm]].sum()), abs_tol=1e-12)

# Numeric PAC-Bayes path certificates used in the manuscript.
n_paths = 128
radius = (math.log(100) + math.log(2.0 * math.sqrt(n_paths) / 0.025)) / n_paths
assert math.isclose(radius, 0.0891657184, rel_tol=0.0, abs_tol=5e-11)
assert math.isclose(kl_lower(0.43359375, radius), 0.240722, rel_tol=0.0, abs_tol=5e-7)
assert math.isclose(kl_lower(0.466796875, radius), 0.268894, rel_tol=0.0, abs_tol=5e-7)

# The declared bank contains 512 distinct nested probe-label demands.
bank_rng = np.random.default_rng(314159)
orders = (2, 4, 8, 16)
statements: list[frozenset[tuple[int, int]]] = []
for _ in range(128):
    idx = bank_rng.choice(128, size=16, replace=False).astype(int)
    labels = bank_rng.integers(0, 10, size=16, endpoint=False).astype(int)
    for order in orders:
        statements.append(frozenset(zip(idx[:order].tolist(), labels[:order].tolist())))
assert len(statements) == 512
assert len(set(statements)) == 512

print('buffer information-projection identity passed')
print('completion-containment certificate check passed')
print('joint pushforward invariance passed')
print('PAC-Bayes numeric certificate check passed')
print('512-demand bank uniqueness check passed')
