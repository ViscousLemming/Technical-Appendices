#!/usr/bin/env python3
# Copyright 2026 Michael Timothy Bennett
# SPDX-License-Identifier: Apache-2.0
"""Compute the AFMaI PAC-Bayes path certificates from ord.csv."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import pandas as pd


def bern_kl(q: float, p: float) -> float:
    if not 0.0 <= q <= 1.0 or not 0.0 <= p <= 1.0:
        raise ValueError("Bernoulli parameters must lie in [0, 1]")
    if q == 0.0:
        return -math.log1p(-p)
    if q == 1.0:
        return -math.log(p)
    if p == 0.0 or p == 1.0:
        return math.inf
    return q * math.log(q / p) + (1.0 - q) * math.log((1.0 - q) / (1.0 - p))


def kl_lower(q: float, radius: float, iterations: int = 160) -> float:
    if radius < 0.0:
        raise ValueError("KL radius must be nonnegative")
    lo, hi = 0.0, q
    for _ in range(iterations):
        mid = (lo + hi) / 2.0
        if bern_kl(q, mid) > radius:
            lo = mid
        else:
            hi = mid
    return hi


def compute(ord_path: Path, prior_size: int, delta: float, n_paths: int) -> pd.DataFrame:
    order = pd.read_csv(ord_path)
    required = {"dataset", "seed", "order", "rate"}
    missing = required - set(order.columns)
    if missing:
        raise ValueError(f"ord.csv is missing {sorted(missing)}")
    if not 0.0 < delta < 1.0:
        raise ValueError("delta must lie in (0, 1)")
    if prior_size <= 0:
        raise ValueError("prior_size must be positive")

    scores = order.groupby(["dataset", "seed"], as_index=False)["rate"].mean()
    n_orders = int(order["order"].nunique())
    if not (order.groupby(["dataset", "seed"])["order"].count() == n_orders).all():
        raise ValueError("networks have unequal numbers of order summaries")
    if n_paths <= 0:
        raise ValueError("n_paths must be positive")

    radius = (math.log(prior_size) + math.log(2.0 * math.sqrt(n_paths) / delta)) / n_paths
    rows: list[dict[str, float | int | str]] = []
    for dataset in ["MNIST", "Fashion-MNIST", "Random labels"]:
        part = scores[scores["dataset"] == dataset]
        if part.empty:
            continue
        best = part.loc[part["rate"].idxmax()]
        empirical = float(best["rate"])
        rows.append(
            {
                "dataset": dataset,
                "seed": int(best["seed"]),
                "empirical_score": empirical,
                "n_paths": n_paths,
                "prior_size": prior_size,
                "delta": delta,
                "kl_radius": radius,
                "population_lower_bound": kl_lower(empirical, radius),
            }
        )
    return pd.DataFrame(rows)


def tex(rows: pd.DataFrame) -> str:
    by = {str(r.dataset): r for r in rows.itertuples()}
    mn, fm = by["MNIST"], by["Fashion-MNIST"]
    return "\n".join(
        [
            rf"\newcommand{{\mpemp}}{{{mn.empirical_score:.3f}}}",
            rf"\newcommand{{\mplb}}{{{mn.population_lower_bound:.3f}}}",
            rf"\newcommand{{\mpseed}}{{{int(mn.seed)}}}",
            rf"\newcommand{{\fpemp}}{{{fm.empirical_score:.3f}}}",
            rf"\newcommand{{\fplb}}{{{fm.population_lower_bound:.3f}}}",
            rf"\newcommand{{\fpseed}}{{{int(fm.seed)}}}",
            rf"\newcommand{{\pacrhs}}{{{mn.kl_radius:.4f}}}",
            "",
        ]
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ord", type=Path, default=Path("results/ord.csv"))
    parser.add_argument("--out", type=Path, default=Path("results"))
    parser.add_argument("--prior", type=int, default=100)
    parser.add_argument("--paths", type=int, default=128)
    parser.add_argument("--delta", type=float, default=0.025)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    rows = compute(args.ord, args.prior, args.delta, args.paths)
    rows.to_csv(args.out / "pac.csv", index=False)
    (args.out / "pac.tex").write_text(tex(rows), encoding="utf-8")
    (args.out / "pac.json").write_text(
        json.dumps(rows.to_dict(orient="records"), indent=2), encoding="utf-8"
    )
    print(rows.to_string(index=False))


if __name__ == "__main__":
    main()
