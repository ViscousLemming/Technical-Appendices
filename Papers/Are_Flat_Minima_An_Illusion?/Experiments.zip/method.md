# Joint method

For each trained network, freeze the learned penultimate feature map and allow one replacement affine head. The empirical base statement contains the child labels and the trained network labels on a fixed anchor set. A bank demand adds several labels on distinct free probe inputs. One linear program asks whether one affine head satisfies the base statement and every added label.

The finite bank contains 128 nested paths. Each path draws 16 probe-label commitments. Prefixes of length 2, 4, 8, and 16 form four demands. The score gives equal weight to the four order-specific laws. It is unbiased for that fixed mixture. Dependence among prefixes on one path changes estimator variance but not its expectation. Infeasibility of a prefix implies infeasibility of every longer prefix, so the notebook can skip later LP solves without changing the score.

The method uses label commitments, no score bands, no coordinate box, no validation-trained composite, and no evolutionary search. The run uses the penultimate layer and equal order weights throughout. No WAM meta learner chooses the abstraction.

With an unbounded affine head, feasibility is invariant under invertible affine changes of feature coordinates. The LP margin is one. Any strictly feasible statement can be rescaled to satisfy any positive margin.

The statistic is the feasible fraction under this fixed bank law. In the paper it is denoted `J_H`. Each successful demand yields a completion of the empirical base statement in the existing Stack Theory feature-classifier language. `J_H` is not the full extension count, measured weakness, or the cardinality of the correct-policy set. The current network-specific anchors also prevent an unconditional identification with the book's held-out semantic Unagi score.

For the PAC-Bayes calculation, path score is the mean of the four prefix feasibility indicators. The 128 paths are independent draws. The empirical network score is their mean. The prior is uniform over the 100 frozen networks and does not depend on path assignments. A point posterior may select the largest bank score without invalidating the bound.

The analysis keeps the joint bank score and spectral-product margin positive. The stored result column retains the legacy name `spectral_margin`, but it contains the tenth-percentile child score margin divided only by the product of layer spectral norms. It is not the full Bartlett-Foster-Telgarsky bound statistic. It negates raw Hessian trace, relative flatness, and weight norm. Positive Spearman association therefore has the same meaning for every score.

## Task interpretation

The joint score is an external-demand survival statistic for each frozen representation and anchor-augmented empirical statement. Because the feature maps induce different embodied languages, the cross-network comparison is not a Bagi comparison. A semantic-Unagi reading requires one common uninstantiated task, label-preserving task readings, and proof that every empirical statement is correct. In the common external label language, the anchor-augmented policies are compatible with some nonempty task exactly when all networks agree at every anchor. The completed aggregate files do not contain the anchor vectors, so the manuscript does not claim that condition was met.
