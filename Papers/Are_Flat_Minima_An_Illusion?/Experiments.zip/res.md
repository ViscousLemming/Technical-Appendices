# Result reading

The declared gate passes.

| Cohort | Joint rho | Holm q | Split reliability |
|---|---:|---:|---:|
| MNIST | 0.290 | 0.004 | 0.940 |
| Fashion-MNIST | 0.468 | 0.00004 | 0.956 |

Spectral-product margin has larger point estimates in both cohorts. Weight norm also has a corrected positive association. Its Fashion-MNIST Holm value is 0.0014. Paired intervals establish a larger joint correlation than raw Hessian trace and relative flatness only on Fashion-MNIST.

The random-label association is 0.058 with Holm q equal to 0.567. Mean completion rate is 0.287 for natural-label MNIST and 0.420 for random labels. The paired natural-minus-random difference is -0.134 with Holm q below 0.0001.

The random-label result means that the declared uniform probe-label law rewards generic affine-readout freedom. Random-label training creates more of that freedom, but it does not turn into held-out random-label accuracy. The score therefore requires a fixed task, language, and demand law for interpretation.

The PAC-Bayes calculation selects the highest empirical path score without using test accuracy. On MNIST the empirical score is 0.434 and the population lower bound is 0.241. On Fashion-MNIST the empirical score is 0.467 and the lower bound is 0.269. These values hold together with probability at least 0.95 under the declared path-sampling experiment. They concern completion survival under that law. They do not bound classification error.

Order 16 is almost always at the feasibility floor. It remains in the declared primary score. Changing its weight after viewing the outcome would be post hoc. A later meta-learning study can tune layer and order choices on a calibration cohort, freeze them, and evaluate network selection on disjoint cohorts.
