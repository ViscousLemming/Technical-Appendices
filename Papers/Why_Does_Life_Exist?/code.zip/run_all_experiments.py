#!/usr/bin/env python3

"""Reproduce every figure and every numeric result used by the paper.

This file is deliberately written to be readable.
It is not trying to be clever.

What you get when you run it
- It overwrites results_macros.tex.
- It overwrites the figure PDFs that the LaTeX file includes.

Why this script exists
The paper makes a claim about provenance.
Every number in the manuscript should come from code that can be rerun.
This script is the single entry point for that.

How to run
From this folder, run

    python run_all_experiments.py

Everything here is self contained. You'll need matplotlib and PyTorch.

How this script relates to Stack Theory
Experiment A is written using the Stack Theory Suite primitives.
That means we use the suite's definitions of
- environments as finite sets of states
- programs as sets of states
- statements as conjunctions of programs

In the code
- a Program is just a set of states
- a Statement is a conjunction of programs
- the truth set of a statement is the set of states where all its programs hold

You can read the experiment without knowing any of the bitset machinery.
The suite uses bitsets internally for speed.
We only use simple operations like intersection and counting.
"""

from __future__ import annotations

import hashlib
import math
import random
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np

# Stack Theory Suite primitives.
# We vendor the suite inside this package under ./stacktheory.
from stacktheory.layer1.environment import FiniteEnvironment
from stacktheory.layer1.program import Program
from stacktheory.layer1.vocabulary import Statement, Vocabulary


# -----------------------------------------------------------------------------
# Small boring utilities
# -----------------------------------------------------------------------------

def sha256_bytes(data: bytes) -> str:
    """Return a SHA256 hash as a hex string."""
    return hashlib.sha256(data).hexdigest()


def sha256_of_file(path: Path) -> str:
    """Hash a file so we can record exactly what produced the numbers."""
    return sha256_bytes(path.read_bytes())


def sha256_of_files(paths: Sequence[Path]) -> str:
    """Hash a list of files.

    We sort paths so the hash does not depend on filesystem ordering.

    This is a cheap way to answer the question
    "which exact code produced this results_macros.tex file".
    """

    h = hashlib.sha256()
    for p in sorted(paths, key=lambda x: str(x)):
        h.update(p.read_bytes())
    return h.hexdigest()


def fmt(x: float, ndp: int = 3) -> str:
    """Format a number for LaTeX macros."""
    return f"{x:.{ndp}f}"


def bootstrap_ci_mean(values: np.ndarray, *, n_boot: int = 5000, seed: int = 0) -> Tuple[float, float]:
    """A simple bootstrap confidence interval for a mean.

    What it does in plain language
    - We have many trial results.
    - We want an error bar on the average.
    - We repeatedly resample the trials with replacement.
    - Each time we compute the average.
    - The middle 95 percent of those averages is our interval.

    This is not deep.
    It is just a way to get uncertainty bars without assuming a Gaussian model.
    """

    rng = np.random.default_rng(seed)
    n = int(values.shape[0])

    means = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        sample = rng.choice(values, size=n, replace=True)
        means[i] = float(np.mean(sample))

    lo, hi = np.percentile(means, [2.5, 97.5])
    return float(lo), float(hi)


def write_results_macros(
    outpath: Path,
    *,
    groups: List[Tuple[str, Dict[str, str]]],
    code_hash: str,
) -> None:
    """Write results_macros.tex.

    LaTeX reads this file and uses the commands inside it.
    We keep it separate so the manuscript stays clean.

    The file header records
    - a timestamp
    - a hash of the code files used to generate it

    That makes the provenance visible inside the final PDF.
    """

    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")

    lines: List[str] = []
    lines.append("% Auto-generated numbers for PNAS draft")
    lines.append(f"% timestamp_utc {ts}")
    lines.append(f"% code_sha256 {code_hash}")
    lines.append("")

    for title, macros in groups:
        lines.append(f"% {title}")
        for name, value in macros.items():
            lines.append(f"\\newcommand{{\\{name}}}{{{value}}}")
        lines.append("")

    outpath.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


# -----------------------------------------------------------------------------
# Experiment A
# Novelty only toy worlds
# -----------------------------------------------------------------------------


@dataclass(frozen=True)
class ExperimentAConfig:
    """All knobs for Experiment A.

    The defaults are chosen to make the figure stable and quick.

    d_bits
        Number of binary features per state.

    outcome_count
        Size of the finite catalogue L.
        L is the only set of possible outcomes in a world.

    base_bits
        Number of feature commitments that define the current function.

    observed_count
        How many successful observations we have seen.
        The whole point is that this is small.
        Small samples create accidental patterns.

    n_worlds
        How many independent worlds we average over.

    trials_per_world
        How many independent observation samples we take in each world.

    seed
        Random seed for reproducibility.

    n_boot
        Bootstrap resamples for error bars.
    """

    d_bits: int = 10
    outcome_count: int = 48
    base_bits: int = 2
    observed_count: int = 4
    n_worlds: int = 200
    trials_per_world: int = 20
    seed: int = 0
    n_boot: int = 5000


def build_literal_vocabulary_for_catalogue(env: FiniteEnvironment, *, d_bits: int) -> Vocabulary:
    """Create a Stack Theory vocabulary for a catalogue of bitstring states.

    We build the simplest possible vocabulary.

    For each feature index j we add two programs.
    One program is the set of catalogue states where x_j is 0.
    The other program is the set of catalogue states where x_j is 1.

    A policy is then just a conjunction of some of these programs.
    """

    programs: List[Program] = []
    names: List[str] = []

    # env.states is the list of catalogue states.
    # Each state is stored as an integer encoding of its bitstring.
    states: Sequence[int] = env.states  # type: ignore[assignment]

    for j in range(d_bits):
        for value in (0, 1):
            # Collect the indices of catalogue states that satisfy x_j = value.
            idxs = [
                env.state_to_index(s)
                for s in states
                if ((int(s) >> j) & 1) == value
            ]

            p = Program.from_state_indices(env, idxs)
            name = f"x{j}={value}"

            programs.append(p)
            names.append(name)

    vocab = Vocabulary(env=env, programs=programs, names=names)
    return vocab


def choose_base_commitments(rng: random.Random, *, d_bits: int, base_bits: int) -> Dict[int, int]:
    """Pick the bits that define the current function in a world."""

    base_positions = rng.sample(range(d_bits), base_bits)
    return {j: rng.choice([0, 1]) for j in base_positions}


def policy_statement_from_commitments(vocab: Vocabulary, commitments: Dict[int, int]) -> Statement:
    """Turn a dictionary like {bit_index: 0 or 1} into a Statement.

    This avoids talking about bitmasks.
    You can read it as.
    "build the conjunction of the chosen feature constraints".
    """

    items = [f"x{bit}={value}" for bit, value in commitments.items()]
    return vocab.statement(items)


def states_satisfying_statement(statement: Statement) -> Program:
    """Return the truth set of a statement.

    In Stack Theory language
    - the statement is a conjunction of programs
    - its truth set is the intersection of those programs

    Here it means
    "the set of catalogue outcomes where all chosen feature constraints hold".
    """

    return statement.truth_set()


def find_spurious_constants(alpha_states: Sequence[int], *, d_bits: int, base_commit: Dict[int, int]) -> Dict[int, int]:
    """Find feature bits that look constant in alpha by accident.

    alpha_states are successful observations.
    They satisfy the base commitments by construction.

    Because alpha is small, other bits can look constant even when they are not.

    We return a dict bit_index -> value for these accidental constants.
    """

    spurious: Dict[int, int] = {}

    for j in range(d_bits):
        if j in base_commit:
            continue

        first_val = (int(alpha_states[0]) >> j) & 1
        if all(((int(s) >> j) & 1) == first_val for s in alpha_states):
            spurious[j] = int(first_val)

    return spurious


def log2_survival_probability_under_uniform_novelty(
    *,
    policy: Statement,
    unobserved_states: Program,
) -> int:
    """Compute log2 survival probability under the uniform novelty model.

    This is the key measurement for Experiment A.

    Model in plain language
    - There is an unobserved region U.
      These are outcomes in the world we have not seen yet.
    - Future selection pressures are modelled as a random subset of U.
      Think of nature picking which new constraints will matter.
    - A policy survives if it does not contradict any of those future constraints.

    Under a uniform subset model, the probability of survival is exactly

        2^{|B_pi|} / 2^{|U|}

    where B_pi is the part of U that is still compatible with the policy.

    Taking log2 gives

        log2 P(survive) = |B_pi| - |U|

    This is why we only need counts.
    """

    truth_set = states_satisfying_statement(policy)

    # Buffer is the part of the unobserved region that the policy still allows.
    buffer = truth_set & unobserved_states

    return int(buffer.cardinality() - unobserved_states.cardinality())


def run_experiment_A(cfg: ExperimentAConfig) -> Tuple[Dict[str, str], Dict[str, float]]:
    """Run Experiment A and return both LaTeX macros and raw stats for plotting."""

    rng = random.Random(cfg.seed)

    log_w: List[int] = []
    log_r: List[int] = []
    deltas: List[int] = []
    spurious_counts: List[int] = []

    worlds_ok = 0

    for _ in range(cfg.n_worlds):
        # We resample world catalogues until the base function has enough examples.
        # If we did not do this, some worlds would be impossible to learn from.
        for _attempt in range(1000):
            catalogue_states = rng.sample(range(2 ** cfg.d_bits), cfg.outcome_count)

            base_commit = choose_base_commitments(rng, d_bits=cfg.d_bits, base_bits=cfg.base_bits)

            # Build Stack Theory objects for this world.
            env = FiniteEnvironment(catalogue_states)
            vocab = build_literal_vocabulary_for_catalogue(env, d_bits=cfg.d_bits)

            base_policy = policy_statement_from_commitments(vocab, base_commit)
            base_truth = states_satisfying_statement(base_policy)
            base_ok_states = [env.states[i] for i in base_truth.iter_state_indices()]  # type: ignore[index]

            if len(base_ok_states) >= cfg.observed_count + 1:
                break
        else:
            # Give up on this world.
            continue

        worlds_ok += 1

        for _trial in range(cfg.trials_per_world):
            # Observations alpha are successful examples.
            alpha_states = rng.sample(base_ok_states, cfg.observed_count)
            alpha_set = set(alpha_states)

            # U is the unobserved region inside the world catalogue.
            unobserved = [s for s in catalogue_states if s not in alpha_set]
            unobserved_prog = Program.from_state_indices(env, [env.state_to_index(s) for s in unobserved])

            # Identify accidental constants.
            spurious = find_spurious_constants(alpha_states, d_bits=cfg.d_bits, base_commit=base_commit)
            spurious_counts.append(len(spurious))

            # Weakness choice.
            # In this construction the weakest correct policy is just the base commitments.
            w_policy = base_policy

            # Random baseline.
            # It commits to a random subset of spurious constants.
            r_commit = dict(base_commit)
            for bit, val in spurious.items():
                if rng.random() < 0.5:
                    r_commit[bit] = val
            r_policy = policy_statement_from_commitments(vocab, r_commit)

            lw = log2_survival_probability_under_uniform_novelty(
                policy=w_policy,
                unobserved_states=unobserved_prog,
            )
            lr = log2_survival_probability_under_uniform_novelty(
                policy=r_policy,
                unobserved_states=unobserved_prog,
            )

            log_w.append(lw)
            log_r.append(lr)
            deltas.append(lw - lr)

    # Convert to numpy arrays for easy statistics.
    log_w_arr = np.array(log_w, dtype=float)
    log_r_arr = np.array(log_r, dtype=float)
    delta_arr = np.array(deltas, dtype=float)
    spurious_arr = np.array(spurious_counts, dtype=float)

    mean_w = float(np.mean(log_w_arr))
    mean_r = float(np.mean(log_r_arr))
    mean_delta = float(np.mean(delta_arr))

    ci_w_lo, ci_w_hi = bootstrap_ci_mean(log_w_arr, n_boot=cfg.n_boot, seed=cfg.seed + 1)
    ci_r_lo, ci_r_hi = bootstrap_ci_mean(log_r_arr, n_boot=cfg.n_boot, seed=cfg.seed + 2)
    ci_d_lo, ci_d_hi = bootstrap_ci_mean(delta_arr, n_boot=cfg.n_boot, seed=cfg.seed + 3)

    macros = {
        "ExpAStateBits": str(cfg.d_bits),
        "ExpAOutcomeCount": str(cfg.outcome_count),
        "ExpABaseBits": str(cfg.base_bits),
        "ExpAObservedM": str(cfg.observed_count),
        "ExpANWorlds": str(worlds_ok),
        "ExpATrialsPerWorld": str(cfg.trials_per_world),
        "ExpATrials": str(int(worlds_ok * cfg.trials_per_world)),
        "ExpASpuriousMean": fmt(float(np.mean(spurious_arr)), 3),
        "ExpAUniformLogPWmax": fmt(mean_w, 3),
        "ExpAUniformLogPWmaxCIlo": fmt(ci_w_lo, 3),
        "ExpAUniformLogPWmaxCIhi": fmt(ci_w_hi, 3),
        "ExpAUniformLogPUnif": fmt(mean_r, 3),
        "ExpAUniformLogPUnifCIlo": fmt(ci_r_lo, 3),
        "ExpAUniformLogPUnifCIhi": fmt(ci_r_hi, 3),
        "ExpAUniformDeltaWminusUniform": fmt(mean_delta, 3),
        "ExpAUniformDeltaCIlo": fmt(ci_d_lo, 3),
        "ExpAUniformDeltaCIhi": fmt(ci_d_hi, 3),
    }

    raw_for_plot = {
        "mean_log_w": mean_w,
        "mean_log_r": mean_r,
        "ci_w_lo": ci_w_lo,
        "ci_w_hi": ci_w_hi,
        "ci_r_lo": ci_r_lo,
        "ci_r_hi": ci_r_hi,
        "mean_delta": mean_delta,
        "ci_d_lo": ci_d_lo,
        "ci_d_hi": ci_d_hi,
    }

    return macros, raw_for_plot


def make_fig1_expA_bar(outpath: Path, stats: Dict[str, float]) -> None:
    """Plot the Experiment A bar chart."""

    mean_w = stats["mean_log_w"]
    mean_r = stats["mean_log_r"]

    lo_w = stats["ci_w_lo"]
    hi_w = stats["ci_w_hi"]

    lo_r = stats["ci_r_lo"]
    hi_r = stats["ci_r_hi"]

    labels = ["random", "weakness"]
    means = [mean_r, mean_w]

    yerr = [
        [mean_r - lo_r, mean_w - lo_w],
        [hi_r - mean_r, hi_w - mean_w],
    ]

    plt.figure(figsize=(4.8, 4.0))
    xs = range(len(labels))

    # Black and white so it survives printing.
    plt.bar(xs, means, color="white", edgecolor="black")
    plt.errorbar(xs, means, yerr=yerr, fmt="none", ecolor="black", capsize=4)

    plt.xticks(list(xs), labels)
    plt.ylabel("mean log2 survival probability")
    plt.ylim(min(lo_r, lo_w) - 1.0, max(hi_r, hi_w) + 1.0)
    plt.tight_layout()
    plt.savefig(outpath)
    plt.close()


# -----------------------------------------------------------------------------
# Experiment E
# Damage and repair
# -----------------------------------------------------------------------------


@dataclass(frozen=True)
class ExperimentEConfig:
    """All knobs for Experiment E.

    This is a deliberately minimal model.

    k_simple
        Number of essential parts in a simple system.
        Fewer essential parts means fewer things can break.
        This is the sense in which a rock is robust.

    k_complex
        Number of essential parts in a complex system.
        More essential parts means more things can break.

    p_break
        Chance that a given essential part breaks at each time step.

    repair_budget
        How many broken parts can be repaired per time step.

    horizon
        How many steps we plot.
    """

    horizon: int = 40
    p_break: float = 0.02
    repair_budget: int = 1
    k_simple: int = 3
    k_complex: int = 12


def per_step_survival_probability(
    *,
    essential_part_count: int,
    break_probability: float,
    repair_budget: int,
) -> float:
    """Probability the system survives a single step.

    Plain language
    - There are k essential parts.
    - Each part breaks independently with probability p.
    - If more than repair_budget parts break in the same step, you die.

    We compute this by adding up the chances of
    0 breaks
    1 break
    2 breaks
    and so on up to the repair budget.
    """

    k = essential_part_count
    p = break_probability
    r = repair_budget

    return sum(
        math.comb(k, j) * (p ** j) * ((1.0 - p) ** (k - j))
        for j in range(r + 1)
    )


def median_survival_time_from_step_probability(step_survival_prob: float) -> int:
    """Median survival time in steps.

    If survival each step is s, then survival at time t is s^t.
    The median is the smallest t with s^t <= 0.5.
    """

    return int(math.ceil(math.log(0.5) / math.log(step_survival_prob)))


def run_experiment_E(cfg: ExperimentEConfig) -> Tuple[Dict[str, str], Dict[str, float]]:
    """Run Experiment E and return macros and raw curves."""

    s_simple = per_step_survival_probability(
        essential_part_count=cfg.k_simple,
        break_probability=cfg.p_break,
        repair_budget=0,
    )

    s_complex_norep = per_step_survival_probability(
        essential_part_count=cfg.k_complex,
        break_probability=cfg.p_break,
        repair_budget=0,
    )

    s_complex_rep = per_step_survival_probability(
        essential_part_count=cfg.k_complex,
        break_probability=cfg.p_break,
        repair_budget=cfg.repair_budget,
    )

    med_simple = median_survival_time_from_step_probability(s_simple)
    med_complex_norep = median_survival_time_from_step_probability(s_complex_norep)
    med_complex_rep = median_survival_time_from_step_probability(s_complex_rep)

    macros = {
        "ExpEHorizon": str(cfg.horizon),
        "ExpEPbreak": fmt(cfg.p_break, 3),
        "ExpERepairBudget": str(cfg.repair_budget),
        "ExpEKsimple": str(cfg.k_simple),
        "ExpEKcomplex": str(cfg.k_complex),
        "ExpEMedianSurvivalSimpleNoRepair": str(med_simple),
        "ExpEMedianSurvivalComplexNoRepair": str(med_complex_norep),
        "ExpEMedianSurvivalComplexRepair": str(med_complex_rep),
    }

    raw = {
        "s_simple": s_simple,
        "s_complex_norep": s_complex_norep,
        "s_complex_rep": s_complex_rep,
        "med_simple": med_simple,
        "med_complex_norep": med_complex_norep,
        "med_complex_rep": med_complex_rep,
    }

    return macros, raw


def make_fig2_damage_repair(
    outpath_pdf: Path,
    outpath_png: Path,
    *,
    cfg: ExperimentEConfig,
) -> None:
    """Plot survival curves for Experiment E."""

    s_simple = per_step_survival_probability(
        essential_part_count=cfg.k_simple,
        break_probability=cfg.p_break,
        repair_budget=0,
    )

    s_complex_norep = per_step_survival_probability(
        essential_part_count=cfg.k_complex,
        break_probability=cfg.p_break,
        repair_budget=0,
    )

    s_complex_rep = per_step_survival_probability(
        essential_part_count=cfg.k_complex,
        break_probability=cfg.p_break,
        repair_budget=cfg.repair_budget,
    )

    ts = np.arange(0, cfg.horizon + 1)

    # Survival at time t is s^t.
    curve_simple = np.power(s_simple, ts)
    curve_complex_norep = np.power(s_complex_norep, ts)
    curve_complex_rep = np.power(s_complex_rep, ts)

    plt.figure(figsize=(7, 7))

    plt.plot(ts, curve_simple, linestyle=":", color="black", label="simple system, no repair (rock like)")
    plt.plot(ts, curve_complex_norep, linestyle="-.", color="black", label="complex system, no repair")
    plt.plot(ts, curve_complex_rep, linestyle="-", color="black", label="complex system, bounded repair")

    plt.title("Experiment E damage and repair")
    plt.xlabel("time step")
    plt.ylabel("survival fraction")
    plt.xlim(0, cfg.horizon)
    plt.ylim(0, 1.0)
    plt.legend(loc="upper right", frameon=False)
    plt.tight_layout()

    plt.savefig(outpath_pdf)
    plt.savefig(outpath_png, dpi=200)
    plt.close()


# -----------------------------------------------------------------------------
# Main runner
# -----------------------------------------------------------------------------


def main() -> None:
    here = Path(__file__).resolve().parent

    # Hash every python file in this folder and its subfolders.
    # This includes this script and the Stack Theory Suite code we vendored.
    py_files = list(here.rglob("*.py"))
    code_hash = sha256_of_files(py_files)

    # Run Experiment A.
    cfgA = ExperimentAConfig()
    expA_macros, expA_raw = run_experiment_A(cfgA)
    make_fig1_expA_bar(here / "fig1_expA_bar.pdf", expA_raw)

    # Run Experiment E.
    cfgE = ExperimentEConfig()
    expE_macros, _expE_raw = run_experiment_E(cfgE)
    make_fig2_damage_repair(
        here / "fig2_survival_repair.pdf",
        here / "fig2_survival_repair_preview.png",
        cfg=cfgE,
    )

    # Write macros.
    groups = [
        ("Experiment A novelty toy worlds", expA_macros),
        ("Experiment E damage and repair", expE_macros),
    ]
    write_results_macros(here / "results_macros.tex", groups=groups, code_hash=code_hash)

    print("wrote results_macros.tex")
    print("wrote fig1_expA_bar.pdf")
    print("wrote fig2_survival_repair.pdf and preview")


if __name__ == "__main__":
    main()
